def test_adaptive_question_abdominal(client):
    """Test POST /api/v1/ai/adaptive-question for Abdominal pain chief complaint"""
    payload = {
        "sessionId": "MED-49201",
        "chiefComplaint": "Severe cramping pain in the right lower abdomen for 2 days",
        "symptoms": ["Right Lower Quadrant Pain"],
        "currentStep": 1,
        "consultType": "allopathic"
    }
    response = client.post("/api/v1/ai/adaptive-question", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["category"] == "Abdominal"
    assert data["targetSection"] == "SOCRATES_PAIN"
    assert "nextQuestion" in data
    assert not data["isRedFlag"]

def test_adaptive_question_fever(client):
    """Test POST /api/v1/ai/adaptive-question for Fever chief complaint"""
    payload = {
        "sessionId": "MED-49201",
        "chiefComplaint": "High fever with shivering and chills for 3 days",
        "symptoms": ["High Fever", "Chills"],
        "currentStep": 1,
        "consultType": "allopathic"
    }
    response = client.post("/api/v1/ai/adaptive-question", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["category"] == "Fever"
    assert data["targetSection"] == "FEVER_ROS"
    assert "nextQuestion" in data

def test_adaptive_question_ayush(client):
    """Test POST /api/v1/ai/adaptive-question for AYUSH chief complaint"""
    payload = {
        "sessionId": "MED-49201",
        "chiefComplaint": "Prakriti imbalance, digestive acidity and stomach heat",
        "symptoms": ["Acidity", "Heat"],
        "currentStep": 1,
        "consultType": "ayush"
    }
    response = client.post("/api/v1/ai/adaptive-question", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["category"] == "AYUSH"
    assert data["targetSection"] == "DASHAVIDHA_PARIKSHA"
    assert "nextQuestion" in data
