def test_get_physician_summary(client):
    """Test GET /api/v1/physician/summary/{patient_id} for Doctor Workstation"""
    response = client.get("/api/v1/physician/summary/MED-49201")
    assert response.status_code == 200
    data = response.json()
    assert "name" in data
    assert "vitals" in data
    assert "allergies" in data
    assert "labResults" in data
    assert data["consultType"] in ["allopathic", "ayush"]

def test_drug_interaction_checker(client, auth_headers_doctor):
    """Test POST /api/v1/doctor/check-interactions for NSAID + ARB contraindication"""
    payload = {
        "candidateMedicine": "Tab. Diclofenac 50 mg",
        "currentPrescriptions": [
            {"medicine": "Tab. Telmisartan 40 mg"}
        ],
        "knownAllergies": [
            {"name": "Penicillin", "reaction": "Anaphylaxis"}
        ]
    }
    response = client.post("/api/v1/doctor/check-interactions", json=payload, headers=auth_headers_doctor)
    assert response.status_code == 200
    res = response.json()
    assert "warnings" in res
    assert len(res["warnings"]) > 0
    assert res["warnings"][0]["severity"] == "high"
