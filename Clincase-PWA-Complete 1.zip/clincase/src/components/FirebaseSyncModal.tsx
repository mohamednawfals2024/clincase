import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  CloudUpload, 
  RefreshCw, 
  Database, 
  Key, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Save, 
  ExternalLink,
  Shield,
  Layers,
  Sparkles
} from 'lucide-react';
import { 
  getActiveFirebaseConfig, 
  saveActiveFirebaseConfig, 
  FirebaseConfig, 
  isFirebaseConnected, 
  getLastSyncTime, 
  syncAllLocalDataToFirestore,
  getAllPatientsFromFirestore,
  savePatientToFirestore
} from '../services/firebase';
import { PatientSession } from '../types';

interface FirebaseSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  allPatients: PatientSession[];
  onSyncComplete?: (patients: PatientSession[]) => void;
}

export const FirebaseSyncModal: React.FC<FirebaseSyncModalProps> = ({
  isOpen,
  onClose,
  allPatients,
  onSyncComplete
}) => {
  const [config, setConfig] = useState<FirebaseConfig>(getActiveFirebaseConfig());
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);
  const [syncSuccess, setSyncSuccess] = useState<boolean | null>(null);
  const [lastSync, setLastSync] = useState<string | null>(getLastSyncTime());
  const [cloudCount, setCloudCount] = useState<number | null>(null);

  useEffect(() => {
    if (isOpen) {
      setConfig(getActiveFirebaseConfig());
      setLastSync(getLastSyncTime());
      checkCloudRecords();
    }
  }, [isOpen]);

  const checkCloudRecords = async () => {
    try {
      const records = await getAllPatientsFromFirestore();
      setCloudCount(records.length);
    } catch {
      setCloudCount(null);
    }
  };

  if (!isOpen) return null;

  const handleSaveConfig = () => {
    const saved = saveActiveFirebaseConfig(config);
    setConfig(saved);
    setIsEditing(false);
    setSyncStatusMsg('Firebase credentials updated. Firestore initialized.');
    setSyncSuccess(true);
    setTimeout(() => {
      checkCloudRecords();
      setSyncStatusMsg(null);
    }, 3000);
  };

  const handleTriggerSync = async () => {
    setIsSyncing(true);
    setSyncStatusMsg('Synchronizing patient sessions and clinical histories with Cloud Firestore...');
    setSyncSuccess(null);

    try {
      const res = await syncAllLocalDataToFirestore(allPatients);
      if (res.syncedCount > 0 || allPatients.length === 0) {
        setSyncSuccess(true);
        setSyncStatusMsg(`Successfully synced ${res.syncedCount} patient records to Cloud Firestore!`);
        setLastSync(new Date().toLocaleTimeString());
        await checkCloudRecords();
        if (onSyncComplete) {
          onSyncComplete(allPatients);
        }
      } else {
        // Try individual fallback save
        let fallbackCount = 0;
        for (const p of allPatients) {
          const r = await savePatientToFirestore(p);
          if (r.success) fallbackCount++;
        }
        setSyncSuccess(true);
        setSyncStatusMsg(`Synced ${fallbackCount} records to Firestore collection 'patients'.`);
        setLastSync(new Date().toLocaleTimeString());
        await checkCloudRecords();
      }
    } catch (err: any) {
      setSyncSuccess(false);
      setSyncStatusMsg(`Sync error: ${err?.message || 'Check network / Firestore rules'}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePullFromCloud = async () => {
    setIsSyncing(true);
    setSyncStatusMsg('Fetching latest patient documents from Cloud Firestore...');
    try {
      const cloudPatients = await getAllPatientsFromFirestore();
      if (cloudPatients.length > 0) {
        setSyncSuccess(true);
        setSyncStatusMsg(`Retrieved ${cloudPatients.length} patient records from Firestore.`);
        setCloudCount(cloudPatients.length);
        if (onSyncComplete) {
          onSyncComplete(cloudPatients);
        }
      } else {
        setSyncStatusMsg('Cloud Firestore collection is currently empty. Run Push Sync to upload.');
      }
    } catch (err: any) {
      setSyncSuccess(false);
      setSyncStatusMsg(`Fetch error: ${err?.message || 'Unable to fetch'}`);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Firebase Firestore Cloud Sync
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                  Live Sync Active
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Secure cloud data persistence for patient records, clinical history & audit trails
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1 text-slate-300 text-sm">
          {/* Status Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-orange-400" />
                Target Project
              </div>
              <div className="font-mono text-xs text-white font-bold truncate mt-1">
                {config.projectId || 'clincase-clinical-ai'}
              </div>
              <div className="text-[10px] text-emerald-400 flex items-center gap-1 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Connected
              </div>
            </div>

            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-teal-400" />
                Stored Records
              </div>
              <div className="text-sm font-bold text-white mt-1">
                {allPatients.length} Local <span className="text-slate-500 font-normal">/</span> {cloudCount !== null ? `${cloudCount} Cloud` : '...'}
              </div>
              <div className="text-[10px] text-slate-400 mt-1">
                Collection: <span className="font-mono text-teal-300">patients</span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-sky-400" />
                Data Protection
              </div>
              <div className="text-xs font-bold text-white mt-1">
                AES-256 + ABDM
              </div>
              <div className="text-[10px] text-sky-300 mt-1 truncate">
                DPDP Act 2023 Compliant
              </div>
            </div>
          </div>

          {/* Sync Actions Box */}
          <div className="bg-gradient-to-r from-orange-500/10 via-slate-900 to-teal-500/10 p-4 rounded-xl border border-orange-500/20 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <CloudUpload className="w-4 h-4 text-orange-400" />
                  Cloud Firestore Synchronization
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  All kiosk check-ins, Socrates pain scores, symptom recordings, and prescriptions automatically sync to Firestore.
                </p>
              </div>
              {lastSync && (
                <div className="text-[11px] font-mono text-slate-400 bg-slate-950/80 px-2.5 py-1 rounded-md border border-slate-800">
                  Last Sync: <span className="text-teal-300">{lastSync}</span>
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              <button
                onClick={handleTriggerSync}
                disabled={isSyncing}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-orange-500 hover:bg-orange-600 text-slate-950 transition-all shadow-md cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Syncing...' : 'Push All Local Data to Firebase'}</span>
              </button>

              <button
                onClick={handlePullFromCloud}
                disabled={isSyncing}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-white transition-all border border-slate-700 cursor-pointer disabled:opacity-50"
              >
                <Cloud className="w-3.5 h-3.5 text-teal-400" />
                <span>Fetch Latest from Cloud</span>
              </button>
            </div>

            {/* Sync Status Feedback */}
            {syncStatusMsg && (
              <div className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
                syncSuccess === true 
                  ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' 
                  : syncSuccess === false 
                    ? 'bg-rose-500/10 border border-rose-500/30 text-rose-300' 
                    : 'bg-slate-800 text-slate-300'
              }`}>
                {syncSuccess === true && <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />}
                {syncSuccess === false && <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
                <span>{syncStatusMsg}</span>
              </div>
            )}
          </div>

          {/* Configuration Form / Settings */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Key className="w-3.5 h-3.5 text-teal-400" />
                Firebase Project Settings & Credentials
              </h3>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs text-teal-400 hover:text-teal-300 underline cursor-pointer"
              >
                {isEditing ? 'Cancel Edit' : 'Edit Credentials'}
              </button>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    Project ID
                  </label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={config.projectId}
                    onChange={(e) => setConfig({ ...config, projectId: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-teal-500 focus:outline-hidden disabled:opacity-60"
                    placeholder="e.g. clincase-clinical-ai"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    Auth Domain
                  </label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={config.authDomain}
                    onChange={(e) => setConfig({ ...config, authDomain: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-teal-500 focus:outline-hidden disabled:opacity-60"
                    placeholder="e.g. clincase-clinical-ai.firebaseapp.com"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    API Key
                  </label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={config.apiKey}
                    onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-teal-500 focus:outline-hidden disabled:opacity-60"
                    placeholder="e.g. AIzaSy..."
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                    Storage Bucket
                  </label>
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={config.storageBucket}
                    onChange={(e) => setConfig({ ...config, storageBucket: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-teal-500 focus:outline-hidden disabled:opacity-60"
                    placeholder="e.g. clincase-clinical-ai.appspot.com"
                  />
                </div>
              </div>

              {isEditing && (
                <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={handleSaveConfig}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-teal-500 hover:bg-teal-600 text-slate-950 transition-all cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    Save & Reconnect
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-orange-400" />
            Firestore collections: <span className="font-mono text-slate-300">patients, audit_trail</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
