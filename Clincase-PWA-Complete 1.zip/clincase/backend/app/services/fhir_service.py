import json
from typing import Dict, Any
from app.core.security import encrypt_payload, sha256

class FHIRService:
    def export_encrypted_bundle(self, patient_data: dict) -> Dict[str, Any]:
        """Export AES-256-GCM encrypted FHIR R4 Bundle container"""
        fhir_bundle = {
            "resourceType": "Bundle",
            "type": "document",
            "timestamp": patient_data.get("createdAt"),
            "entry": [
                {
                    "resource": {
                        "resourceType": "Patient",
                        "id": patient_data.get("id"),
                        "identifier": [{"system": "https://abdm.gov.in/abha", "value": patient_data.get("abhaId")}],
                        "name": [{"text": patient_data.get("name")}],
                        "gender": patient_data.get("gender"),
                        "birthDate": patient_data.get("dob")
                    }
                },
                {
                    "resource": {
                        "resourceType": "Observation",
                        "code": {"text": "Vital Signs"},
                        "valueString": json.dumps(patient_data.get("vitals", {}))
                    }
                }
            ]
        }

        raw_json = json.dumps(fhir_bundle)
        encrypted = encrypt_payload(raw_json)
        checksum = sha256(encrypted["cipherText"])

        return {
            "securityStandard": "ABDM_LEVEL_3_ENCRYPTED_CONTAINER",
            "encryptionAlgorithm": "AES-256-GCM",
            "packageChecksum": checksum,
            "encryptedPayload": encrypted["cipherText"],
            "nonce": encrypted["nonce"]
        }

fhir_service = FHIRService()
