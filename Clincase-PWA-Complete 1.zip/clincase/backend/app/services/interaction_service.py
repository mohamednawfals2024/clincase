from typing import List, Dict, Any

class InteractionService:
    def check_interactions(
        self, candidate_med: str, current_prescriptions: List[dict], known_allergies: List[dict]
    ) -> List[Dict[str, Any]]:
        warnings = []
        med_lower = candidate_med.lower()

        # 1. Allergy contraindication check
        for allergy in known_allergies:
            a_name = (allergy.get("name") if isinstance(allergy, dict) else str(allergy)).lower()
            if ("penicillin" in a_name or "amoxicillin" in a_name) and any(kw in med_lower for kw in ["amox", "penicillin", "augmentin"]):
                warnings.append({
                    "severity": "high",
                    "drugs": [candidate_med, a_name],
                    "description": "CRITICAL: Patient has documented severe allergy to Penicillin. Cross-reactivity anaphylaxis risk.",
                    "recommendation": "DO NOT PRESCRIBE. Switch to Macrolide (Azithromycin) or Fluoroquinolone."
                })

        # 2. NSAID + ARB/ACEi interaction
        if any(kw in med_lower for kw in ["diclofenac", "ibuprofen", "naproxen"]):
            for rx in current_prescriptions:
                rx_name = (rx.get("medicine") if isinstance(rx, dict) else str(rx)).lower()
                if any(kw in rx_name for kw in ["telmisartan", "enalapril", "ramipril", "losartan"]):
                    warnings.append({
                        "severity": "high",
                        "drugs": [candidate_med, rx_name],
                        "description": "POTENTIAL INTERACTION: NSAIDs decrease antihypertensive efficacy of ARBs/ACE-Is and increase renal impairment risk.",
                        "recommendation": "Prefer Paracetamol for analgesia; monitor renal function & blood pressure."
                    })

        # 3. Duplicate Metformin
        if "metformin" in med_lower:
            for rx in current_prescriptions:
                rx_name = (rx.get("medicine") if isinstance(rx, dict) else str(rx)).lower()
                if "metformin" in rx_name:
                    warnings.append({
                        "severity": "moderate",
                        "drugs": [candidate_med, rx_name],
                        "description": "Duplicate Metformin formulations detected across active prescriptions.",
                        "recommendation": "Verify cumulative daily dose does not exceed 2000 mg."
                    })

        return warnings

interaction_service = InteractionService()
