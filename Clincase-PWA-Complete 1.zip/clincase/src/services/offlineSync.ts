// ============================================================================
// CLINCASE OFFLINE-FIRST SYNCHRONIZATION & LOCAL PERSISTENCE ENGINE
// Seamless Offline OPD Kiosk Continuity & Auto Cloud Synchronization
// ============================================================================

import { PatientSession } from '../types';

const STORAGE_KEY_OFFLINE_PATIENTS = 'clincase_offline_patients_store';
const STORAGE_KEY_OFFLINE_QUEUE = 'clincase_offline_mutation_queue';
const STORAGE_KEY_LAST_SYNC = 'clincase_offline_last_sync_time';

export interface OfflineMutation {
  id: string;
  action: 'save_patient' | 'patch_patient' | 'delete_patient' | 'emergency_dispatch';
  data: any;
  timestamp: number;
}

type NetworkChangeCallback = (isOnline: boolean) => void;
const networkListeners: Set<NetworkChangeCallback> = new Set();

let isOnlineState: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;

// Initialize Global Offline/Online Listeners
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    console.log('[OfflineSync] Network status changed: ONLINE');
    isOnlineState = true;
    networkListeners.forEach(cb => cb(true));
    // Automatically drain offline mutation queue when connectivity is restored
    processOfflineMutationQueue();
  });

  window.addEventListener('offline', () => {
    console.log('[OfflineSync] Network status changed: OFFLINE');
    isOnlineState = false;
    networkListeners.forEach(cb => cb(false));
  });
}

/**
 * Returns current online/offline status
 */
export function isAppOnline(): boolean {
  if (typeof navigator !== 'undefined') {
    return navigator.onLine && isOnlineState;
  }
  return true;
}

/**
 * Subscribes to network connectivity state changes
 */
export function subscribeToNetworkStatus(callback: NetworkChangeCallback): () => void {
  networkListeners.add(callback);
  callback(isAppOnline());
  return () => {
    networkListeners.delete(callback);
  };
}

/**
 * Retrieves all offline stored patients from local storage
 */
export function getOfflinePatients(): PatientSession[] {
  try {
    if (typeof localStorage === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY_OFFLINE_PATIENTS);
    if (!data) return [];
    return JSON.parse(data) as PatientSession[];
  } catch (err) {
    console.warn('[OfflineSync] Failed to read offline patients store:', err);
    return [];
  }
}

/**
 * Saves or updates a patient in the offline local database
 */
export function savePatientOffline(patient: PatientSession): void {
  try {
    if (typeof localStorage === 'undefined' || !patient || !patient.id) return;
    const current = getOfflinePatients();
    const index = current.findIndex(p => p.id === patient.id);
    
    const enrichedPatient: PatientSession = {
      ...patient,
      lastOfflineModified: new Date().toISOString()
    } as any;

    if (index >= 0) {
      current[index] = enrichedPatient;
    } else {
      current.unshift(enrichedPatient);
    }

    localStorage.setItem(STORAGE_KEY_OFFLINE_PATIENTS, JSON.stringify(current));
    console.log(`[OfflineSync] Patient ${patient.id} persisted to offline storage.`);
  } catch (err) {
    console.warn('[OfflineSync] Failed to save patient to offline store:', err);
  }
}

/**
 * Deletes a patient from the offline local database
 */
export function deletePatientOffline(patientId: string): void {
  try {
    if (typeof localStorage === 'undefined' || !patientId) return;
    const current = getOfflinePatients();
    const filtered = current.filter(p => p.id !== patientId);
    localStorage.setItem(STORAGE_KEY_OFFLINE_PATIENTS, JSON.stringify(filtered));
    console.log(`[OfflineSync] Patient ${patientId} removed from offline store.`);
  } catch (err) {
    console.warn('[OfflineSync] Failed to delete patient from offline store:', err);
  }
}

/**
 * Retrieves pending offline mutations
 */
export function getOfflineMutationQueue(): OfflineMutation[] {
  try {
    if (typeof localStorage === 'undefined') return [];
    const data = localStorage.getItem(STORAGE_KEY_OFFLINE_QUEUE);
    if (!data) return [];
    return JSON.parse(data) as OfflineMutation[];
  } catch (err) {
    console.warn('[OfflineSync] Failed to read mutation queue:', err);
    return [];
  }
}

/**
 * Enqueues a mutation to be synchronized when connection is restored
 */
export function enqueueOfflineMutation(action: OfflineMutation['action'], data: any): void {
  try {
    if (typeof localStorage === 'undefined') return;
    const queue = getOfflineMutationQueue();
    const mutation: OfflineMutation = {
      id: `MUT-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      action,
      data,
      timestamp: Date.now()
    };
    queue.push(mutation);
    localStorage.setItem(STORAGE_KEY_OFFLINE_QUEUE, JSON.stringify(queue));
    console.log(`[OfflineSync] Queued offline mutation: ${action} (${mutation.id})`);
  } catch (err) {
    console.warn('[OfflineSync] Failed to enqueue mutation:', err);
  }
}

/**
 * Processes and flushes all queued offline mutations to backend & cloud
 */
export async function processOfflineMutationQueue(): Promise<{
  success: boolean;
  syncedCount: number;
  remainingCount: number;
}> {
  if (!isAppOnline()) {
    console.log('[OfflineSync] Device is offline. Cannot process sync queue.');
    return { success: false, syncedCount: 0, remainingCount: getOfflineMutationQueue().length };
  }

  const queue = getOfflineMutationQueue();
  if (queue.length === 0) {
    return { success: true, syncedCount: 0, remainingCount: 0 };
  }

  console.log(`[OfflineSync] Processing ${queue.length} pending offline mutations...`);
  let synced = 0;
  const remainingQueue: OfflineMutation[] = [];

  for (const item of queue) {
    try {
      if (item.action === 'save_patient') {
        await fetch('/api/patient/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item.data)
        });
        synced++;
      } else if (item.action === 'patch_patient') {
        const { sessionId, updates } = item.data;
        await fetch(`/api/summary/${sessionId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates)
        });
        synced++;
      } else if (item.action === 'delete_patient') {
        const { sessionId } = item.data;
        await fetch(`/api/patient/${sessionId}`, { method: 'DELETE' });
        synced++;
      } else if (item.action === 'emergency_dispatch') {
        await fetch('/api/emergency/dispatch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(item.data)
        });
        synced++;
      }
    } catch (err) {
      console.warn(`[OfflineSync] Failed to process mutation ${item.id}, retaining in queue:`, err);
      remainingQueue.push(item);
    }
  }

  localStorage.setItem(STORAGE_KEY_OFFLINE_QUEUE, JSON.stringify(remainingQueue));
  localStorage.setItem(STORAGE_KEY_LAST_SYNC, new Date().toISOString());

  console.log(`[OfflineSync] Sync complete. Processed: ${synced}, Remaining in queue: ${remainingQueue.length}`);
  return {
    success: remainingQueue.length === 0,
    syncedCount: synced,
    remainingCount: remainingQueue.length
  };
}

/**
 * Returns count of pending offline changes awaiting sync
 */
export function getPendingSyncCount(): number {
  return getOfflineMutationQueue().length;
}

/**
 * Returns last successful sync timestamp
 */
export function getLastSyncTimestamp(): string | null {
  if (typeof localStorage === 'undefined') return null;
  return localStorage.getItem(STORAGE_KEY_LAST_SYNC);
}
