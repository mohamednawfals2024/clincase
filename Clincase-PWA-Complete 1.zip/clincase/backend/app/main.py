from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from datetime import datetime

from app.config import settings
from app.database import engine, Base
from app.api import auth, patient, clinical, document, ai_generation, timeline, consent, doctor, physician, speech

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize async database tables on startup
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # Shutdown engine connection pool
    await engine.dispose()

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="FastAPI REST Backend for Clincase AI Clinical History & OPD Platform with Configurable STT Abstraction Layer",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Custom Global Error Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": str(exc),
                "timestamp": datetime.utcnow().isoformat()
            }
        }
    )

# Configure CORS for React frontend (Port 3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers (v1)
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(patient.router, prefix=settings.API_V1_STR)
app.include_router(clinical.router, prefix=settings.API_V1_STR)
app.include_router(document.router, prefix=settings.API_V1_STR)
app.include_router(ai_generation.router, prefix=settings.API_V1_STR)
app.include_router(timeline.router, prefix=settings.API_V1_STR)
app.include_router(consent.router, prefix=settings.API_V1_STR)
app.include_router(doctor.router, prefix=settings.API_V1_STR)
app.include_router(physician.router, prefix=settings.API_V1_STR)
app.include_router(speech.router, prefix=settings.API_V1_STR)

@app.get("/")
async def root():
    return {
        "status": "healthy",
        "service": "Clincase FastAPI Backend (v1.0.0)",
        "activeSttProvider": settings.STT_PROVIDER,
        "docsUrl": "/docs",
        "compliance": "DPDP_Act_2023_ABDM_Level_3"
    }

@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "Clincase FastAPI Gateway",
        "sttProvider": settings.STT_PROVIDER,
        "timestamp": datetime.utcnow().isoformat()
    }
