from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.user import DoctorUserModel as UserModel
from app.schemas.auth import LoginRequest, TokenResponse, UserResponse
from app.core.security import verify_password, get_password_hash, create_access_token
from app.core.rbac import allow_guest

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/login", response_model=TokenResponse)
async def login(req: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Role Login endpoint for Doctor and Admin Workstation"""
    # Demo credentials handling
    if req.role == "doctor" and (req.username in ["DOC-MD-8921", "doctor", "doc"] or not req.username):
        token = create_access_token({"sub": "DOC-MD-8921", "role": "doctor"})
        return TokenResponse(
            access_token=token,
            role="doctor",
            name="Dr. Arvind Varma, MD"
        )
    elif req.role == "admin" and (req.username in ["ADMIN-SEC-01", "admin", "sec"] or not req.username):
        token = create_access_token({"sub": "ADMIN-SEC-01", "role": "admin"})
        return TokenResponse(
            access_token=token,
            role="admin",
            name="Hospital Admin (Sec-01)"
        )

    # Database credential lookup
    result = await db.execute(select(UserModel).where(UserModel.username == req.username))
    user = result.scalars().first()

    if not user or not verify_password(req.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or passcode credentials"
        )

    token = create_access_token({"sub": user.username, "role": user.role})
    return TokenResponse(
        access_token=token,
        role=user.role,
        name=user.full_name
    )
