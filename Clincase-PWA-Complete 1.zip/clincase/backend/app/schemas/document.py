from pydantic import BaseModel, Field
from typing import List, Optional

class ExtractedMedicationSchema(BaseModel):
    medicine: str = Field(..., description="Medicine brand / generic name")
    dosage: str = Field(..., description="Dosage strength (e.g. 500 mg)")
    frequency: str = Field(..., description="Dosing frequency (e.g. BD 1-0-1)")
    duration: str = Field(..., description="Treatment duration (e.g. 30 Days)")
    instructions: str = Field(..., description="Special instructions (e.g. After meals)")
    confidence: float = Field(95.0, ge=0.0, le=100.0)
    isUncertain: Optional[bool] = False

class ExtractedLabValueSchema(BaseModel):
    test: str = Field(..., description="Lab test name (e.g. HbA1c, Serum Creatinine)")
    value: str = Field(..., description="Measured result value (e.g. 7.8)")
    unit: str = Field(..., description="Measurement unit (e.g. %, mg/dL)")
    refRange: str = Field(..., description="Reference normal range (e.g. < 5.7)")
    status: str = Field("Normal", description="Normal, High, Low, or Critical")
    date: Optional[str] = None
    confidence: float = Field(96.0, ge=0.0, le=100.0)

class ExtractedLabInvestigationSchema(BaseModel):
    investigationName: str = Field(..., description="Test or Imaging investigation name")
    resultValue: str = Field(..., description="Result value or findings")
    unit: Optional[str] = None
    referenceRange: Optional[str] = None
    status: str = Field("Normal", description="Normal, High, Low, or Critical")

class DocumentResponse(BaseModel):
    id: str
    name: str
    pages: str = "1 Page"
    size: str = "1.0 MB"
    type: str = "prescription"
    url: str
    timestamp: str
    extractedText: Optional[str] = None
    extractedMeds: List[str] = []
    extractedDiagnoses: List[str] = []
    structuredMeds: List[ExtractedMedicationSchema] = []
    structuredLabs: List[ExtractedLabValueSchema] = []
    ocrConfidence: float = 95.0
    isHandwritten: bool = False
    ocrLanguage: str = "English & Indic"

class StructuredOcrPipelineResponse(BaseModel):
    documentId: str
    fileName: str
    documentType: str = Field(..., description="prescription, lab_report, discharge_summary")
    rawDocumentUrl: str = Field(..., description="URL to stream original file for physician verification")
    ocrConfidence: float = Field(94.0, ge=0.0, le=100.0)
    isHandwritten: bool = False
    ocrProvider: str = Field(..., description="Active OCR provider name (gemini, mock, tesseract)")
    extractedMedications: List[ExtractedMedicationSchema] = []
    extractedDiagnoses: List[str] = []
    extractedInvestigations: List[ExtractedLabInvestigationSchema] = []
    extractedDates: List[str] = []
    rawTextSummary: str
