from sqlalchemy import Column, String, DateTime, ForeignKey
from datetime import datetime
from app.database import Base

class PrescriptionModel(Base):
    __tablename__ = "prescriptions"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patient_records.id", ondelete="CASCADE"), nullable=False)
    medicine = Column(String, nullable=False)
    dosage = Column(String, nullable=False)
    frequency = Column(String, nullable=False)
    duration = Column(String, nullable=False)
    instructions = Column(String, nullable=False)
    prescribed_by = Column(String, default="Dr. Arvind Varma, MD")
    created_at = Column(DateTime, default=datetime.utcnow)
