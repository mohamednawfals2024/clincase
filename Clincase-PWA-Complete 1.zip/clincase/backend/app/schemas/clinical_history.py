from pydantic import BaseModel
from typing import Optional, Dict, List
from app.schemas.clinical import SocratesPainSchema, ROSSchema, DashavidhaSchema

class ClinicalHistoryCreate(BaseModel):
    patient_id: str
    session_id: str
    chief_complaint: Optional[str] = None
    hpi_details: Optional[str] = None
    past_medical_history: Optional[str] = None
    past_surgical_history: Optional[str] = None
    medication_history: Optional[str] = None
    allergy_history: Optional[str] = None
    family_history: Optional[str] = None
    lifestyle_details: Optional[str] = None
    socrates_pain: Optional[SocratesPainSchema] = None
    review_of_systems: Optional[ROSSchema] = None
    dashavidha_pariksha: Optional[DashavidhaSchema] = None

class ClinicalHistoryResponse(BaseModel):
    id: str
    patient_id: str
    session_id: str
    chief_complaint: Optional[str] = None
    hpi_details: Optional[str] = None
    past_medical_history: Optional[str] = None
    past_surgical_history: Optional[str] = None
    medication_history: Optional[str] = None
    allergy_history: Optional[str] = None
    family_history: Optional[str] = None
    lifestyle_details: Optional[str] = None
    socrates_pain_json: Optional[Dict] = None
    review_of_systems_json: Optional[Dict] = None
    dashavidha_pariksha_json: Optional[Dict] = None
    created_at: str
