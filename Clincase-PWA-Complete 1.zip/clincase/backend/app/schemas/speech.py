from pydantic import BaseModel, Field

class TranscriptionResponse(BaseModel):
    text: str = Field(..., description="Transcribed audio spoken text")
    confidence: float = Field(0.95, ge=0.0, le=1.0, description="Acoustic confidence score")
    language: str = Field("en", description="Detected or requested language code")
    provider: str = Field(..., description="Active STT provider name (gemini, mock, whisper)")
