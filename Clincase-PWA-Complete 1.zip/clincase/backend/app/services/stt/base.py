from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

@dataclass
class TranscribeResult:
    text: str
    confidence: float
    language: str
    provider: str

class STTProvider(ABC):
    @abstractmethod
    async def transcribe(
        self, 
        audio_bytes: bytes, 
        filename: str, 
        content_type: str, 
        language: Optional[str] = "en"
    ) -> TranscribeResult:
        """Abstract method to transcribe audio bytes into text"""
        pass
