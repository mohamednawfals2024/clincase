import os
from typing import List
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Clincase PostgreSQL & FastAPI Backend"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "MEDIKIOSK_HEALTHCARE_ABDM_DPDP_2026_MASTER_SECRET"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours
    
    # PostgreSQL async URL (with aiosqlite fallback for local dev)
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", 
        "postgresql+asyncpg://postgres:postgres@localhost:5432/clincase_db"
    )

    # Configurable STT Provider ("mock", "gemini", "whisper")
    STT_PROVIDER: str = os.getenv("STT_PROVIDER", "mock")

    # Configurable OCR Provider ("mock", "gemini", "tesseract")
    OCR_PROVIDER: str = os.getenv("OCR_PROVIDER", "mock")

    # Raw document preservation storage directory
    UPLOAD_DIR: str = os.path.join(os.getcwd(), "uploads", "documents")

    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    ENCRYPTION_SECRET: str = "MEDIKIOSK_HEALTHCARE_ABDM_DPDP_2026_MASTER_SECRET"
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:8000"]

    class Config:
        case_sensitive = True

settings = Settings()
