import React, { useState, useRef } from 'react';
import { 
  Camera, 
  FileText, 
  CheckCircle2, 
  Upload, 
  Trash2, 
  Sparkles, 
  Layers, 
  ArrowRight,
  ShieldCheck,
  Eye,
  AlertTriangle,
  FileCheck2,
  Image as ImageIcon,
  Check,
  HelpCircle,
  Stethoscope
} from 'lucide-react';
import { PatientSession, LanguageCode, DocumentRecord } from '../types';
import { translations } from '../data/translations';
import { uploadDocument, audioService } from '../services/api';

interface ScanStepProps {
  lang: LanguageCode;
  patient: PatientSession;
  onUpdatePatient: (updates: Partial<PatientSession>) => void;
  onProceedToSummary: () => void;
}

export const ScanStep: React.FC<ScanStepProps> = ({
  lang,
  patient,
  onUpdatePatient,
  onProceedToSummary
}) => {
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [selectedDocPreview, setSelectedDocPreview] = useState<DocumentRecord | null>(null);
  const [ocrSampleType, setOcrSampleType] = useState<'prescription' | 'lab_report'>('prescription');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = translations[lang] || translations.en;

  const handleCaptureDocument = async (fileToUpload?: File) => {
    setIsCapturing(true);
    audioService.playBeep('capture');

    setTimeout(async () => {
      setIsCapturing(false);
      setIsUploading(true);

      const docIndex = (patient.documents?.length || 0) + 1;
      const isLab = ocrSampleType === 'lab_report';
      const docName = fileToUpload 
        ? fileToUpload.name 
        : isLab
          ? `Biochemistry_Lab_Report_0${docIndex}.png`
          : `OPD_Doctor_Prescription_0${docIndex}.png`;

      // Create blob if file is not directly provided
      const uploadBlob = fileToUpload || new Blob([`Scanned Prescription Content ${docIndex}`], { type: 'image/png' });

      try {
        const res = await uploadDocument(patient.id, uploadBlob, docName);
        if (res.document && res.timelineEvent) {
          const updatedDocs = [res.document, ...(patient.documents || [])];
          const updatedTimeline = [res.timelineEvent, ...(patient.timeline || [])];
          onUpdatePatient({
            documents: updatedDocs,
            timeline: updatedTimeline
          });
        }
        audioService.playBeep('success');
      } catch (err) {
        console.error("Upload error:", err);
      } finally {
        setIsUploading(false);
      }
    }, 600);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleCaptureDocument(file);
    }
  };

  const handleDeleteDoc = (id: string) => {
    audioService.playBeep('click');
    const filtered = (patient.documents || []).filter(d => d.id !== id);
    onUpdatePatient({ documents: filtered });
  };

  return (
    <div id="scan-step-container" className="w-full max-w-5xl mx-auto flex flex-col gap-6 animate-fadeIn pb-8 select-none">
      
      {/* Step Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-teal-950/60 border border-teal-800 text-teal-400 text-[10px] font-mono uppercase font-bold tracking-widest mb-2">
          Step 03 / 04 • Real Medical OCR & Prescription Parsing
        </div>
        <h1 className="text-2xl md:text-3xl font-bold font-serif text-slate-100">
          {t.docDigitization}
        </h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Digitize printed and handwritten doctor prescriptions, discharge summaries, and biochemistry lab reports using Gemini Multimodal OCR.
        </p>
      </div>

      {/* Main Grid: Scanner Bed & Document Stack */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Interactive Kiosk Camera Scanner View */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          
          {/* Scanner Viewfinder Box */}
          <div className={`relative h-88 rounded-2xl overflow-hidden bg-slate-950 text-white flex flex-col items-center justify-center p-6 border-2 transition-all shadow-2xl ${
            isCapturing ? 'border-teal-400 bg-teal-950/20 scale-[0.99]' : 'border-dashed border-teal-700/60'
          }`}>
            
            {/* Camera Viewfinder Guides */}
            <div className="absolute inset-5 border border-teal-500/20 rounded-xl pointer-events-none flex flex-col justify-between p-3">
              <div className="flex justify-between">
                <div className="w-5 h-5 border-t-2 border-l-2 border-teal-400" />
                <div className="w-5 h-5 border-t-2 border-r-2 border-teal-400" />
              </div>
              <div className="text-center text-[10px] uppercase font-mono tracking-widest text-teal-400/70 bg-slate-950/80 px-3 py-1 rounded-full mx-auto border border-teal-800/40">
                [ MULTIMODAL MEDICAL OCR ACTIVE • HANDWRITING & PRINTED SCRIPT ]
              </div>
              <div className="flex justify-between">
                <div className="w-5 h-5 border-b-2 border-l-2 border-teal-400" />
                <div className="w-5 h-5 border-b-2 border-r-2 border-teal-400" />
              </div>
            </div>

            {/* Document Type Selector (Prescription vs Lab Report) */}
            <div className="absolute top-4 left-4 z-20 flex gap-2">
              <button
                type="button"
                onClick={() => setOcrSampleType('prescription')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
                  ocrSampleType === 'prescription' 
                    ? 'bg-teal-600 text-white border-teal-400' 
                    : 'bg-slate-900/80 text-slate-400 border-slate-700'
                }`}
              >
                Prescription Slip
              </button>
              <button
                type="button"
                onClick={() => setOcrSampleType('lab_report')}
                className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
                  ocrSampleType === 'lab_report' 
                    ? 'bg-teal-600 text-white border-teal-400' 
                    : 'bg-slate-900/80 text-slate-400 border-slate-700'
                }`}
              >
                Lab Blood Report
              </button>
            </div>

            {/* Scanner Center Action */}
            <div className="flex flex-col items-center gap-3 z-10 text-center mt-6">
              <div className="w-16 h-16 rounded-full bg-teal-500/10 border border-teal-500/30 flex items-center justify-center backdrop-blur-sm text-teal-400">
                <Camera className="w-8 h-8 animate-pulse" />
              </div>
              <p className="text-xs text-slate-300 font-medium max-w-xs">
                Position patient's prior prescription slip or blood test report onto the kiosk scanning bed.
              </p>

              <div className="flex items-center gap-3 mt-2">
                <button
                  id="btn-scan-capture"
                  disabled={isUploading}
                  onClick={() => handleCaptureDocument()}
                  className="px-6 h-11 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  {isUploading ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Extracting OCR Entities...</span>
                    </>
                  ) : (
                    <>
                      <Camera className="w-4 h-4" />
                      <span>Scan Document</span>
                    </>
                  )}
                </button>

                {/* File Upload from Disk / Mobile Camera */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileInputChange}
                  accept="image/*,.pdf"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 h-11 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-all"
                  title="Upload Image/PDF from device"
                >
                  <Upload className="w-4 h-4 text-teal-400" />
                  <span>Upload File</span>
                </button>
              </div>
            </div>
          </div>

          {/* Compliance & DPDP Act 2023 Minimization Footer */}
          <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              <strong>DPDP Act 2023 Data Minimization:</strong> Raw images are converted into structured clinical entities (medications, dosages, lab results) and binary scans are automatically purged after the OPD session.
            </span>
          </div>
        </div>

        {/* Right Column: Captured Documents Stack & Entity Extraction Preview */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col h-full justify-between backdrop-blur-md">
            <div>
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center gap-2 font-serif font-bold text-sm text-slate-100">
                  <Layers className="w-4 h-4 text-teal-400" />
                  <span>Digitized Clinical Records ({patient.documents?.length || 0})</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/50">
                  OCR Reconciled
                </span>
              </div>

              {/* Stack List */}
              <div className="space-y-2.5 overflow-y-auto max-h-72 pr-1">
                {patient.documents && patient.documents.length > 0 ? (
                  patient.documents.map((doc, idx) => (
                    <div
                      key={doc.id || idx}
                      className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between text-xs transition-all hover:border-slate-700"
                    >
                      <div className="flex items-center gap-2.5 overflow-hidden">
                        <FileCheck2 className="w-5 h-5 text-teal-400 shrink-0" />
                        <div className="truncate">
                          <div className="font-bold text-slate-200 truncate flex items-center gap-1.5">
                            <span>{doc.name}</span>
                            {doc.ocrConfidence && (
                              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-teal-950 text-teal-300 border border-teal-800">
                                {doc.ocrConfidence}% OCR
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-2">
                            <span>{doc.pages} • {doc.size}</span>
                            {doc.isHandwritten && (
                              <span className="text-amber-400 font-semibold">• Handwritten Script</span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 ml-2">
                        <button
                          onClick={() => setSelectedDocPreview(doc)}
                          className="p-1.5 text-slate-400 hover:text-teal-300 hover:bg-slate-800 rounded-lg transition-colors"
                          title="View extracted clinical entities"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteDoc(doc.id)}
                          className="p-1.5 text-rose-400 hover:bg-rose-950/60 rounded-lg transition-colors"
                          title="Remove document"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-10 text-center text-xs text-slate-500 italic">
                    No documents digitized yet. Tap "Scan Document" or "Upload File" above to extract prior prescriptions.
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            <button
              id="btn-proceed-summary"
              onClick={() => {
                audioService.playBeep('click');
                onProceedToSummary();
              }}
              className="mt-4 w-full h-12 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
            >
              <span>Review Complete Intake Summary →</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* MODAL: OCR Extracted Text & Structured Entities Preview */}
      {selectedDocPreview && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-slate-900 rounded-2xl p-6 max-w-lg w-full border border-slate-700 shadow-2xl animate-fadeIn text-slate-100 max-h-[85vh] overflow-y-auto">
            
            <div className="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
              <h3 className="font-serif font-bold text-base text-slate-100 flex items-center gap-2">
                <FileText className="w-5 h-5 text-teal-400" />
                <span>Extracted Medical Information</span>
              </h3>
              <button
                onClick={() => setSelectedDocPreview(null)}
                className="text-xs font-bold text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            {/* Document Header & Confidence */}
            <div className="flex items-center justify-between bg-slate-950 p-3 rounded-xl border border-slate-800 mb-4 text-xs">
              <div>
                <span className="font-semibold text-slate-200">{selectedDocPreview.name}</span>
                <div className="text-[11px] text-slate-400">Type: {selectedDocPreview.type}</div>
              </div>
              <div className="text-right">
                <span className="text-teal-400 font-bold font-mono text-sm">{selectedDocPreview.ocrConfidence || 94}%</span>
                <div className="text-[10px] text-slate-400">Confidence Score</div>
              </div>
            </div>

            {/* Structured Medications */}
            {selectedDocPreview.structuredMeds && selectedDocPreview.structuredMeds.length > 0 && (
              <div className="mb-4">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-400 mb-2 flex items-center gap-1.5">
                  <Stethoscope className="w-3.5 h-3.5" />
                  <span>Prescribed Medications ({selectedDocPreview.structuredMeds.length}):</span>
                </div>
                <div className="space-y-2">
                  {selectedDocPreview.structuredMeds.map((med: any, idx: number) => (
                    <div key={idx} className="bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 text-xs">
                      <div className="flex justify-between font-bold text-slate-200">
                        <span>{med.medicine} ({med.dosage})</span>
                        <span className="text-teal-400 font-mono text-[11px]">{med.frequency}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 flex justify-between">
                        <span>Duration: {med.duration} • {med.instructions}</span>
                        {med.isUncertain && (
                          <span className="text-amber-400 font-semibold">⚠️ Low Handwriting Confidence</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Structured Lab Values */}
            {selectedDocPreview.structuredLabs && selectedDocPreview.structuredLabs.length > 0 && (
              <div className="mb-4">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-400 mb-2">
                  Lab Test Results ({selectedDocPreview.structuredLabs.length}):
                </div>
                <div className="space-y-1.5">
                  {selectedDocPreview.structuredLabs.map((lab: any, idx: number) => (
                    <div key={idx} className="bg-slate-950/80 p-2 rounded-lg border border-slate-800 text-xs flex justify-between items-center">
                      <div>
                        <div className="font-semibold text-slate-200">{lab.test}</div>
                        <div className="text-[10px] text-slate-400">Ref Range: {lab.refRange}</div>
                      </div>
                      <div className="text-right">
                        <span className={`font-mono font-bold ${lab.status === 'High' || lab.status === 'Critical' ? 'text-rose-400' : 'text-emerald-400'}`}>
                          {lab.value} {lab.unit}
                        </span>
                        <span className={`block text-[10px] uppercase font-bold ${lab.status === 'High' ? 'text-rose-400' : 'text-slate-400'}`}>
                          {lab.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Raw OCR Text */}
            <div className="mt-4">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Full OCR Digitized Text:</div>
              <p className="text-xs text-slate-300 font-mono bg-slate-950 p-3 rounded-xl border border-slate-800 leading-relaxed whitespace-pre-wrap">
                {selectedDocPreview.extractedText || "Document parsed and indexed."}
              </p>
            </div>

            <button
              onClick={() => setSelectedDocPreview(null)}
              className="mt-5 w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition-all"
            >
              Close Record
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
