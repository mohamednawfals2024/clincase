import React from 'react';
import { AlertTriangle, Clock, ShieldAlert, HeartPulse } from 'lucide-react';
import { LanguageCode } from '../types';
import { translations } from '../data/translations';

interface EmergencyOverlayProps {
  lang: LanguageCode;
  kioskId?: string;
  sessionId?: string;
  onDismissManual?: () => void;
}

export const EmergencyOverlay: React.FC<EmergencyOverlayProps> = ({
  lang,
  kioskId = 'Kiosk-01',
  sessionId = 'MED-49201',
  onDismissManual
}) => {
  const t = translations[lang] || translations.en;

  return (
    <div className="fixed inset-0 z-[100] bg-[#BA1A1A] text-white flex flex-col items-center justify-center p-6 select-none animate-fadeIn">
      <div className="text-center max-w-xl mx-auto space-y-6">
        {/* Pulsing Alert Icon */}
        <div className="w-24 h-24 rounded-full bg-white text-[#BA1A1A] flex items-center justify-center mx-auto shadow-2xl animate-bounce">
          <HeartPulse className="w-12 h-12 text-[#BA1A1A]" />
        </div>

        <div>
          <h1 className="text-3xl md:text-4xl font-bold font-serif">
            {t.nurseAlertTitle}
          </h1>
          <p className="text-lg text-white/90 font-medium mt-2">
            {t.nurseAlertSubtitle}
          </p>
          <p className="text-xs text-white/75 mt-1">
            {t.alertSentNotice}
          </p>
        </div>

        {/* Live Status Holding Banner */}
        <div className="p-4 bg-white/10 rounded-2xl border border-white/20 backdrop-blur-xs space-y-2">
          <div className="flex items-center justify-center gap-2 text-sm font-bold tracking-wide text-white">
            <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
            <span>Waiting for Nurse / Attendant to Arrive & Release Kiosk...</span>
          </div>
          <p className="text-xs font-mono text-white/70">
            {kioskId} • Session ID: {sessionId}
          </p>
        </div>

        {/* Manual Dev Dismiss Button (for demo recovery) */}
        {onDismissManual && (
          <div className="pt-4">
            <button
              onClick={onDismissManual}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-[11px] font-bold uppercase tracking-wider border border-white/20 transition-colors"
            >
              Simulate Nurse Arrival (Dismiss Alert)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
