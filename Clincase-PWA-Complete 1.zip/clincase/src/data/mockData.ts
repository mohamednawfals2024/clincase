import { 
  PatientSession, 
  VitalSigns, 
  Allergy, 
  LabResult, 
  TimelineEvent, 
  DocumentRecord, 
  Prescription,
  PatientAppointment,
  PatientVisitRecord
} from '../types';

export const initialVitals: VitalSigns = {
  temp: "99.4 °F",
  bp: "124/82 mmHg",
  hr: "78 bpm",
  spo2: "98%",
  respRate: "16 bpm"
};

export const initialAllergies: Allergy[] = [
  { name: "Penicillin", reaction: "Severe - Anaphylaxis / Bronchospasm (2018)", severity: "Severe" },
  { name: "Sulfa Drugs", reaction: "Mild - Urticarial skin rash (2021)", severity: "Moderate" }
];

export const initialLabResults: LabResult[] = [
  { test: "Complete Blood Count (WBC)", result: "11,800 /µL", refRange: "4,500 - 11,000", status: "High" },
  { test: "Serum Bilirubin (Total)", result: "1.4 mg/dL", refRange: "0.2 - 1.2", status: "High" },
  { test: "Serum Creatinine", result: "0.9 mg/dL", refRange: "0.7 - 1.3", status: "Normal" },
  { test: "Blood Glucose (Random)", result: "138 mg/dL", refRange: "70 - 140", status: "Normal" },
  { test: "Urinalysis (Pus Cells)", result: "2-3 /HPF", refRange: "0 - 5", status: "Normal" }
];

export const initialDocuments: DocumentRecord[] = [
  {
    id: "doc-1",
    name: "Prescription_01_DrRao.pdf",
    pages: "1 Page",
    size: "1.2 MB",
    type: "prescription",
    url: "/assets/documents/prescription_01.pdf",
    timestamp: "Today, 10:14 AM",
    extractedText: "Rx: Tab. Paracetamol 650mg TDS x 3d, Tab. Pantoprazole 40mg OD AC x 5d. Advice: USG Abdomen if pain persists.",
    extractedMeds: ["Paracetamol 650mg", "Pantoprazole 40mg"],
    extractedDiagnoses: ["Acute Gastritis", "Pyrexia of Unknown Origin"]
  },
  {
    id: "doc-2",
    name: "Lab_Report_Hemogram.pdf",
    pages: "2 Pages",
    size: "2.4 MB",
    type: "lab_report",
    url: "/assets/documents/lab_report.pdf",
    timestamp: "Today, 10:15 AM",
    extractedText: "Automated Hematology Analyzer: WBC Count elevated 11.8k/uL with neutrophilia (78%). Platelets adequate 240k/uL.",
    extractedMeds: [],
    extractedDiagnoses: ["Leukocytosis"]
  }
];

export const initialTimeline: TimelineEvent[] = [
  { id: "tl-1", date: "Today, 10:15 AM", title: "Lab_Report_Hemogram.pdf", type: "lab", summary: "CBC shows mild leukocytosis (11,800/uL)" },
  { id: "tl-2", date: "Today, 10:14 AM", title: "Prescription_01_DrRao.pdf", type: "prescription", summary: "Anti-pyretic & PPI prescribed at primary clinic" },
  { id: "tl-3", date: "12-Jan-2024", title: "Previous OPD Consultation Summary", type: "clinical", summary: "Routine diabetic check-up; HbA1c 6.8%" }
];

export const initialPrescriptions: Prescription[] = [
  {
    id: "rx-1",
    medicine: "Tab. Paracetamol",
    dosage: "650 mg",
    frequency: "TDS (1-1-1)",
    duration: "3 Days",
    instructions: "Take after meals if body temp exceeds 100°F"
  },
  {
    id: "rx-2",
    medicine: "Tab. Pantoprazole",
    dosage: "40 mg",
    frequency: "OD (1-0-0)",
    duration: "5 Days",
    instructions: "Take 30 minutes before breakfast with warm water"
  },
  {
    id: "rx-3",
    medicine: "Tab. Metformin",
    dosage: "500 mg",
    frequency: "BD (1-0-1)",
    duration: "30 Days",
    instructions: "With breakfast and dinner for glycemic control"
  }
];

export const initialAppointments: PatientAppointment[] = [
  {
    id: "apt-101",
    doctorName: "Dr. Arvind Varma, MD (General Medicine)",
    department: "General Medicine OPD",
    specialty: "Internal Medicine & Diabetes",
    date: "Tomorrow, 10:30 AM",
    time: "10:30 AM - 11:00 AM",
    type: "In-Person OPD",
    status: "Confirmed",
    tokenNumber: "OPD-G-042",
    roomNumber: "Room 108, First Floor, Wing B",
    notes: "Follow-up for acute right iliac fossa pain and CBC elevation.",
    instructions: "Arrive 15 minutes early. Bring recent ultrasound report if completed."
  },
  {
    id: "apt-102",
    doctorName: "Vaidya Rajeshwari Sharma, BAMS, MD (Ayur)",
    department: "AYUSH Kayachikitsa & Panchakarma",
    specialty: "Ayurvedic Internal Medicine",
    date: "In 3 Days (Monday, 02:00 PM)",
    time: "02:00 PM - 02:45 PM",
    type: "AYUSH Evaluation",
    status: "Scheduled",
    tokenNumber: "AYU-K-019",
    roomNumber: "AYUSH Block, Cabin 04",
    notes: "Prakriti assessment, Pitta-Ama pacification protocol, and Dashavidha Pariksha follow-up.",
    instructions: "Avoid heavy spicy meals 2 hours prior to Nadi Pariksha examination."
  },
  {
    id: "apt-103",
    doctorName: "Dr. Neha Kulkarni, MS (General Surgery)",
    department: "Surgical Gastroenterology OPD",
    specialty: "Gastrointestinal & Laparoscopy",
    date: "Next Week (Thursday, 11:15 AM)",
    time: "11:15 AM - 11:45 AM",
    type: "In-Person OPD",
    status: "Scheduled",
    tokenNumber: "SURG-B-08",
    roomNumber: "Room 214, Second Floor, Wing A",
    notes: "Surgical evaluation if RLQ tenderness does not resolve with conservative management.",
    instructions: "Fast overnight if fasting abdominal ultrasound is requested."
  }
];

export const initialPastVisits: PatientVisitRecord[] = [
  {
    id: "vis-201",
    date: "Today, 10:14 AM",
    doctorName: "Dr. Arvind Varma, MD",
    department: "Emergency & OPD Triage",
    hospitalOrClinic: "City Public Health Hospital (ABDM ID: 91-4528)",
    diagnosis: ["Acute Abdominal Pain (RLQ)", "Pyrexia of Unknown Origin", "Mild Leukocytosis"],
    chiefComplaint: "Acute right lower quadrant abdominal cramping pain with low grade fever (100.2°F).",
    treatmentType: "Allopathic",
    vitalsSummary: "BP: 124/82 mmHg | HR: 78 bpm | SpO2: 98% | Temp: 99.4°F",
    prescriptions: ["Tab. Paracetamol 650mg TDS x 3d", "Tab. Pantoprazole 40mg OD AC x 5d"],
    clinicalSummary: "Patient evaluated at Kiosk triage. Physical exam showed localized tenderness at McBurney's point without rebound rigidity. CBC ordered and anti-pyretic initiated.",
    followUpDate: "Tomorrow, 10:30 AM",
    attachmentsCount: 2
  },
  {
    id: "vis-202",
    date: "12-Jan-2024 (6 weeks ago)",
    doctorName: "Dr. S. K. Nambiar, MD (Endo)",
    department: "Diabetes & Endocrinology Clinic",
    hospitalOrClinic: "Apex Specialty Diabetic Center",
    diagnosis: ["Type-2 Diabetes Mellitus (Controlled)", "Essential Hypertension (Stage 1)"],
    chiefComplaint: "Quarterly routine diabetic review and prescription refill.",
    treatmentType: "Allopathic",
    vitalsSummary: "BP: 128/84 mmHg | HR: 72 bpm | SpO2: 99% | Weight: 74 kg",
    prescriptions: ["Tab. Metformin 500mg BD x 90d", "Cap. Vitamin D3 60k IU Once/Week"],
    clinicalSummary: "HbA1c steady at 6.8%. Fasting glucose 112 mg/dL. Renal profile within normal parameters. Advised continuous 30 min daily brisk walk and moderate carbohydrate restriction.",
    followUpDate: "12-Apr-2024",
    attachmentsCount: 1
  },
  {
    id: "vis-203",
    date: "04-Nov-2023 (4 months ago)",
    doctorName: "Vaidya Rajeshwari Sharma, BAMS",
    department: "AYUSH Holistic Wellness Center",
    hospitalOrClinic: "National Institute of Ayurveda OPD",
    diagnosis: ["Amlapitta (Hyperacidity)", "Vata-Pitta Imbalance"],
    chiefComplaint: "Recurrent post-prandial heartburn and bloating after irregular working hours.",
    treatmentType: "AYUSH",
    vitalsSummary: "Nadi: Pitta-Pradhana | Agni: Mandagni | Tongue: Mild Samata",
    prescriptions: ["Avipattikar Churna 3g BD with warm water", "Kamadudha Rasa (Mukta Yukta) 1 tab BD"],
    clinicalSummary: "Dashavidha Pariksha revealed Pitta aggravation exacerbated by delayed meals and work-related stress. Prescribed cooling dietetic regimen and Triphala herbal rasayana.",
    followUpDate: "As needed",
    attachmentsCount: 1
  }
];

export const defaultPatient: PatientSession = {
  id: "MED-49201",
  abhaId: "91-4528-9021-0044",
  name: "John Doe",
  gender: "Male",
  age: 45,
  dob: "15-May-1979",
  phone: "9876543210",
  consentGiven: true,
  currentStep: 1,
  symptoms: ["Fever (2 Days)", "Right Lower Quadrant Pain", "Mild Nausea"],
  chiefComplaintDetails: "Patient states severe cramping pain in the right lower abdomen starting yesterday evening, accompanied by moderate fever (100.2°F), dry mouth, and loss of appetite.",
  hpiDetails: "45-year-old male with 3-year history of Type-2 DM presents with acute onset right lower abdominal pain (VAS 6/10) for 36 hours. Symptoms started post-prandial with low-grade fever and mild chills. Denies hematemesis, melena, or dysuria. Previously took OTC paracetamol with transient relief.",
  pastHistoryDetails: "Known Type-2 Diabetes Mellitus x 3 years on Metformin 500mg BD. Well-controlled (last HbA1c 6.8%). Mild essential hypertension on diet control. No previous surgeries.",
  familyHistoryDetails: "Father deceased at age 58 due to acute myocardial infarction; mother (72) has hypertension and osteoarthritis. No known familial cancer history.",
  lifestyleDetails: "Vegetarian diet, non-smoker, non-alcoholic. Sedentary IT desk occupation, regular 30-minute evening walk, sleeps 6-7 hours.",
  vitals: initialVitals,
  allergies: initialAllergies,
  labResults: initialLabResults,
  timeline: initialTimeline,
  documents: initialDocuments,
  prescriptions: initialPrescriptions,
  appointments: initialAppointments,
  pastVisits: initialPastVisits,
  consultType: "allopathic",
  status: "active",
  ayushDetails: {
    Prakriti: "Vata-Pitta Dwandwaja (Lean muscular build, warm extremities, alert)",
    Vikriti: "Pitta Aggravation (Amlapitta - burning sensation, stomach heat, feverishness)",
    Sara: "Rakta-Mamsa Sara (Healthy blood and muscle tone, clear eyes)",
    Samhanana: "Susamhata (Compact and well-formed bone-joint structure)",
    Pramana: "Sama Pramana (Normal anthropometric proportions)",
    Satmya: "Madhyama Satmya (Suited to warm cooked foods, cow ghee, green gram)",
    Sattva: "Pravara Sattva (High emotional resilience, calm demeanor)",
    "Ahara Shakti": "Madhyama Abhyavaharana / Mandagni (Reduced appetite due to Pitta-Ama)",
    "Vyayama Shakti": "Madhyama Vyayama Shakti (Walks 30 mins daily)",
    Vaya: "Madhyama Vaya (45 years old, active working age)",
    "Ahara-Vihara": "Vegetarian diet, tea twice daily, sleeps 6.5 hours, works regular shifts."
  },
  createdAt: new Date().toISOString()
};
