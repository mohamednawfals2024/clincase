import React, { useState } from 'react';
import { 
  Building2, 
  Stethoscope, 
  AlertTriangle, 
  HelpCircle, 
  FileCode2, 
  ShieldCheck, 
  MonitorSmartphone,
  Palette,
  Check,
  Sparkles,
  Home,
  User,
  LogOut,
  Lock,
  Cloud,
  Wifi,
  WifiOff,
  RefreshCw
} from 'lucide-react';
import { ConsultType, ThemeMode } from '../types';

interface HeaderProps {
  currentView: string;
  onSelectView: (view: string) => void;
  onOpenAssistance: () => void;
  onOpenFhir: () => void;
  onOpenSecurity?: () => void;
  onOpenFirebaseSync?: () => void;
  onGoHome?: () => void;
  consultType: ConsultType;
  activeAlertsCount: number;
  currentTheme: ThemeMode;
  onSelectTheme: (theme: ThemeMode) => void;
  authRole: 'guest' | 'doctor' | 'admin';
  authName?: string;
  onLogout: () => void;
  isOnline?: boolean;
  pendingSyncCount?: number;
  onTriggerSync?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onSelectView,
  onOpenAssistance,
  onOpenFhir,
  onOpenSecurity,
  onOpenFirebaseSync,
  onGoHome,
  consultType,
  activeAlertsCount,
  currentTheme,
  onSelectTheme,
  authRole,
  authName,
  onLogout,
  isOnline = true,
  pendingSyncCount = 0,
  onTriggerSync
}) => {
  const [showThemeMenu, setShowThemeMenu] = useState(false);

  const themeOptions: { id: ThemeMode; name: string; tag: string; dotColor: string }[] = [
    { id: 'clinical-teal', name: 'Clinical Teal', tag: 'Modern Hospital Dark', dotColor: 'bg-teal-400' },
    { id: 'midnight-ocean', name: 'Midnight Ocean', tag: 'Deep Blue Night Shift', dotColor: 'bg-blue-400' },
    { id: 'healing-sage', name: 'Healing Sage', tag: 'AYUSH Nature Wellness', dotColor: 'bg-emerald-400' },
    { id: 'clean-ivory', name: 'Daylight Linen', tag: 'High-Visibility Crisp EMR', dotColor: 'bg-amber-300' }
  ];

  return (
    <header className="bg-[#070B14] text-[#F1F5F9] flex items-center justify-between px-4 md:px-8 h-16 w-full z-40 shadow-md border-b border-slate-800 shrink-0">
      {/* Brand Identity & Title */}
      <div className="flex items-center gap-3 md:gap-4">
        <button 
          onClick={onGoHome} 
          className="flex items-center gap-2 text-left hover:opacity-90 transition-opacity cursor-pointer"
          title="Return to Home & Medication Choice Screen"
        >
          <div className="w-8 h-8 rounded-lg bg-teal-500 text-slate-950 flex items-center justify-center font-bold font-mono text-sm shadow-inner">
            CC
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg md:text-xl font-bold tracking-tight font-sans text-white">
                CLINCASE
              </span>
              <span className="text-[9px] uppercase tracking-[0.2em] text-teal-400 font-bold">
                OPD_AI
              </span>
            </div>
            <div className="text-[9px] text-slate-400 tracking-wide hidden sm:block">
              {consultType === 'ayush' ? 'Ministry of AYUSH • Dashavidha Pariksha Intake' : 'Institutional OPD Intake & Clinical Intelligence'}
            </div>
          </div>
        </button>

        {/* Home Button */}
        {onGoHome && (
          <button
            onClick={onGoHome}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 transition-all shadow-xs"
            title="Return to Medication Choice Home Page"
          >
            <Home className="w-3.5 h-3.5 text-teal-400" />
            <span className="text-[11px]">Home</span>
          </button>
        )}

        {/* View Badges */}
        {currentView === 'patient_dashboard' && (
          <div className="hidden lg:flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-bold text-sky-400 bg-sky-500/10 px-3 py-1 rounded-md border border-sky-500/30">
            <User className="w-3.5 h-3.5 text-sky-400" />
            Patient Health Dashboard
          </div>
        )}
        {currentView === 'physician' && (
          <div className="hidden lg:flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-bold text-teal-400 bg-teal-500/10 px-3 py-1 rounded-md border border-teal-500/30">
            <Stethoscope className="w-3.5 h-3.5 text-teal-400" />
            Physician Workstation
          </div>
        )}
        {currentView === 'triage' && (
          <div className="hidden lg:flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-md border border-amber-500/30">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            Duty-Station Triage
          </div>
        )}
      </div>

      {/* Action Buttons & Role Dashboard Switcher */}
      <div className="flex items-center gap-1.5 md:gap-2">
        {/* Role Tab Switcher Group */}
        <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800 shadow-inner">
          {/* User / Patient Dashboard */}
          <button
            onClick={() => onSelectView('patient_dashboard')}
            className={`flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
              currentView === 'patient_dashboard' || currentView === 'kiosk'
                ? 'bg-sky-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title="User / Patient Health Portal & OPD Kiosk"
          >
            <User className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">User Dashboard</span>
            <span className="sm:hidden">User</span>
          </button>

          {/* Doctor / Physician Dashboard */}
          <button
            onClick={() => onSelectView('physician')}
            className={`flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
              currentView === 'physician'
                ? 'bg-teal-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title="Doctor Clinical Workstation & EMR Summary"
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Doctor</span>
            <span className="sm:hidden">MD</span>
          </button>

          {/* Nurse Triage Console */}
          <button
            onClick={() => onSelectView('triage')}
            className={`flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
              currentView === 'triage'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title="Duty Nurse Triage Station"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Triage</span>
            <span className="sm:hidden">Alerts</span>
            {activeAlertsCount > 0 && (
              <span className="px-1.5 py-0.2 bg-red-600 text-white font-mono font-bold text-[10px] rounded-full animate-bounce">
                {activeAlertsCount}
              </span>
            )}
          </button>

          {/* Hospital Admin Console */}
          <button
            onClick={() => onSelectView('admin')}
            className={`flex items-center gap-1.5 px-2.5 md:px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
              currentView === 'admin'
                ? 'bg-amber-400 text-slate-950 font-bold shadow-md'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title="Hospital Admin Security & Audit Console"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Admin</span>
            <span className="sm:hidden">Sec</span>
          </button>
        </div>

        {/* Live Network & Offline/Online Sync Status Pill */}
        <div 
          onClick={onTriggerSync}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer shadow-xs ${
            isOnline
              ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
              : 'bg-amber-500/15 text-amber-300 border-amber-500/40 hover:bg-amber-500/25 animate-pulse'
          }`}
          title={isOnline ? "Online • Cloud & Local Database Synced" : "Offline Mode Active • Local Storage & Rule Engine Enabled. Click to Sync."}
        >
          {isOnline ? (
            <>
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px] hidden sm:inline">Online</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            </>
          ) : (
            <>
              <WifiOff className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-[11px] hidden sm:inline">Offline</span>
              {pendingSyncCount > 0 ? (
                <span className="px-1.5 py-0.2 bg-amber-400 text-slate-950 font-bold rounded-full text-[10px]">
                  {pendingSyncCount}
                </span>
              ) : null}
            </>
          )}
        </div>

        {/* Theme Selector Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowThemeMenu(!showThemeMenu)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all shadow-xs cursor-pointer"
            title="Change Visual Theme"
          >
            <Palette className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden xl:inline text-[11px]">Theme</span>
            <span className="w-2 h-2 rounded-full bg-teal-400"></span>
          </button>

          {showThemeMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 z-50 animate-fadeIn">
              <div className="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 flex items-center justify-between">
                <span>Select Background Theme</span>
                <Sparkles className="w-3 h-3 text-teal-400" />
              </div>
              <div className="space-y-1 mt-1">
                {themeOptions.map((opt) => {
                  const isActive = currentTheme === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => {
                        onSelectTheme(opt.id);
                        setShowThemeMenu(false);
                      }}
                      className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-all ${
                        isActive
                          ? 'bg-slate-800 text-white font-bold border border-teal-500/40'
                          : 'hover:bg-slate-800/60 text-slate-300 text-xs'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${opt.dotColor}`} />
                        <div>
                          <div className="text-xs">{opt.name}</div>
                          <div className="text-[10px] text-slate-400 font-normal">{opt.tag}</div>
                        </div>
                      </div>
                      {isActive && <Check className="w-4 h-4 text-teal-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Firebase Cloud Sync Button */}
        {onOpenFirebaseSync && (
          <button
            onClick={onOpenFirebaseSync}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-orange-300 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 transition-all cursor-pointer shadow-xs"
            title="Firebase Firestore Cloud Data Synchronization"
          >
            <Cloud className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-[11px] hidden sm:inline">Firebase Sync</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
          </button>
        )}

        {/* FHIR Export Modal Button */}
        <button
          onClick={onOpenFhir}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors border border-transparent hover:border-slate-700"
          title="View FHIR R4 Bundle & ABDM Health Records"
        >
          <FileCode2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-[11px] font-mono uppercase tracking-wider">FHIR R4</span>
        </button>

        {/* Active Auth Role Session Badge & Logout Button */}
        {authRole !== 'guest' ? (
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 px-2.5 py-1 rounded-xl">
            <span className={`text-[10px] font-bold uppercase tracking-wider font-mono px-2 py-0.5 rounded ${
              authRole === 'doctor' ? 'bg-teal-500/20 text-teal-300' : 'bg-amber-500/20 text-amber-300'
            }`}>
              {authRole === 'doctor' ? '🩺 Doctor' : '🛡️ Admin'}
            </span>
            <span className="text-[11px] font-semibold text-white hidden xl:inline">
              {authName || authRole}
            </span>
            <button
              onClick={onLogout}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Logout of Role Session"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => onSelectView('physician')}
            className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all cursor-pointer"
            title="Doctor / Admin Staff Login"
          >
            <Lock className="w-3.5 h-3.5 text-teal-400" />
            <span>Staff Login</span>
          </button>
        )}

        {/* Call for Assistance Button */}
        <button
          onClick={onOpenAssistance}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <HelpCircle className="w-3.5 h-3.5 text-teal-400" />
          <span className="hidden md:inline">Assistance</span>
        </button>
      </div>
    </header>
  );
};
