import struct
import zlib
import os
import math

def write_png(filename, width, height, pixels):
    """
    Writes a 32-bit RGBA PNG image without external dependencies.
    pixels: list of (R, G, B, A) tuples of length width * height
    """
    def make_chunk(chunk_type, data):
        return (
            struct.pack(">I", len(data)) +
            chunk_type +
            data +
            struct.pack(">I", zlib.crc32(chunk_type + data) & 0xffffffff)
        )

    header = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    ihdr_chunk = make_chunk(b"IHDR", ihdr)

    # Scanlines with filter byte 0 (None)
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0)  # Filter type 0
        for x in range(width):
            r, g, b, a = pixels[y * width + x]
            raw_data.extend((r, g, b, a))

    compressed = zlib.compress(bytes(raw_data), level=9)
    idat_chunk = make_chunk(b"IDAT", compressed)
    iend_chunk = make_chunk(b"IEND", b"")

    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, "wb") as f:
        f.write(header + ihdr_chunk + idat_chunk + iend_chunk)

def draw_clincase_icon(size, is_maskable=False):
    width = size
    height = size
    pixels = []

    # Colors
    bg_teal_top = (20, 184, 166)    # #14B8A6
    bg_teal_mid = (13, 148, 136)    # #0D9488
    bg_teal_bot = (4, 47, 46)       # #042F2E
    dark_navy = (7, 11, 20)         # #070B14
    white = (255, 255, 255)
    cyan_bright = (94, 234, 212)    # #5EEAD4
    teal_dark = (15, 118, 110)

    # Corner radius for standard vs maskable
    radius = 0 if is_maskable else size * 0.22

    for y in range(height):
        ny = y / (height - 1) if height > 1 else 0
        for x in range(width):
            nx = x / (width - 1) if width > 1 else 0

            # Compute rounded rectangle mask
            inside_rounded_rect = True
            if not is_maskable:
                # Check corners
                cx = radius if x < radius else (width - 1 - radius if x >= width - radius else x)
                cy = radius if y < radius else (height - 1 - radius if y >= height - radius else y)
                dist = math.hypot(x - cx, y - cy)
                if (x < radius or x >= width - radius) and (y < radius or y >= height - radius):
                    if dist > radius:
                        inside_rounded_rect = False

            if not inside_rounded_rect:
                pixels.append((0, 0, 0, 0))
                continue

            # Diagonal gradient factor
            diag = (nx + ny) / 2.0
            r = int(bg_teal_top[0] * (1 - diag) + bg_teal_bot[0] * diag)
            g = int(bg_teal_top[1] * (1 - diag) + bg_teal_bot[1] * diag)
            b = int(bg_teal_top[2] * (1 - diag) + bg_teal_bot[2] * diag)
            a = 255

            # Border glow
            if not is_maskable and (x < 3 or x >= width - 3 or y < 3 or y >= height - 3):
                r = int(r * 0.7 + cyan_bright[0] * 0.3)
                g = int(g * 0.7 + cyan_bright[1] * 0.3)
                b = int(b * 0.7 + cyan_bright[2] * 0.3)

            # Center coordinates normalized (-1 to 1)
            cx_n = (x - width / 2) / (width / 2)
            cy_n = (y - height / 2) / (height / 2)

            # Safe area scaling for maskable
            scale = 0.75 if is_maskable else 0.9
            sx = cx_n / scale
            sy = cy_n / scale

            # 1. Medical Cross (Upper center)
            cross_cy = sy + 0.15
            in_v_bar = abs(sx) <= 0.14 and abs(cross_cy) <= 0.45
            in_h_bar = abs(sx) <= 0.45 and abs(cross_cy) <= 0.14

            if in_v_bar or in_h_bar:
                r = 255
                g = 255
                b = 255

            # 2. Medical Pulse waveform over the cross
            # Path points approximate: (-0.45, 0) -> (-0.2, 0) -> (-0.1, -0.22) -> (0.0, 0.25) -> (0.1, -0.15) -> (0.2, 0) -> (0.45, 0)
            if abs(cross_cy) <= 0.35 and abs(sx) <= 0.45:
                target_y = 0.0
                if -0.45 <= sx < -0.2:
                    target_y = 0.0
                elif -0.2 <= sx < -0.1:
                    target_y = -0.22 * (sx - (-0.2)) / 0.1
                elif -0.1 <= sx < 0.0:
                    target_y = -0.22 + 0.47 * (sx - (-0.1)) / 0.1
                elif 0.0 <= sx < 0.1:
                    target_y = 0.25 - 0.40 * sx / 0.1
                elif 0.1 <= sx < 0.2:
                    target_y = -0.15 + 0.15 * (sx - 0.1) / 0.1
                elif 0.2 <= sx <= 0.45:
                    target_y = 0.0

                dist_to_pulse = abs(cross_cy - target_y)
                if dist_to_pulse <= 0.04:
                    r = cyan_bright[0]
                    g = cyan_bright[1]
                    b = cyan_bright[2]
                elif dist_to_pulse <= 0.07:
                    r = teal_dark[0]
                    g = teal_dark[1]
                    b = teal_dark[2]

            # 3. Bottom Pill Badge with "CC" Monogram
            badge_y = sy - 0.58
            if abs(badge_y) <= 0.18 and abs(sx) <= 0.55:
                # Inside bottom badge
                r = dark_navy[0]
                g = dark_navy[1]
                b = dark_navy[2]

                # Border around badge
                if abs(badge_y) >= 0.15 or abs(sx) >= 0.52:
                    r = bg_teal_top[0]
                    g = bg_teal_top[1]
                    b = bg_teal_top[2]

                # Draw bold "C C" letters in badge
                # Left C: center at sx = -0.22
                # Right C: center at sx = 0.22
                for offset_x in [-0.22, 0.22]:
                    dx = sx - offset_x
                    dy = badge_y
                    dist_c = math.hypot(dx, dy)
                    if 0.05 <= dist_c <= 0.12:
                        angle = math.atan2(dy, dx)
                        # Open on the right side (angle around 0)
                        if not (-0.6 <= angle <= 0.6):
                            r = 255
                            g = 255
                            b = 255

            # 4. Top Right AI Sparkle
            sparkle_dx = sx - 0.5
            sparkle_dy = sy + 0.6
            dist_sparkle = math.hypot(sparkle_dx, sparkle_dy)
            if dist_sparkle <= 0.045:
                r = cyan_bright[0]
                g = cyan_bright[1]
                b = cyan_bright[2]
            elif dist_sparkle <= 0.08:
                r = int(r * 0.5 + cyan_bright[0] * 0.5)
                g = int(g * 0.5 + cyan_bright[1] * 0.5)
                b = int(b * 0.5 + cyan_bright[2] * 0.5)

            pixels.append((r, g, b, a))

    return pixels

def generate_all_icons(target_dir):
    os.makedirs(target_dir, exist_ok=True)

    icons_to_generate = [
        ("icon-192x192.png", 192, False),
        ("icon-512x512.png", 512, False),
        ("icon-maskable-192x192.png", 192, True),
        ("icon-maskable-512x512.png", 512, True),
        ("apple-touch-icon.png", 180, False),
        ("favicon-32x32.png", 32, False),
        ("favicon-16x16.png", 16, False),
    ]

    for fname, size, is_maskable in icons_to_generate:
        path = os.path.join(target_dir, fname)
        print(f"Generating {fname} ({size}x{size}, maskable={is_maskable})...")
        px = draw_clincase_icon(size, is_maskable=is_maskable)
        write_png(path, size, size, px)
        print(f"Saved {path}")

    # Also save top-level favicon.png
    root_public = os.path.dirname(target_dir)
    write_png(os.path.join(root_public, "favicon.png"), 32, 32, draw_clincase_icon(32, False))
    write_png(os.path.join(root_public, "apple-touch-icon.png"), 180, 180, draw_clincase_icon(180, False))

if __name__ == "__main__":
    out_dir = os.path.join(os.path.dirname(__file__), "public", "icons")
    generate_all_icons(out_dir)
    print("All PWA icons generated successfully!")
