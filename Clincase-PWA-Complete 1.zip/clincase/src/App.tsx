import React, { useState, useEffect } from 'react';
import { 
  Header 
} from './components/Header';
import { HomeMedicationChoice } from './components/HomeMedicationChoice';
import { LanguageSelect } from './components/LanguageSelect';
import { ConsultTypeSelect } from './components/ConsultTypeSelect';
import { IdentifyStep } from './components/IdentifyStep';
import { ConverseStep } from './components/ConverseStep';
import { ScanStep } from './components/ScanStep';
import { SummaryStep } from './components/SummaryStep';
import { PhysicianPortal } from './components/PhysicianPortal';
import { TriageConsole } from './components/TriageConsole';
import { PatientDashboard } from './components/PatientDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { EmergencyOverlay } from './components/EmergencyOverlay';
import { 
  NewPatientModal, 
  WriteRxModal, 
  SupportModal, 
  FhirModal, 
  QrScannerModal 
} from './components/Modals';
import { SecurityConsoleModal } from './components/SecurityConsoleModal';
import { RoleLoginModal } from './components/RoleLoginModal';
import { FirebaseSyncModal } from './components/FirebaseSyncModal';

import { 
  PatientSession, 
  LanguageCode, 
  ConsultType, 
  RedFlagAlert, 
  Prescription,
  ThemeMode 
} from './types';
import { defaultPatient } from './data/mockData';
import { translations } from './data/translations';
import { 
  startSession, 
  getSession, 
  updateSession, 
  getAllPatients,
  triggerRedflag, 
  ackRedflag, 
  audioService 
} from './services/api';
import {
  subscribeToPatientsFromFirestore,
  savePatientToFirestore
} from './services/firebase';
import {
  subscribeToNetworkStatus,
  processOfflineMutationQueue,
  getPendingSyncCount,
  isAppOnline
} from './services/offlineSync';
import { 
  UserCheck, 
  MessageSquare, 
  Camera, 
  FileCheck, 
  AlertOctagon, 
  Building2, 
  ChevronRight,
  Home,
  WifiOff,
  CheckCircle2,
  X
} from 'lucide-react';

export default function App() {
  // Navigation & View States
  const [currentView, setCurrentView] = useState<'kiosk' | 'physician' | 'triage' | 'patient_dashboard' | 'admin'>('kiosk');
  const [kioskStep, setKioskStep] = useState<'home' | 'language' | 'consult_type' | 'identify' | 'converse' | 'scan' | 'summary'>('home');
  const [lang, setLang] = useState<LanguageCode>('en');
  const [consultType, setConsultType] = useState<ConsultType>('allopathic');

  // Role Authentication State
  const [authRole, setAuthRole] = useState<'guest' | 'doctor' | 'admin'>('guest');
  const [authName, setAuthName] = useState<string>('');
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [loginTargetRole, setLoginTargetRole] = useState<'doctor' | 'admin'>('doctor');

  const handleSelectView = (view: string) => {
    if (view === 'physician' && authRole !== 'doctor') {
      setLoginTargetRole('doctor');
      setIsLoginModalOpen(true);
      return;
    }
    if (view === 'admin' && authRole !== 'admin') {
      setLoginTargetRole('admin');
      setIsLoginModalOpen(true);
      return;
    }
    setCurrentView(view as any);
  };

  // Background Theme State (Defaults to modern clinical teal)
  const [theme, setTheme] = useState<ThemeMode>(() => {
    return (localStorage.getItem('medikiosk_theme') as ThemeMode) || 'clinical-teal';
  });

  const handleSelectTheme = (newTheme: ThemeMode) => {
    setTheme(newTheme);
    localStorage.setItem('medikiosk_theme', newTheme);
  };

  // Core Data States
  const [patient, setPatient] = useState<PatientSession>(defaultPatient);
  const [consentGiven, setConsentGiven] = useState<boolean>(true);
  const [isEmergencyActive, setIsEmergencyActive] = useState<boolean>(false);
  const [activeAlerts, setActiveAlerts] = useState<RedFlagAlert[]>([]);

  // Offline & Online Network Sync States
  const [isOnline, setIsOnline] = useState<boolean>(isAppOnline());
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(getPendingSyncCount());
  const [syncSuccessToast, setSyncSuccessToast] = useState<string | null>(null);

  // Modals States
  const [isNewPatientOpen, setIsNewPatientOpen] = useState<boolean>(false);
  const [isWriteRxOpen, setIsWriteRxOpen] = useState<boolean>(false);
  const [isSupportOpen, setIsSupportOpen] = useState<boolean>(false);
  const [isFhirOpen, setIsFhirOpen] = useState<boolean>(false);
  const [isQrOpen, setIsQrOpen] = useState<boolean>(false);
  const [isSecurityOpen, setIsSecurityOpen] = useState<boolean>(false);
  const [isFirebaseOpen, setIsFirebaseOpen] = useState<boolean>(false);
  const [allPatientsList, setAllPatientsList] = useState<PatientSession[]>([defaultPatient]);

  const t = translations[lang] || translations.en;

  // Network status subscriber & auto sync
  useEffect(() => {
    const unsubscribe = subscribeToNetworkStatus((online) => {
      setIsOnline(online);
      setPendingSyncCount(getPendingSyncCount());
      if (online) {
        processOfflineMutationQueue().then(res => {
          setPendingSyncCount(res.remainingCount);
          if (res.syncedCount > 0) {
            setSyncSuccessToast(`Online: Synced ${res.syncedCount} offline record(s) to cloud database!`);
            setTimeout(() => setSyncSuccessToast(null), 4000);
            getAllPatients().then(fresh => setAllPatientsList(fresh));
          }
        });
      }
    });
    return () => unsubscribe();
  }, []);

  const handleManualSync = async () => {
    audioService.playBeep('click');
    const res = await processOfflineMutationQueue();
    setPendingSyncCount(res.remainingCount);
    if (res.syncedCount > 0) {
      setSyncSuccessToast(`Synced ${res.syncedCount} records to database.`);
      setTimeout(() => setSyncSuccessToast(null), 3000);
      const fresh = await getAllPatients();
      setAllPatientsList(fresh);
    } else if (!isOnline) {
      alert("You are currently offline. All patient data is saved locally and will auto-sync when online.");
    } else {
      setSyncSuccessToast("Everything is already in sync!");
      setTimeout(() => setSyncSuccessToast(null), 2500);
    }
  };

  // 1. Fetch initial active session and listen to Cloud Firestore in real-time
  useEffect(() => {
    async function init() {
      try {
        const sess = await getSession(defaultPatient.id);
        if (sess && sess.id) {
          setPatient(sess);
          if (sess.consultType) {
            setConsultType(sess.consultType as ConsultType);
          }
        }
        const patients = await getAllPatients();
        if (patients.length > 0) {
          setAllPatientsList(patients);
        }
      } catch (e) {
        console.error("Init session fetch error:", e);
      }
    }
    init();

    // Subscribe to real-time Firestore database updates
    const unsubscribeFirestore = subscribeToPatientsFromFirestore((cloudPatients) => {
      if (cloudPatients && cloudPatients.length > 0) {
        setAllPatientsList(cloudPatients);
        const matchingCurrent = cloudPatients.find(p => p.id === patient.id);
        if (matchingCurrent) {
          setPatient(matchingCurrent);
        }
      }
    });

    return () => {
      unsubscribeFirestore();
    };
  }, []);

  // 2. Real-Time Server-Sent Events (SSE) for Nurse Triage Alerts
  useEffect(() => {
    let eventSource: EventSource | null = null;
    try {
      eventSource = new EventSource('/api/redflag/events');
      
      eventSource.addEventListener('red_flag_alert', (e: MessageEvent) => {
        try {
          const alertData: RedFlagAlert = JSON.parse(e.data);
          setActiveAlerts(prev => {
            if (prev.some(a => a.session_id === alertData.session_id)) return prev;
            return [alertData, ...prev];
          });
          audioService.playBeep('alarm');
        } catch (err) {
          console.error("Failed to parse redflag alert event:", err);
        }
      });

      eventSource.addEventListener('red_flag_ack', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data);
          setActiveAlerts(prev => prev.filter(a => a.session_id !== data.session_id));
          if (patient.id === data.session_id) {
            setIsEmergencyActive(false);
          }
        } catch (err) {
          console.error("Failed to parse redflag ack event:", err);
        }
      });
    } catch (err) {
      console.error("SSE connection error:", err);
    }

    return () => {
      if (eventSource) eventSource.close();
    };
  }, [patient.id]);

  // 3. Polling fallback when Kiosk is in emergency state
  useEffect(() => {
    if (!isEmergencyActive) return;
    const interval = setInterval(async () => {
      try {
        const updated = await getSession(patient.id);
        if (updated.status === 'acknowledged' || updated.status === 'active') {
          setIsEmergencyActive(false);
          setPatient(updated);
        }
      } catch (err) {
        console.error("Polling error:", err);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [isEmergencyActive, patient.id]);

  // Patient updater that syncs to API backend
  const handleUpdatePatient = async (updates: Partial<PatientSession>) => {
    const updated = { ...patient, ...updates };
    setPatient(updated);
    try {
      await updateSession(patient.id, updates);
    } catch (err) {
      console.error("Failed to sync updates to backend:", err);
    }
  };

  // Kiosk Handlers
  const handleConfirmHomeMedicationChoice = async (type: ConsultType, stream: 'allopathic' | 'ayush' | 'both') => {
    setConsultType(type);
    try {
      const newSession = await startSession({
        consultType: type,
        name: patient.name,
        age: patient.age,
        gender: patient.gender,
        phone: patient.phone,
        abhaId: patient.abhaId
      });
      const updated = { ...newSession, medicationStream: stream };
      setPatient(updated);
      await updateSession(newSession.id, { medicationStream: stream });
    } catch (err) {
      console.error("Session start error:", err);
      setPatient(prev => ({ ...prev, consultType: type, medicationStream: stream }));
    }
    setKioskStep('identify');
  };

  const handleSelectLanguage = (selectedCode: LanguageCode) => {
    setLang(selectedCode);
    setKioskStep('home');
  };

  const handleSelectConsultType = async (type: ConsultType) => {
    setConsultType(type);
    try {
      const newSession = await startSession({
        consultType: type,
        name: patient.name,
        age: patient.age,
        gender: patient.gender,
        phone: patient.phone,
        abhaId: patient.abhaId
      });
      setPatient(newSession);
    } catch (err) {
      console.error(err);
    }
    setKioskStep('identify');
  };

  const handleVerifyAbha = async (abhaId: string) => {
    try {
      const newSession = await startSession({
        abhaId,
        consultType
      });
      setPatient(newSession);
      setKioskStep('converse');
    } catch (err) {
      console.error(err);
      setKioskStep('converse');
    }
  };

  const handleOpenPatientDashboard = async (abhaId: string) => {
    try {
      const newSession = await startSession({
        abhaId,
        consultType
      });
      setPatient(newSession);
      setCurrentView('patient_dashboard');
    } catch (err) {
      console.error(err);
      setCurrentView('patient_dashboard');
    }
  };

  const handleRegisterNewPatient = async (data: { name: string; age: number; gender: string; phone: string }) => {
    try {
      const newSession = await startSession({
        name: data.name,
        age: data.age,
        gender: data.gender,
        phone: data.phone,
        consultType
      });
      setPatient(newSession);
      setIsNewPatientOpen(false);
      setKioskStep('converse');
    } catch (err) {
      console.error(err);
      setIsNewPatientOpen(false);
      setKioskStep('converse');
    }
  };

  const handleTriggerEmergency = async () => {
    audioService.playBeep('alarm');
    setIsEmergencyActive(true);
    try {
      await triggerRedflag(patient.id, "Emergency Escalation Pressed on Kiosk Bed", "Kiosk-01");
    } catch (err) {
      console.error("Trigger redflag error:", err);
    }
  };

  const handleAcknowledgeAlert = async (sessionId: string) => {
    try {
      await ackRedflag(sessionId);
      setActiveAlerts(prev => prev.filter(a => a.session_id !== sessionId));
      if (patient.id === sessionId) {
        setIsEmergencyActive(false);
        setPatient(prev => ({
          ...prev,
          status: 'acknowledged',
          documents: prev.documents.map(d => ({ ...d, url: '/assets/documents/purged_dpdp.pdf' }))
        }));
      }
    } catch (err) {
      console.error("Ack redflag error:", err);
    }
  };

  const handleSavePrescription = async (rx: Prescription) => {
    const updatedPrescriptions = [rx, ...(patient.prescriptions || [])];
    await handleUpdatePatient({ prescriptions: updatedPrescriptions });
  };

  const handleSimulateTestAlert = async () => {
    audioService.playBeep('alarm');
    const mockAlert: RedFlagAlert = {
      session_id: `MED-${Math.floor(10000 + Math.random() * 90000)}`,
      patient_name: "Emergency Patient",
      symptom: "Severe Chest Pain / Shortness of Breath (Simulated)",
      kiosk_id: "Kiosk-02",
      timestamp: Date.now()
    };
    setActiveAlerts(prev => [mockAlert, ...prev]);
  };

  return (
    <div 
      className={`flex flex-col h-screen w-screen overflow-hidden select-none font-sans transition-colors duration-300 theme-${theme}`}
      style={{
        backgroundColor: 'var(--bg-app)',
        backgroundImage: 'var(--bg-mesh)',
        color: 'var(--text-main)'
      }}
    >
      
      {/* Top Universal Header */}
      <Header
        currentView={currentView}
        onSelectView={handleSelectView}
        onGoHome={() => {
          audioService.playBeep('click');
          setCurrentView('kiosk');
          setKioskStep('home');
        }}
        onOpenAssistance={() => setIsSupportOpen(true)}
        onOpenFhir={() => setIsFhirOpen(true)}
        onOpenSecurity={() => setIsSecurityOpen(true)}
        onOpenFirebaseSync={() => setIsFirebaseOpen(true)}
        consultType={consultType}
        activeAlertsCount={activeAlerts.length}
        currentTheme={theme}
        onSelectTheme={handleSelectTheme}
        authRole={authRole}
        authName={authName}
        onLogout={() => {
          audioService.playBeep('click');
          setAuthRole('guest');
          setAuthName('');
          setCurrentView('kiosk');
        }}
        isOnline={isOnline}
        pendingSyncCount={pendingSyncCount}
        onTriggerSync={handleManualSync}
      />

      {/* Offline Mode Alert Ribbon */}
      {!isOnline && (
        <div className="bg-gradient-to-r from-amber-950/90 via-amber-900/80 to-amber-950/90 border-b border-amber-500/40 px-4 py-2 text-xs text-amber-200 flex items-center justify-between shadow-md shrink-0 animate-fadeIn">
          <div className="flex items-center gap-2.5">
            <WifiOff className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
            <span>
              <strong>Offline Mode Active:</strong> All OPD Kiosk workflows, local AI voice dialogue, and local data persistence are fully active. Data will auto-sync when online.
            </span>
          </div>
          {pendingSyncCount > 0 && (
            <button 
              onClick={handleManualSync}
              className="px-2.5 py-0.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold font-mono text-[11px] rounded-lg transition-colors cursor-pointer"
            >
              {pendingSyncCount} Pending • Retry Sync
            </button>
          )}
        </div>
      )}

      {/* Auto Cloud Sync Success Toast */}
      {syncSuccessToast && (
        <div className="bg-emerald-950/95 border-b border-emerald-500/40 px-4 py-2 text-xs text-emerald-200 flex items-center justify-between shadow-md shrink-0 animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">{syncSuccessToast}</span>
          </div>
          <button onClick={() => setSyncSuccessToast(null)} className="text-emerald-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main App Body */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* Kiosk Sidebar Navigation (Visible only in Kiosk intake flow after home/language select) */}
        {currentView === 'kiosk' && kioskStep !== 'home' && kioskStep !== 'language' && kioskStep !== 'consult_type' && (
          <aside 
            className="w-64 border-r flex flex-col h-full py-6 px-4 shrink-0 shadow-lg transition-colors duration-300"
            style={{
              backgroundColor: 'var(--bg-sidebar)',
              borderColor: 'var(--border-color)'
            }}
          >
            {/* Facility Header */}
            <div 
              className="mb-6 flex flex-col items-center text-center pb-5 border-b"
              style={{ borderColor: 'var(--border-color)' }}
            >
              <div className="w-12 h-12 bg-teal-500/10 border border-teal-500/30 rounded-2xl mb-2.5 flex items-center justify-center shadow-xs font-bold text-xl text-teal-400">
                🏥
              </div>
              <div className="text-[9px] uppercase tracking-[0.25em] text-teal-400 font-bold">
                PUBLIC HEALTH OPD
              </div>
              <h2 className="text-sm font-bold font-serif mt-0.5" style={{ color: 'var(--text-main)' }}>
                {t.opdRegistration}
              </h2>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-[10px] opacity-70 font-mono" style={{ color: 'var(--text-muted)' }}>
                  Kiosk-01 • {consultType === 'ayush' ? 'AYUSH' : 'Allopathic'}
                </span>
                <button
                  onClick={() => setKioskStep('home')}
                  className="text-[9px] text-teal-400 hover:underline font-semibold ml-1 cursor-pointer"
                  title="Switch Allopathic / AYUSH Pathway"
                >
                  (Change)
                </button>
              </div>
            </div>

            {/* Stepper Navigation */}
            <nav className="flex-1 space-y-1.5">
              {[
                { s: 'identify', label: t.identifyNav, num: '01', icon: <UserCheck className="w-4 h-4" /> },
                { s: 'converse', label: t.converseNav, num: '02', icon: <MessageSquare className="w-4 h-4" /> },
                { s: 'scan', label: t.scanNav, num: '03', icon: <Camera className="w-4 h-4" /> },
                { s: 'summary', label: t.summaryNav, num: '04', icon: <FileCheck className="w-4 h-4" /> }
              ].map(item => {
                const isActive = kioskStep === item.s;
                return (
                  <button
                    key={item.s}
                    onClick={() => {
                      audioService.playBeep('click');
                      setKioskStep(item.s as any);
                    }}
                    className={`flex items-center gap-3 px-3.5 py-3 rounded-xl w-full text-left text-xs font-semibold border transition-all ${
                      isActive
                        ? 'bg-teal-600 text-white border-teal-500 shadow-md font-bold'
                        : 'bg-transparent border-transparent hover:bg-white/5 opacity-75 hover:opacity-100'
                    }`}
                    style={{
                      color: isActive ? '#FFFFFF' : 'var(--text-main)'
                    }}
                  >
                    <span className="font-mono text-[10px] opacity-70">{item.num}</span>
                    <span className="flex-1">{item.label}</span>
                    {item.icon}
                  </button>
                );
              })}
            </nav>

            {/* Red Priority Emergency Button on Kiosk Sidebar */}
            <button
              onClick={handleTriggerEmergency}
              className="mt-auto h-12 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all border border-rose-500 shadow-sm flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <AlertOctagon className="w-4 h-4" />
              <span>{t.emergencyHelp}</span>
            </button>
          </aside>
        )}

        {/* Dynamic Main Workspace Router */}
        <main className="flex-1 flex flex-col h-full overflow-y-auto relative p-4 md:p-8">
          
          {/* VIEW 1: KIOSK INTAKE */}
          {currentView === 'kiosk' && (
            <>
              {kioskStep === 'home' && (
                <HomeMedicationChoice
                  currentType={consultType}
                  selectedLang={lang}
                  onSelectLanguage={setLang}
                  onConfirmChoice={handleConfirmHomeMedicationChoice}
                />
              )}

              {kioskStep === 'language' && (
                <LanguageSelect
                  selectedLang={lang}
                  onSelectLanguage={handleSelectLanguage}
                />
              )}

              {kioskStep === 'consult_type' && (
                <ConsultTypeSelect
                  onSelectType={handleSelectConsultType}
                />
              )}

              {kioskStep === 'identify' && (
                <IdentifyStep
                  lang={lang}
                  patient={patient}
                  onVerifyAbha={handleVerifyAbha}
                  onOpenPatientDashboard={handleOpenPatientDashboard}
                  onOpenNewRegistration={() => setIsNewPatientOpen(true)}
                  onOpenQrScanner={() => setIsQrOpen(true)}
                  consentGiven={consentGiven}
                  onToggleConsent={setConsentGiven}
                />
              )}

              {kioskStep === 'converse' && (
                <ConverseStep
                  lang={lang}
                  patient={patient}
                  consultType={consultType}
                  onUpdatePatient={handleUpdatePatient}
                  onProceedToScan={() => setKioskStep('scan')}
                  onTriggerEmergency={handleTriggerEmergency}
                />
              )}

              {kioskStep === 'scan' && (
                <ScanStep
                  lang={lang}
                  patient={patient}
                  onUpdatePatient={handleUpdatePatient}
                  onProceedToSummary={() => setKioskStep('summary')}
                />
              )}

              {kioskStep === 'summary' && (
                <SummaryStep
                  lang={lang}
                  patient={patient}
                  consultType={consultType}
                  onEditByVoice={() => setKioskStep('converse')}
                  onConfirmAndProceed={() => {
                    handleUpdatePatient({ status: 'completed' });
                    setCurrentView('physician');
                  }}
                />
              )}
            </>
          )}

          {/* VIEW 2: PATIENT DASHBOARD (Card-based Medical History, Visits & Appointments) */}
          {currentView === 'patient_dashboard' && (
            <PatientDashboard
              patient={patient}
              lang={lang}
              onStartNewIntake={() => {
                setCurrentView('kiosk');
                setKioskStep('converse');
              }}
              onOpenFhirModal={() => setIsFhirOpen(true)}
              onOpenSecurityModal={() => setIsSecurityOpen(true)}
            />
          )}

          {/* VIEW 3: PHYSICIAN CLINICAL PORTAL */}
          {currentView === 'physician' && (
            <PhysicianPortal
              patient={patient}
              allPatients={allPatientsList}
              onSelectPatient={(p) => setPatient(p)}
              onUpdatePatient={handleUpdatePatient}
              onOpenWriteRx={() => setIsWriteRxOpen(true)}
              onOpenFhir={() => setIsFhirOpen(true)}
              onOpenSecurity={() => setIsSecurityOpen(true)}
            />
          )}

          {/* VIEW 4: NURSE TRIAGE ALERT CONSOLE */}
          {currentView === 'triage' && (
            <TriageConsole
              activeAlerts={activeAlerts}
              onAcknowledgeAlert={handleAcknowledgeAlert}
              onSimulateTestAlert={handleSimulateTestAlert}
            />
          )}

          {/* VIEW 5: ADMIN DASHBOARD (Patient Data Management + Cryptographic Audit Logs + Hardware Metrics) */}
          {currentView === 'admin' && (
            <AdminDashboard
              activeAlerts={activeAlerts}
              allPatients={allPatientsList}
              onSelectPatient={(p) => {
                setPatient(p);
                setCurrentView('physician');
              }}
              onRefreshPatients={async () => {
                const fresh = await getAllPatients();
                setAllPatientsList(fresh);
              }}
              onOpenNewPatientModal={() => setIsNewPatientOpen(true)}
              onAcknowledgeAlert={handleAcknowledgeAlert}
              onSimulateTestAlert={handleSimulateTestAlert}
              onOpenSecurityModal={() => setIsSecurityOpen(true)}
            />
          )}

        </main>
      </div>

      {/* Emergency Red-Flag Patient Hold Overlay */}
      {isEmergencyActive && (
        <EmergencyOverlay
          lang={lang}
          kioskId="Kiosk-01"
          sessionId={patient.id}
          patientName={patient.name}
          symptom={patient.redflagSymptom || patient.chiefComplaintDetails || "Acute Chest Pain / Respiratory Distress"}
          onDismissManual={() => handleAcknowledgeAlert(patient.id)}
        />
      )}

      {/* All Application Modals */}
      <NewPatientModal
        isOpen={isNewPatientOpen}
        onClose={() => setIsNewPatientOpen(false)}
        onRegister={handleRegisterNewPatient}
      />

      <WriteRxModal
        isOpen={isWriteRxOpen}
        onClose={() => setIsWriteRxOpen(false)}
        patient={patient}
        onSavePrescription={handleSavePrescription}
      />

      <SupportModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
        onRequestHelp={(svc) => console.log("Requested assistance:", svc)}
      />

      <FhirModal
        isOpen={isFhirOpen}
        onClose={() => setIsFhirOpen(false)}
        patient={patient}
      />

      <QrScannerModal
        isOpen={isQrOpen}
        onClose={() => setIsQrOpen(false)}
        onScanSuccess={handleVerifyAbha}
      />

      <SecurityConsoleModal
        isOpen={isSecurityOpen}
        onClose={() => setIsSecurityOpen(false)}
        session={patient}
        onPatientPurged={async () => {
          const fresh = await getSession(patient.id);
          setPatient(fresh);
        }}
        onPiiToggled={async () => {
          const fresh = await getSession(patient.id);
          setPatient(fresh);
        }}
      />

      {/* Role Login Authentication Modal */}
      <RoleLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        targetRole={loginTargetRole}
        onLoginSuccess={(role, name) => {
          setAuthRole(role);
          setAuthName(name);
          setCurrentView(role === 'doctor' ? 'physician' : 'admin');
        }}
      />

      {/* Firebase Firestore Cloud Data Sync Modal */}
      <FirebaseSyncModal
        isOpen={isFirebaseOpen}
        onClose={() => setIsFirebaseOpen(false)}
        allPatients={allPatientsList}
        onSyncComplete={(updated) => setAllPatientsList(updated)}
      />

    </div>
  );
}
