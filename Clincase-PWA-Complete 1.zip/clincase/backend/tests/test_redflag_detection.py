def test_redflag_emergency_trigger(client):
    """Test emergency red-flag alert detection when acute symptoms are reported"""
    payload = {
        "sessionId": "MED-49201",
        "chiefComplaint": "Crushing chest pain radiating to left arm and shortness of breath",
        "symptoms": ["Chest Pain", "Dyspnea"],
        "currentStep": 1,
        "consultType": "allopathic"
    }
    response = client.post("/api/v1/ai/adaptive-question", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["isRedFlag"] is True
    assert data["targetSection"] == "TRIAGE_EMERGENCY"
    assert "CRITICAL" in data["nextQuestion"] or "urgency" in data["nextQuestion"]

def test_non_redflag_routine_symptoms(client):
    """Test routine mild symptoms do not trigger emergency red-flag alert"""
    payload = {
        "sessionId": "MED-49201",
        "chiefComplaint": "Mild headache and runny nose for 1 day",
        "symptoms": ["Headache", "Coryza"],
        "currentStep": 1,
        "consultType": "allopathic"
    }
    response = client.post("/api/v1/ai/adaptive-question", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["isRedFlag"] is False
