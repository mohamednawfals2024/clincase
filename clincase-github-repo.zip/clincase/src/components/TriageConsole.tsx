import React from 'react';
import { AlertTriangle, Bell, CheckCircle2, ShieldAlert, Clock, Monitor, User } from 'lucide-react';
import { RedFlagAlert } from '../types';
import { audioService } from '../services/api';

interface TriageConsoleProps {
  activeAlerts: RedFlagAlert[];
  onAcknowledgeAlert: (sessionId: string) => void;
  onSimulateTestAlert: () => void;
}

export const TriageConsole: React.FC<TriageConsoleProps> = ({
  activeAlerts,
  onAcknowledgeAlert,
  onSimulateTestAlert
}) => {
  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 animate-fadeIn pb-12">
      {/* Console Header */}
      <div className={`p-6 rounded-2xl border transition-all ${
        activeAlerts.length > 0
          ? 'bg-[#BA1A1A]/10 border-[#BA1A1A] ring-4 ring-[#BA1A1A]/10 shadow-lg'
          : 'bg-white border-[#1A1A1A]/10 shadow-xs'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                activeAlerts.length > 0 ? 'bg-[#BA1A1A] text-white animate-bounce' : 'bg-[#1A1A1A] text-white'
              }`}>
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h1 className="text-xl md:text-2xl font-bold font-serif text-[#1A1A1A]">
                Duty-Station Nurse Triage Alert Console
              </h1>
            </div>
            <p className="text-xs text-[#5C5852] mt-1">
              Real-time priority clinical escalation receiver for OPD Kiosks via Server-Sent Events (SSE).
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#34A853]/10 text-[#34A853] text-xs font-bold uppercase tracking-wider border border-[#34A853]/20">
              <span className="w-2 h-2 rounded-full bg-[#34A853] animate-pulse" />
              <span>Live Connected</span>
            </div>

            <button
              onClick={onSimulateTestAlert}
              className="px-3.5 py-1.5 bg-[#FAF8F5] hover:bg-[#EBE8E3] text-[#1A1A1A] rounded-xl text-xs font-bold uppercase tracking-wider border border-[#1A1A1A]/10 transition-colors"
            >
              Simulate Alert
            </button>
          </div>
        </div>
      </div>

      {/* Active Alerts List */}
      {activeAlerts.length === 0 ? (
        <div className="bg-white border border-[#1A1A1A]/10 rounded-2xl p-12 text-center flex flex-col items-center justify-center shadow-xs">
          <div className="w-16 h-16 rounded-full bg-[#34A853]/10 text-[#34A853] flex items-center justify-center mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold font-serif text-[#1A1A1A]">
            No Active Emergency Red-Flags
          </h3>
          <p className="text-xs text-[#5C5852] mt-1 max-w-sm">
            All OPD waiting-area kiosks are operating normally. Emergency triggers will flash here instantly with audible alarm tones.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="text-xs font-bold uppercase tracking-wider text-[#BA1A1A] flex items-center gap-1.5">
            <Bell className="w-4 h-4 animate-bounce" />
            <span>Priority Attention Required ({activeAlerts.length} Kiosks Active)</span>
          </div>

          {activeAlerts.map(alert => (
            <div
              key={alert.session_id}
              className="p-6 bg-gradient-to-r from-red-50 to-white border-2 border-[#BA1A1A] rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-5 shadow-md animate-fadeIn"
            >
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-1 bg-[#BA1A1A] text-white text-xs font-mono font-bold rounded-lg uppercase tracking-wider">
                    {alert.kiosk_id}
                  </span>
                  <span className="text-sm font-bold text-[#1A1A1A] flex items-center gap-1.5">
                    <User className="w-4 h-4 text-[#5C5852]" />
                    {alert.patient_name}
                  </span>
                  <span className="text-xs font-mono text-[#5C5852] bg-white px-2 py-0.5 rounded border">
                    ID: {alert.session_id}
                  </span>
                </div>

                <div className="text-sm font-bold text-[#BA1A1A] flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#BA1A1A] animate-pulse" />
                  <span>Symptom / Escalation: {alert.symptom}</span>
                </div>

                <div className="text-[11px] text-[#5C5852] flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Dispatched: {new Date(alert.timestamp).toLocaleTimeString()} • Kiosk screen currently locked in holding state.</span>
                </div>
              </div>

              <button
                onClick={() => {
                  audioService.playBeep('success');
                  onAcknowledgeAlert(alert.session_id);
                }}
                className="w-full md:w-auto px-6 py-3 bg-[#BA1A1A] hover:bg-[#A31616] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all shrink-0 cursor-pointer flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Acknowledge & Release Kiosk</span>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
