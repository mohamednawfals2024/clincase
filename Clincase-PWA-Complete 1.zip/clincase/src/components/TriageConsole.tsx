import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  Bell, 
  CheckCircle2, 
  ShieldAlert, 
  Clock, 
  User, 
  Truck, 
  Building2, 
  UserCheck, 
  PhoneCall, 
  Navigation, 
  ExternalLink,
  Radio,
  Hospital
} from 'lucide-react';
import { RedFlagAlert, EmergencyHospital, AmbulanceUnit, EmergencyDoctor } from '../types';
import { audioService } from '../services/api';
import { fetchNearbyEmergencyFacilities } from '../services/emergencyService';

interface TriageConsoleProps {
  activeAlerts: RedFlagAlert[];
  onAcknowledgeAlert: (sessionId: string) => void;
  onSimulateTestAlert: () => void;
}

export const TriageConsole: React.FC<TriageConsoleProps> = ({
  activeAlerts,
  onAcknowledgeAlert,
  onSimulateTestAlert
}) => {
  const [facilities, setFacilities] = useState<{
    hospitals: EmergencyHospital[];
    ambulances: AmbulanceUnit[];
    doctors: EmergencyDoctor[];
    attribution: string;
  } | null>(null);

  useEffect(() => {
    fetchNearbyEmergencyFacilities().then((res) => {
      setFacilities(res);
    });
  }, []);

  return (
    <div className="w-full max-w-5xl mx-auto flex flex-col gap-6 animate-fadeIn pb-12">
      {/* Console Header */}
      <div className={`p-6 rounded-2xl border transition-all ${
        activeAlerts.length > 0
          ? 'bg-[#BA1A1A]/10 border-[#BA1A1A] ring-4 ring-[#BA1A1A]/10 shadow-lg'
          : 'bg-white border-[#1A1A1A]/10 shadow-xs'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                activeAlerts.length > 0 ? 'bg-[#BA1A1A] text-white animate-bounce' : 'bg-[#1A1A1A] text-white'
              }`}>
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h1 className="text-xl md:text-2xl font-bold font-serif text-[#1A1A1A]">
                Duty-Station Nurse Triage Alert Console
              </h1>
            </div>
            <p className="text-xs text-[#5C5852] mt-1">
              Real-time priority clinical escalation & automated Google Maps emergency dispatch hub.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#34A853]/10 text-[#34A853] text-xs font-bold uppercase tracking-wider border border-[#34A853]/20">
              <span className="w-2 h-2 rounded-full bg-[#34A853] animate-pulse" />
              <span>Live Connected</span>
            </div>

            <button
              onClick={onSimulateTestAlert}
              className="px-3.5 py-1.5 bg-[#FAF8F5] hover:bg-[#EBE8E3] text-[#1A1A1A] rounded-xl text-xs font-bold uppercase tracking-wider border border-[#1A1A1A]/10 transition-colors"
            >
              Simulate Emergency Alert
            </button>
          </div>
        </div>
      </div>

      {/* Active Alerts List */}
      {activeAlerts.length === 0 ? (
        <div className="bg-white border border-[#1A1A1A]/10 rounded-2xl p-12 text-center flex flex-col items-center justify-center shadow-xs">
          <div className="w-16 h-16 rounded-full bg-[#34A853]/10 text-[#34A853] flex items-center justify-center mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold font-serif text-[#1A1A1A]">
            No Active Emergency Red-Flags
          </h3>
          <p className="text-xs text-[#5C5852] mt-1 max-w-sm">
            All OPD waiting-area kiosks are operating normally. Emergency triggers will flash here instantly with automated hospital, doctor, and ambulance dispatching.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="text-xs font-bold uppercase tracking-wider text-[#BA1A1A] flex items-center gap-1.5">
            <Bell className="w-4 h-4 animate-bounce" />
            <span>Priority Attention Required ({activeAlerts.length} Kiosks Active)</span>
          </div>

          {activeAlerts.map(alert => {
            const hospital = facilities?.hospitals?.[0];
            const ambulance = facilities?.ambulances?.[0];
            const doctor = facilities?.doctors?.[0];

            return (
              <div
                key={alert.session_id}
                className="p-6 bg-gradient-to-r from-red-50 to-white border-2 border-[#BA1A1A] rounded-2xl flex flex-col gap-5 shadow-md animate-fadeIn"
              >
                {/* Top Alert Header Bar */}
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-red-200 pb-4">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-1 bg-[#BA1A1A] text-white text-xs font-mono font-bold rounded-lg uppercase tracking-wider">
                        {alert.kiosk_id}
                      </span>
                      <span className="text-sm font-bold text-[#1A1A1A] flex items-center gap-1.5">
                        <User className="w-4 h-4 text-[#5C5852]" />
                        {alert.patient_name}
                      </span>
                      <span className="text-xs font-mono text-[#5C5852] bg-white px-2 py-0.5 rounded border">
                        ID: {alert.session_id}
                      </span>
                    </div>

                    <div className="text-sm font-bold text-[#BA1A1A] flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-[#BA1A1A] animate-pulse" />
                      <span>Symptom Escalation: {alert.symptom}</span>
                    </div>

                    <div className="text-[11px] text-[#5C5852] flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Triggered at {new Date(alert.timestamp).toLocaleTimeString()} • Automatic Multi-Agency Escalation Triggered</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      audioService.playBeep('success');
                      onAcknowledgeAlert(alert.session_id);
                    }}
                    className="w-full md:w-auto px-6 py-3 bg-[#BA1A1A] hover:bg-[#A31616] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all shrink-0 cursor-pointer flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Acknowledge & Release Kiosk</span>
                  </button>
                </div>

                {/* Google Data Emergency Dispatch Cards (Hospital, Doctor, Ambulance) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-700">
                    <span className="flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 text-[#BA1A1A] animate-pulse" />
                      <span>Direct Emergency Contact Hub (Google Places Data)</span>
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {facilities?.attribution || "Google Maps Platform Places Data"}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    
                    {/* Card 1: Nearby Hospital Contacted */}
                    <div className="p-4 bg-white rounded-xl border border-sky-200 shadow-xs flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-sky-800 flex items-center gap-1">
                            <Building2 className="w-3.5 h-3.5 text-sky-600" />
                            <span>Nearby Hospital</span>
                          </span>
                          <span className="px-2 py-0.5 bg-sky-100 text-sky-700 rounded-full text-[10px] font-bold">
                            {hospital?.distanceKm || 1.1} km • {hospital?.etaMinutes || 4}m ETA
                          </span>
                        </div>
                        <p className="text-xs font-bold text-slate-900">
                          {hospital?.name || "Apollo Hospital Trauma Center"}
                        </p>
                        <p className="text-[11px] text-slate-600">
                          {hospital?.vicinity || "Greams Lane, Chennai"}
                        </p>
                        <p className="text-[10px] text-emerald-700 font-semibold">
                          ICU Beds: {hospital?.icuBedsAvailable || 8} Available • {hospital?.traumaLevel || "Level 1 Trauma"}
                        </p>
                      </div>

                      <div className="mt-3 flex items-center gap-2">
                        <a
                          href={`tel:${hospital?.phone || '+914428290200'}`}
                          className="flex-1 py-1.5 px-2 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold text-center flex items-center justify-center gap-1 transition-colors"
                        >
                          <PhoneCall className="w-3 h-3" />
                          <span>Call ED ({hospital?.phone?.split('/')[0] || '+91-44-2829-0200'})</span>
                        </a>
                        <a
                          href={hospital?.googleMapsUrl || "https://www.google.com/maps/search/?api=1&query=Apollo+Hospital+Emergency&utm_campaign=gmp_git_agentskills_v1"}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                          title="Open Google Maps Route"
                        >
                          <Navigation className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>

                    {/* Card 2: On-Call Doctor Paged */}
                    <div className="p-4 bg-white rounded-xl border border-rose-200 shadow-xs flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-rose-800 flex items-center gap-1">
                            <UserCheck className="w-3.5 h-3.5 text-rose-600" />
                            <span>On-Call Doctor</span>
                          </span>
                          <span className="px-2 py-0.5 bg-rose-100 text-rose-700 rounded-full text-[10px] font-bold">
                            PAGED
                          </span>
                        </div>
                        <p className="text-xs font-bold text-slate-900">
                          {doctor?.name || "Dr. Arvind Varma, MD"}
                        </p>
                        <p className="text-[11px] text-slate-600">
                          {doctor?.specialty || "Chief of Emergency & Resuscitation"}
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Response: {doctor?.estimatedResponseTime || "Immediate (Inside Ward)"} • {doctor?.pagerExt || "Ext. 401"}
                        </p>
                      </div>

                      <a
                        href={`tel:${doctor?.phone || '+919876512345'}`}
                        className="mt-3 py-1.5 px-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold text-center flex items-center justify-center gap-1 transition-colors"
                      >
                        <PhoneCall className="w-3 h-3" />
                        <span>Direct Page Doctor ({doctor?.phone || '+91-98765-12345'})</span>
                      </a>
                    </div>

                    {/* Card 3: Nearby Ambulance Dispatched */}
                    <div className="p-4 bg-white rounded-xl border border-emerald-200 shadow-xs flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-800 flex items-center gap-1">
                            <Truck className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                            <span>Nearby Ambulance</span>
                          </span>
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-[10px] font-bold">
                            DISPATCHED • {ambulance?.etaMinutes || 3}m ETA
                          </span>
                        </div>
                        <p className="text-xs font-bold text-slate-900">
                          {ambulance?.serviceName || "108 National Cardiac Ambulance"}
                        </p>
                        <p className="text-[11px] text-slate-600">
                          Unit: {ambulance?.callSign || "ACLS-108-UNIT-44"} ({ambulance?.type?.split(' ')[0] || 'ACLS'})
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Driver: {ambulance?.driverName || "K. Ramesh"} • Reg: {ambulance?.vehicleNumber || "TN-01-EM-4892"}
                        </p>
                      </div>

                      <a
                        href={`tel:${ambulance?.phone || '108'}`}
                        className="mt-3 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold text-center flex items-center justify-center gap-1 transition-colors"
                      >
                        <PhoneCall className="w-3 h-3" />
                        <span>Call Ambulance Driver ({ambulance?.phone || '108'})</span>
                      </a>
                    </div>

                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
