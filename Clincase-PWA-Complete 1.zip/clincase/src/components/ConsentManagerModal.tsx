import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  FileCheck2, 
  Trash2, 
  Download, 
  CheckCircle2, 
  X, 
  KeyRound, 
  AlertTriangle,
  FileText,
  Clock,
  UserCheck
} from 'lucide-react';
import { PatientSession } from '../types';
import { generateDigitalConsentReceipt, maskName, maskAbha } from '../services/privacyService';

interface ConsentManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientSession;
  onPurgeData: () => void;
}

export const ConsentManagerModal: React.FC<ConsentManagerModalProps> = ({
  isOpen,
  onClose,
  patient,
  onPurgeData
}) => {
  const [purposes, setPurposes] = useState({
    clinicalCare: true,
    aiSummarization: true,
    emrInteroperability: true,
    academicResearch: false
  });

  const [receipt] = useState(() => 
    generateDigitalConsentReceipt(patient.id, patient.name, purposes)
  );

  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadCertificate = () => {
    const cert = {
      complianceStandard: "DPDP Act 2023 (Section 6 & 12) & ABDM Interoperability",
      digitalReceipt: receipt,
      patientId: patient.id,
      patientNameMasked: maskName(patient.name),
      abhaIdMasked: maskAbha(patient.abhaId || ''),
      encryptionStandard: "AES-256-GCM Zero-Trust Hardware Storage",
      auditTrailStatus: "SHA-256 Chained Tombstone Verifiable",
      issuedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(cert, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `DPDP_Privacy_Certificate_${patient.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0E1626] border border-[#1E2D4A] rounded-3xl max-w-2xl w-full p-6 md:p-8 text-slate-100 shadow-2xl space-y-6 relative max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-400 border border-teal-500/20 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold font-serif text-white">
              Data Privacy & Digital Consent Console
            </h2>
            <p className="text-xs text-slate-400">
              India DPDP Act 2023 • Section 6 Informed Consent & Section 12 Right to Erasure
            </p>
          </div>
        </div>

        {/* Digital Consent Receipt Box */}
        <div className="bg-slate-950/80 border border-teal-500/30 rounded-2xl p-5 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between text-teal-400 font-bold border-b border-slate-800 pb-2">
            <span className="flex items-center gap-1.5">
              <FileCheck2 className="w-4 h-4" />
              DIGITAL CONSENT RECEIPT
            </span>
            <span className="text-[10px] bg-teal-500/20 text-teal-300 px-2 py-0.5 rounded border border-teal-500/40">
              VERIFIED INTACT
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 text-[11px]">
            <div><strong className="text-slate-400">Receipt ID:</strong> {receipt.receiptId}</div>
            <div><strong className="text-slate-400">Patient:</strong> {receipt.patientNameMasked}</div>
            <div><strong className="text-slate-400">Jurisdiction:</strong> {receipt.jurisdiction}</div>
            <div><strong className="text-slate-400">Expiry Date:</strong> {receipt.expiryDate}</div>
          </div>

          <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 truncate">
            <strong className="text-slate-300">SHA-256 Signature:</strong> {receipt.consentHash}
          </div>
        </div>

        {/* Granular Consent Controls */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-teal-400" />
            <span>Granular Purpose Permissions</span>
          </h3>

          <div className="space-y-2 text-xs">
            <label className="flex items-center justify-between p-3 bg-slate-900/80 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700">
              <div className="space-y-0.5">
                <div className="font-bold text-white">OPD Clinical Care & Triage</div>
                <div className="text-[11px] text-slate-400">Allows OPD intake, nurse triage, and physician consultation.</div>
              </div>
              <input
                type="checkbox"
                checked={purposes.clinicalCare}
                disabled
                className="w-4 h-4 accent-teal-500"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-slate-900/80 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700">
              <div className="space-y-0.5">
                <div className="font-bold text-white">AI Clinical History Summarization</div>
                <div className="text-[11px] text-slate-400">Enables Gemini AI HPI briefing generation with automatic PII sanitization.</div>
              </div>
              <input
                type="checkbox"
                checked={purposes.aiSummarization}
                onChange={(e) => setPurposes({ ...purposes, aiSummarization: e.target.checked })}
                className="w-4 h-4 accent-teal-500 cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-slate-900/80 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700">
              <div className="space-y-0.5">
                <div className="font-bold text-white">ABDM / HL7 FHIR Interoperability</div>
                <div className="text-[11px] text-slate-400">Allows export of encrypted FHIR R4 Bundles to hospital EMR.</div>
              </div>
              <input
                type="checkbox"
                checked={purposes.emrInteroperability}
                onChange={(e) => setPurposes({ ...purposes, emrInteroperability: e.target.checked })}
                className="w-4 h-4 accent-teal-500 cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#1E2D4A]">
          {/* DPDP Section 12 Right to Erasure */}
          <button
            onClick={onPurgeData}
            className="w-full sm:w-auto px-4 py-2.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Trash2 className="w-4 h-4 text-rose-400" />
            <span>Right to Erasure (Wipe Data)</span>
          </button>

          {/* Download Privacy Certificate */}
          <button
            onClick={handleDownloadCertificate}
            className="w-full sm:w-auto px-5 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md"
          >
            {downloadSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-slate-950" />
                <span>Certificate Downloaded!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download DPDP Certificate</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
