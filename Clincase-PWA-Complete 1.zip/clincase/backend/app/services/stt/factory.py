from app.config import settings
from app.services.stt.base import STTProvider
from app.services.stt.providers import MockSTTProvider, GoogleGeminiSTTProvider, WhisperSTTProvider

def get_stt_provider() -> STTProvider:
    """Factory function returning the active STT provider based on STT_PROVIDER env config"""
    provider_name = settings.STT_PROVIDER.lower().strip()
    
    if provider_name == "gemini":
        return GoogleGeminiSTTProvider()
    elif provider_name == "whisper":
        return WhisperSTTProvider()
    else:
        return MockSTTProvider()
