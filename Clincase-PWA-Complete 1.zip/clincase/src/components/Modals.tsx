import React, { useState } from 'react';
import { 
  X, 
  UserPlus, 
  Pill, 
  HelpCircle, 
  FileCode2, 
  Copy, 
  Check, 
  QrCode, 
  Camera, 
  Sparkles, 
  ShieldCheck,
  AlertTriangle,
  AlertOctagon
} from 'lucide-react';
import { Prescription, PatientSession, DrugInteractionWarning } from '../types';
import { audioService, checkDrugInteractions } from '../services/api';

// ----------------------------------------------------
// 1. NEW PATIENT REGISTRATION MODAL
// ----------------------------------------------------
interface NewPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRegister: (data: { name: string; age: number; gender: string; phone: string }) => void;
}

export const NewPatientModal: React.FC<NewPatientModalProps> = ({
  isOpen,
  onClose,
  onRegister
}) => {
  const [name, setName] = useState('Sarah Connor');
  const [age, setAge] = useState('34');
  const [gender, setGender] = useState('Female');
  const [phone, setPhone] = useState('9876501234');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    audioService.playBeep('success');
    onRegister({
      name: name.trim() || 'New Patient',
      age: parseInt(age, 10) || 30,
      gender,
      phone: phone.trim() || '9876543210'
    });
  };

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-slate-900 rounded-2xl p-6 md:p-8 max-w-md w-full border border-slate-700 shadow-2xl animate-fadeIn text-slate-100">
        <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-white">New Patient Registration</h3>
              <p className="text-xs text-slate-400">Enter basic demographics to initiate an OPD session</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold uppercase text-slate-400 mb-1">Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              placeholder="e.g. John Doe"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold uppercase text-slate-400 mb-1">Age</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                required
                className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              />
            </div>
            <div>
              <label className="block font-bold uppercase text-slate-400 mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold uppercase text-slate-400 mb-1">Mobile Phone</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              placeholder="10-digit mobile number"
            />
          </div>

          <div className="flex gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 bg-slate-800 border border-slate-700 text-slate-300 rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-slate-700 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-teal-600 text-white rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-teal-500 shadow-md transition-all active:scale-95"
            >
              Register & Proceed
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ----------------------------------------------------
// 2. WRITE PRESCRIPTION MODAL WITH DRUG INTERACTION CHECK
// ----------------------------------------------------
interface WriteRxModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientSession;
  onSavePrescription: (rx: Prescription) => void;
}

export const WriteRxModal: React.FC<WriteRxModalProps> = ({
  isOpen,
  onClose,
  patient,
  onSavePrescription
}) => {
  const [medicine, setMedicine] = useState('');
  const [dosage, setDosage] = useState('650 mg');
  const [frequency, setFrequency] = useState('OD (1-0-0) Once Daily');
  const [duration, setDuration] = useState('5 Days');
  const [instructions, setInstructions] = useState('After meals with warm water');
  const [drugWarnings, setDrugWarnings] = useState<DrugInteractionWarning[]>([]);
  const [isCheckingInteraction, setIsCheckingInteraction] = useState(false);

  if (!isOpen) return null;

  const handleMedicineChange = async (medName: string) => {
    setMedicine(medName);
    if (medName.trim().length > 2) {
      setIsCheckingInteraction(true);
      try {
        const warnings = await checkDrugInteractions(
          medName,
          patient.prescriptions?.map(p => p.medicine) || [],
          patient.allergies?.map(a => a.name) || []
        );
        setDrugWarnings(warnings);
      } catch (err) {
        console.error(err);
      } finally {
        setIsCheckingInteraction(false);
      }
    } else {
      setDrugWarnings([]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!medicine.trim()) return;

    audioService.playBeep('success');
    onSavePrescription({
      id: `rx-${Date.now()}`,
      medicine: medicine.trim(),
      dosage,
      frequency,
      duration,
      instructions
    });

    setMedicine('');
    setDrugWarnings([]);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-slate-900 rounded-2xl p-6 md:p-8 max-w-lg w-full border border-slate-700 shadow-2xl animate-fadeIn text-slate-100">
        <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center">
              <Pill className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-white">Write Prescription</h3>
              <p className="text-xs text-slate-400">Patient: {patient.name} ({patient.age}y / {patient.gender})</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold uppercase text-slate-400 mb-1">
              Medicine Name & Composition
            </label>
            <input
              type="text"
              value={medicine}
              onChange={(e) => handleMedicineChange(e.target.value)}
              required
              autoFocus
              placeholder="e.g. Tab. Amoxicillin / Ibuprofen / Losartan"
              className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-semibold text-sm text-slate-100"
            />
          </div>

          {/* Real-Time Drug Interaction & Allergy Warning Box */}
          {drugWarnings.length > 0 && (
            <div className="space-y-2">
              {drugWarnings.map((w, idx) => (
                <div 
                  key={idx} 
                  className={`p-3 rounded-xl border flex items-start gap-2.5 text-xs ${
                    w.severity === 'Severe' 
                      ? 'bg-rose-950/80 border-rose-700 text-rose-200' 
                      : 'bg-amber-950/80 border-amber-700 text-amber-200'
                  }`}
                >
                  <AlertOctagon className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold uppercase tracking-wider text-[10px]">
                      {w.type.toUpperCase()} WARNING ({w.severity})
                    </div>
                    <div className="font-medium text-xs mt-0.5">{w.message}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold uppercase text-slate-400 mb-1">Dosage</label>
              <input
                type="text"
                value={dosage}
                onChange={(e) => setDosage(e.target.value)}
                className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              />
            </div>
            <div>
              <label className="block font-bold uppercase text-slate-400 mb-1">Frequency</label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value)}
                className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              >
                <option value="OD (1-0-0) Once Daily">OD (1-0-0) Once Daily</option>
                <option value="BD (1-0-1) Twice Daily">BD (1-0-1) Twice Daily</option>
                <option value="TDS (1-1-1) 3 Times/Day">TDS (1-1-1) 3 Times/Day</option>
                <option value="QID (4 Times/Day)">QID (4 Times/Day)</option>
                <option value="SOS (As needed)">SOS (As needed)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold uppercase text-slate-400 mb-1">Duration</label>
              <input
                type="text"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              />
            </div>
            <div>
              <label className="block font-bold uppercase text-slate-400 mb-1">Instructions / Timing</label>
              <input
                type="text"
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                className="w-full h-11 px-3 bg-slate-950 border border-slate-700 rounded-xl focus:border-teal-500 outline-none font-medium text-slate-100"
              />
            </div>
          </div>

          <div className="flex gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 bg-slate-800 border border-slate-700 text-slate-300 rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-slate-700 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-3 bg-teal-600 text-white rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-teal-500 shadow-md transition-all active:scale-95"
            >
              Issue Prescription
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ----------------------------------------------------
// 3. CALL FOR ASSISTANCE MODAL
// ----------------------------------------------------
interface SupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestHelp: (service: string) => void;
}

export const SupportModal: React.FC<SupportModalProps> = ({
  isOpen,
  onClose,
  onRequestHelp
}) => {
  const [requested, setRequested] = useState<string | null>(null);

  if (!isOpen) return null;

  const supportOptions = [
    { name: "Kiosk Attendant Support", desc: "A staff member will arrive to guide voice / touch input." },
    { name: "Wheelchair Mobility Assistance", desc: "Order a wheelchair and attendant to this kiosk." },
    { name: "Regional Dialect Translator", desc: "Request verbal translation assistance." },
    { name: "Paper Document Scanning Helper", desc: "Assistance with aligning reports on the scanner bed." }
  ];

  const handleSelect = (name: string) => {
    audioService.playBeep('success');
    setRequested(name);
    onRequestHelp(name);
    setTimeout(() => {
      setRequested(null);
      onClose();
    }, 1400);
  };

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-slate-900 rounded-2xl p-6 md:p-8 max-w-sm w-full border border-slate-700 shadow-2xl animate-fadeIn text-center text-slate-100">
        <div className="w-12 h-12 rounded-full bg-teal-950/80 text-teal-400 flex items-center justify-center mx-auto mb-3 border border-teal-800">
          <HelpCircle className="w-6 h-6" />
        </div>
        <h3 className="font-serif font-bold text-lg text-white mb-1">Call for Assistance</h3>
        <p className="text-xs text-slate-400 mb-5">Select the support you require at this kiosk:</p>

        <div className="space-y-2.5 mb-6 text-left">
          {supportOptions.map(opt => (
            <button
              key={opt.name}
              onClick={() => handleSelect(opt.name)}
              className="w-full p-3.5 bg-slate-950 border border-slate-800 hover:border-teal-500 hover:bg-slate-800/80 rounded-xl transition-all text-left group"
            >
              <div className="font-bold text-xs text-slate-200 group-hover:text-teal-300">
                {opt.name}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">{opt.desc}</div>
            </button>
          ))}
        </div>

        {requested ? (
          <div className="p-3 bg-emerald-950 text-emerald-300 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 animate-fadeIn border border-emerald-800">
            <Check className="w-4 h-4" />
            <span>Assistance dispatched to Kiosk-01</span>
          </div>
        ) : (
          <button
            onClick={onClose}
            className="w-full py-2.5 border border-slate-700 rounded-xl text-xs font-bold uppercase tracking-wider text-slate-300 hover:bg-slate-800 transition-all"
          >
            Cancel
          </button>
        )}
      </div>
    </div>
  );
};

// ----------------------------------------------------
// 4. FHIR R4 RESOURCE VIEWER MODAL
// ----------------------------------------------------
interface FhirModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: PatientSession;
}

export const FhirModal: React.FC<FhirModalProps> = ({
  isOpen,
  onClose,
  patient
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const fhirBundle = {
    resourceType: "Bundle",
    id: `bundle-${patient.id}`,
    type: "document",
    timestamp: new Date().toISOString(),
    entry: [
      {
        resource: {
          resourceType: "Patient",
          id: patient.id,
          identifier: [{ system: "https://healthid.ndhm.gov.in", value: patient.abhaId || "91-4528-9021-0044" }],
          name: [{ use: "official", text: patient.name }],
          gender: patient.gender.toLowerCase(),
          birthDate: patient.dob,
          telecom: [{ system: "phone", value: patient.phone }]
        }
      },
      {
        resource: {
          resourceType: "Encounter",
          id: `enc-${patient.id}`,
          status: "in-progress",
          class: { system: "http://terminology.hl7.org/CodeSystem/v3-ActCode", code: "AMB", display: "Ambulatory OPD" }
        }
      },
      ...patient.symptoms.map((sym, i) => ({
        resource: {
          resourceType: "Condition",
          id: `cond-${i + 1}`,
          code: { text: sym }
        }
      })),
      {
        resource: {
          resourceType: "Observation",
          id: `obs-vitals`,
          component: [
            { code: { text: "Temp" }, valueString: patient.vitals.temp },
            { code: { text: "BP" }, valueString: patient.vitals.bp },
            { code: { text: "Heart Rate" }, valueString: patient.vitals.hr },
            { code: { text: "SpO2" }, valueString: patient.vitals.spo2 }
          ]
        }
      },
      ...patient.prescriptions.map(rx => ({
        resource: {
          resourceType: "MedicationStatement",
          id: rx.id,
          medicationCodeableConcept: { text: `${rx.medicine} (${rx.dosage})` },
          dosage: [{ text: `${rx.frequency} for ${rx.duration}` }]
        }
      }))
    ]
  };

  const fhirJsonString = JSON.stringify(fhirBundle, null, 2);

  const handleCopy = () => {
    navigator.clipboard.writeText(fhirJsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-slate-900 rounded-2xl p-6 md:p-8 max-w-2xl w-full border border-slate-700 shadow-2xl animate-fadeIn flex flex-col max-h-[85vh] text-slate-100">
        <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center">
              <FileCode2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-white">FHIR R4 Diagnostic Bundle</h3>
              <p className="text-xs text-slate-400">ABDM Health Information Exchange (HIE) Specification</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-800 text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto bg-slate-950 text-emerald-400 p-4 rounded-xl font-mono text-[11px] leading-relaxed border border-slate-800">
          <pre>{fhirJsonString}</pre>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-800 mt-4 shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>HL7 FHIR R4 JSON Payload</span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleCopy}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold uppercase tracking-wider border border-slate-700 transition-colors flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-teal-500 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ----------------------------------------------------
// 5. QR CODE SCANNER MODAL (ABHA SCANNER)
// ----------------------------------------------------
interface QrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (abhaId: string) => void;
}

export const QrScannerModal: React.FC<QrScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess
}) => {
  if (!isOpen) return null;

  const handleSimulateScan = () => {
    audioService.playBeep('success');
    onScanSuccess("91-4528-9021-0044");
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-slate-900 rounded-2xl p-6 max-w-sm w-full border border-slate-700 shadow-2xl animate-fadeIn text-center text-slate-100">
        <div className="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
          <h3 className="font-serif font-bold text-base text-white flex items-center gap-2">
            <QrCode className="w-4 h-4 text-teal-400" />
            <span>Scan ABHA QR Code</span>
          </h3>
          <button onClick={onClose} className="text-xs font-bold text-slate-400">✕</button>
        </div>

        <div className="w-48 h-48 mx-auto bg-slate-950 rounded-2xl border-2 border-dashed border-teal-500 flex flex-col items-center justify-center relative overflow-hidden my-4">
          <div className="w-36 h-36 border border-teal-500/40 rounded-xl relative flex items-center justify-center">
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-teal-400 animate-pulse" />
            <QrCode className="w-16 h-16 text-teal-500/50" />
          </div>
          <span className="text-[10px] text-teal-400/80 font-mono mt-2">Align QR Code within frame</span>
        </div>

        <button
          onClick={handleSimulateScan}
          className="w-full py-3 bg-teal-600 text-white rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-teal-500 transition-colors shadow-md active:scale-95"
        >
          Simulate Successful QR Scan
        </button>
      </div>
    </div>
  );
};
