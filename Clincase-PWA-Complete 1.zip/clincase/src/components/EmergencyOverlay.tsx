import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  Clock, 
  ShieldAlert, 
  HeartPulse, 
  Truck, 
  Building2, 
  UserCheck, 
  PhoneCall, 
  ExternalLink,
  MapPin,
  CheckCircle2,
  Navigation
} from 'lucide-react';
import { LanguageCode, EmergencyDispatchRecord } from '../types';
import { translations } from '../data/translations';
import { triggerDirectEmergencyDispatch, fetchNearbyEmergencyFacilities } from '../services/emergencyService';

interface EmergencyOverlayProps {
  lang: LanguageCode;
  kioskId?: string;
  sessionId?: string;
  patientName?: string;
  symptom?: string;
  onDismissManual?: () => void;
}

export const EmergencyOverlay: React.FC<EmergencyOverlayProps> = ({
  lang,
  kioskId = 'Kiosk-01',
  sessionId = 'MED-49201',
  patientName = 'Patient',
  symptom = 'Acute Clinical Distress / Red Flag Escalation',
  onDismissManual
}) => {
  const t = translations[lang] || translations.en;
  const [dispatch, setDispatch] = useState<EmergencyDispatchRecord | null>(null);
  const [countdown, setCountdown] = useState(180); // 3 minutes ETA countdown

  useEffect(() => {
    // Automatically initiate direct contact to nearby hospital, doctor, and ambulance
    let isMounted = true;
    triggerDirectEmergencyDispatch({
      sessionId,
      patientName,
      symptom,
      kioskId
    }).then((res) => {
      if (isMounted) {
        setDispatch(res);
      }
    });

    // ETA countdown timer simulation
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 10 ? prev - 1 : 10));
    }, 1000);

    return () => {
      isMounted = false;
      clearInterval(timer);
    };
  }, [sessionId, patientName, symptom, kioskId]);

  const nearestHospital = dispatch?.nearbyHospitals?.[0];
  const dispatchedAmbulance = dispatch?.dispatchedAmbulance;
  const onDutyDoctor = dispatch?.contactedDoctor;

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#BA1A1A] text-white flex flex-col items-center justify-start p-4 sm:p-6 select-none overflow-y-auto animate-fadeIn">
      <div className="text-center max-w-2xl mx-auto space-y-4 my-auto w-full">
        {/* Pulsing Alert Icon */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white text-[#BA1A1A] flex items-center justify-center mx-auto shadow-2xl animate-bounce">
          <HeartPulse className="w-8 h-8 sm:w-10 sm:h-10 text-[#BA1A1A]" />
        </div>

        <div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold font-serif">
            {t.nurseAlertTitle}
          </h1>
          <p className="text-sm sm:text-base text-white/90 font-medium mt-1">
            {t.nurseAlertSubtitle}
          </p>
          <p className="text-xs text-white/80 mt-1">
            Nearby Emergency Hospital, On-Call Doctor, and Ambulance have been directly notified via Google Live Data.
          </p>
        </div>

        {/* Real-time Emergency Dispatch Cards (Ambulance, Hospital, Doctor) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-left">
          
          {/* 1. Nearest Dispatched Ambulance */}
          <div className="p-3.5 bg-white/10 rounded-2xl border border-white/20 backdrop-blur-md flex flex-col justify-between shadow-sm">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-emerald-300">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
                  <span>Ambulance Dispatched</span>
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </div>
              <p className="text-xs font-bold text-white line-clamp-1">
                {dispatchedAmbulance?.serviceName || "108 Emergency Cardiac Support"}
              </p>
              <div className="text-[11px] text-white/80 space-y-0.5">
                <p>ETA: <span className="font-mono font-bold text-amber-200">{formatCountdown(countdown)} mins</span> ({dispatchedAmbulance?.currentDistanceKm || 0.8} km)</p>
                <p className="text-[10px] text-white/70">Vehicle: {dispatchedAmbulance?.vehicleNumber || "TN-01-EM-4892"}</p>
              </div>
            </div>

            <a
              href={`tel:${dispatchedAmbulance?.phone || '108'}`}
              className="mt-3 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors shadow-sm"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Call Paramedic ({dispatchedAmbulance?.phone || '108'})</span>
            </a>
          </div>

          {/* 2. Nearest Hospital Contacted */}
          <div className="p-3.5 bg-white/10 rounded-2xl border border-white/20 backdrop-blur-md flex flex-col justify-between shadow-sm">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-sky-200">
                <span className="flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-sky-200" />
                  <span>Hospital ED Notified</span>
                </span>
                <span className="px-1.5 py-0.5 bg-sky-500/30 text-[10px] rounded font-mono">
                  {nearestHospital?.distanceKm || 1.1} km
                </span>
              </div>
              <p className="text-xs font-bold text-white line-clamp-1">
                {nearestHospital?.name || "Apollo Trauma & Emergency"}
              </p>
              <div className="text-[11px] text-white/80 space-y-0.5">
                <p>{nearestHospital?.traumaLevel || "Level 1 Trauma Center"}</p>
                <p className="text-[10px] text-white/70">ICU Beds: {nearestHospital?.icuBedsAvailable || 8} available</p>
              </div>
            </div>

            <div className="mt-3 flex items-center gap-1.5">
              <a
                href={`tel:${nearestHospital?.phone || '+914428290200'}`}
                className="flex-1 inline-flex items-center justify-center gap-1 px-2 py-1.5 bg-white/20 hover:bg-white/30 text-white rounded-xl text-[11px] font-bold transition-colors"
              >
                <PhoneCall className="w-3 h-3" />
                <span>Call ED</span>
              </a>
              <a
                href={nearestHospital?.googleMapsUrl || "https://www.google.com/maps/search/?api=1&query=Apollo+Hospital+Emergency&utm_campaign=gmp_git_agentskills_v1"}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 bg-white/20 hover:bg-white/30 text-white rounded-xl transition-colors"
                title="View on Google Maps"
              >
                <Navigation className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* 3. On-Duty Doctor Paged */}
          <div className="p-3.5 bg-white/10 rounded-2xl border border-white/20 backdrop-blur-md flex flex-col justify-between shadow-sm">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-rose-200">
                <span className="flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-rose-200" />
                  <span>Doctor Paged</span>
                </span>
                <span className="px-1.5 py-0.5 bg-rose-500/30 text-[10px] rounded font-bold">
                  HIGH PRIORITY
                </span>
              </div>
              <p className="text-xs font-bold text-white line-clamp-1">
                {onDutyDoctor?.name || "Dr. Arvind Varma, MD"}
              </p>
              <div className="text-[11px] text-white/80 space-y-0.5">
                <p>{onDutyDoctor?.specialty || "Chief of Emergency Care"}</p>
                <p className="text-[10px] text-white/70">Response: {onDutyDoctor?.estimatedResponseTime || "Immediate (Inside Ward)"}</p>
              </div>
            </div>

            <a
              href={`tel:${onDutyDoctor?.phone || '+919876512345'}`}
              className="mt-3 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white rounded-xl text-xs font-bold transition-colors shadow-sm"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Direct Page Doctor</span>
            </a>
          </div>

        </div>

        {/* Live Status Holding Banner */}
        <div className="p-3 bg-white/10 rounded-2xl border border-white/20 backdrop-blur-xs space-y-1">
          <div className="flex items-center justify-center gap-2 text-xs sm:text-sm font-bold tracking-wide text-white">
            <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
            <span>Kiosk Locked for Priority Resuscitation • Nurse & Attendant Alerted</span>
          </div>
          <p className="text-[11px] font-mono text-white/70">
            {kioskId} • Session ID: {sessionId} • Live Google Maps Data Integration Active
          </p>
        </div>

        {/* Manual Dev Dismiss Button (for demo recovery) */}
        {onDismissManual && (
          <div className="pt-2">
            <button
              onClick={onDismissManual}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-[11px] font-bold uppercase tracking-wider border border-white/20 transition-colors"
            >
              Simulate Nurse Arrival (Dismiss Alert)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
