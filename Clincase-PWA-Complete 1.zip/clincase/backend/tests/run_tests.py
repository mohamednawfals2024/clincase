import sys
import os
import asyncio
import unittest
from fastapi.testclient import TestClient

# Add backend directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app.main import app
from app.database import engine, Base, AsyncSessionLocal
from app.models.patient import PatientRecordModel
from app.core.security import create_access_token

class TestClincaseBackend(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Create database tables synchronously / via asyncio before running tests
        async def init_tables():
            async with engine.begin() as conn:
                await conn.run_sync(Base.metadata.drop_all)
                await conn.run_sync(Base.metadata.create_all)
            
            # Seed synthetic test patient MED-49201
            async with AsyncSessionLocal() as session:
                existing = await session.get(PatientRecordModel, "MED-49201")
                if not existing:
                    p = PatientRecordModel(
                        id="MED-49201",
                        abha_id="91-4528-9021-0044",
                        name="John Doe",
                        gender="Male",
                        age=45,
                        dob="15-May-1979",
                        phone="9876543210",
                        consent_given=True,
                        vitals_json={"temp": "99.4 °F", "bp": "124/82 mmHg", "hr": "78 bpm", "spo2": "98%"},
                        allergies_json=[{"name": "Penicillin", "reaction": "Severe"}],
                        lab_results_json=[{"test": "CBC", "result": "11,800", "refRange": "4,500-11,000", "status": "High"}],
                        consult_type="allopathic",
                        status="active"
                    )
                    session.add(p)
                    await session.commit()
                    
        asyncio.run(init_tables())

        cls.client = TestClient(app)
        cls.doctor_token = create_access_token({"sub": "DOC-MD-8921", "role": "doctor"})
        cls.doctor_headers = {"Authorization": f"Bearer {cls.doctor_token}"}

    def test_01_health_check(self):
        res = self.client.get("/api/health")
        self.assertEqual(res.status_code, 200)
        self.assertIn("healthy", res.json()["status"])

    def test_02_patient_registration_success(self):
        payload = {
            "name": "Synthetic Test Patient",
            "age": 42,
            "gender": "Male",
            "dob": "12-Aug-1984",
            "phone": "9988776655",
            "abhaId": "91-9988-7766-5544",
            "consultType": "allopathic"
        }
        res = self.client.post("/api/v1/patients/register", json=payload)
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data["name"], "Synthetic Test Patient")
        self.assertEqual(data["phone"], "9988776655")

    def test_03_patient_identification_lookup(self):
        res = self.client.post("/api/v1/patients/identify", json={"identifier": "9876543210"})
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["phone"], "9876543210")

    def test_04_record_dpdp_consent(self):
        payload = {
            "patientId": "MED-49201",
            "purposeCode": "CA_OPD_CLINICAL_INTAKE",
            "validDays": 365
        }
        res = self.client.post("/api/v1/consent/record", json=payload)
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data["consentId"], "DPDP-CR-MED-49201")
        self.assertEqual(len(data["digitalSignature"]), 64)

    def test_05_start_history_session(self):
        payload = {"patientId": "MED-49201", "consultType": "allopathic"}
        res = self.client.post("/api/v1/clinical/sessions/start", json=payload)
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data["patient_id"], "MED-49201")

    def test_06_record_history_answers(self):
        payload = {
            "step": 2,
            "symptoms": ["Right Abdominal Pain", "Low Grade Fever"],
            "chiefComplaint": "Severe cramping pain in the right lower abdomen for 2 days"
        }
        res = self.client.post("/api/v1/clinical/sessions/MED-49201/answers", json=payload)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.json()["status"], "success")

    def test_07_adaptive_question_generation(self):
        payload = {
            "sessionId": "MED-49201",
            "chiefComplaint": "Severe cramping pain in right lower abdomen for 2 days",
            "currentStep": 1
        }
        res = self.client.post("/api/v1/ai/adaptive-question", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertEqual(data["category"], "Abdominal")
        self.assertEqual(data["targetSection"], "SOCRATES_PAIN")

    def test_08_document_pipeline_ocr(self):
        import io
        fake_pdf = b"%PDF-1.4 Fake Synthetic Prescription File"
        files = {"file": ("Prescription_Synthetic.pdf", io.BytesIO(fake_pdf), "application/pdf")}
        res = self.client.post("/api/v1/documents/pipeline", data={"sessionId": "MED-49201"}, files=files)
        self.assertEqual(res.status_code, 201)
        data = res.json()
        self.assertEqual(data["fileName"], "Prescription_Synthetic.pdf")
        self.assertIn("rawDocumentUrl", data)

    def test_09_medical_timeline_retrieval(self):
        res = self.client.get("/api/v1/timeline/MED-49201")
        self.assertEqual(res.status_code, 200)
        self.assertTrue(isinstance(res.json(), list))

    def test_10_redflag_emergency_detection(self):
        payload = {
            "sessionId": "MED-49201",
            "chiefComplaint": "Crushing chest pain radiating to left arm",
            "currentStep": 1
        }
        res = self.client.post("/api/v1/ai/adaptive-question", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["isRedFlag"])
        self.assertEqual(data["targetSection"], "TRIAGE_EMERGENCY")

    def test_11_physician_summary_retrieval(self):
        res = self.client.get("/api/v1/physician/summary/MED-49201")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("vitals", data)
        self.assertIn("allergies", data)

    def test_12_drug_interaction_checker(self):
        payload = {
            "candidateMedicine": "Tab. Diclofenac 50 mg",
            "currentPrescriptions": [{"medicine": "Tab. Telmisartan 40 mg"}],
            "knownAllergies": [{"name": "Penicillin"}]
        }
        res = self.client.post("/api/v1/doctor/check-interactions", json=payload, headers=self.doctor_headers)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(len(data["warnings"]) > 0)

if __name__ == "__main__":
    unittest.main()
