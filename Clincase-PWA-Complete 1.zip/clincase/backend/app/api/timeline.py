from fastapi import APIRouter, Depends
from typing import List
from app.schemas.timeline import TimelineEventSchema, PatientAppointmentSchema, PatientVisitRecordSchema
from app.core.rbac import allow_guest

router = APIRouter(prefix="/timeline", tags=["Medical Timeline & Appointments"])

@router.get("/{patient_id}", response_model=List[TimelineEventSchema])
async def get_patient_timeline(patient_id: str, current_user: dict = Depends(allow_guest)):
    """Fetch chronological medical timeline events for a patient"""
    return [
        TimelineEventSchema(id="tl-1", date="Today, 10:15 AM", title="Lab_Report_Hemogram.pdf", type="lab", summary="CBC shows mild leukocytosis (11,800/uL)"),
        TimelineEventSchema(id="tl-2", date="Today, 10:14 AM", title="Prescription_01_DrRao.pdf", type="prescription", summary="Anti-pyretic & PPI prescribed at primary clinic"),
        TimelineEventSchema(id="tl-3", date="Today, 10:00 AM", title="OPD Kiosk Registration", type="clinical", summary="Patient checked in via Clincase Kiosk (AES-256 Encrypted)")
    ]

@router.get("/appointments/{patient_id}", response_model=List[PatientAppointmentSchema])
async def get_appointments(patient_id: str, current_user: dict = Depends(allow_guest)):
    """Fetch scheduled OPD appointments for a patient"""
    return [
        PatientAppointmentSchema(
            id="apt-1",
            doctorName="Dr. Arvind Varma, MD",
            department="General Medicine",
            specialty="Internal Medicine & Gastroenterology",
            date="Today",
            time="11:30 AM",
            type="In-Person OPD",
            status="Confirmed",
            tokenNumber="OPD-A-042",
            roomNumber="Room 108, Ground Floor",
            notes="Follow up on abdominal pain & lab CBC report review",
            instructions="Please bring all past prescriptions & ABHA card"
        )
    ]

@router.get("/visits/{patient_id}", response_model=List[PatientVisitRecordSchema])
async def get_past_visits(patient_id: str, current_user: dict = Depends(allow_guest)):
    """Fetch past medical visit records"""
    return [
        PatientVisitRecordSchema(
            id="visit-101",
            date="14-Jan-2026",
            doctorName="Dr. S. K. Ramanathan, MD",
            department="Cardiology & Internal Med",
            hospitalOrClinic="City General OPD Care",
            diagnosis=["Acute Gastritis", "Mild Essential Hypertension"],
            chiefComplaint="Epigastric burning pain and dyspepsia after meals for 3 days",
            treatmentType="Allopathic",
            vitalsSummary="BP: 126/82 mmHg | Temp: 98.4°F | Pulse: 76 bpm",
            prescriptions=["Tab. Pantoprazole 40mg OD x 14d", "Tab. Telmisartan 40mg OD x 30d"],
            clinicalSummary="Patient advised low-sodium diet, avoidance of spicy foods, and regular BP monitoring.",
            followUpDate="14-Feb-2026",
            attachmentsCount=2
        )
    ]
