from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from typing import Optional

from app.schemas.speech import TranscriptionResponse
from app.services.stt.factory import get_stt_provider
from app.core.rbac import allow_guest

router = APIRouter(prefix="/speech", tags=["Speech-to-Text (STT) Abstraction"])

@router.post(
    "/transcribe", 
    response_model=TranscriptionResponse,
    status_code=status.HTTP_200_OK,
    summary="Transcribe Audio File to Text",
    description="Accepts multipart audio upload (.wav, .mp3, .m4a, .ogg, .webm) and transcribes it using the configured STT_PROVIDER."
)
async def transcribe_audio(
    file: UploadFile = File(...),
    language: Optional[str] = Form("en"),
    current_user: dict = Depends(allow_guest)
):
    if not file or not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Valid audio file upload is required"
        )

    content = await file.read()
    if len(content) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Uploaded audio file is empty (0 bytes)"
        )

    provider = get_stt_provider()
    result = await provider.transcribe(
        audio_bytes=content,
        filename=file.filename,
        content_type=file.content_type or "audio/wav",
        language=language or "en"
    )

    return TranscriptionResponse(
        text=result.text,
        confidence=result.confidence,
        language=result.language,
        provider=result.provider
    )
