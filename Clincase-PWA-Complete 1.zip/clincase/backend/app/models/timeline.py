from sqlalchemy import Column, String, DateTime, JSON, ForeignKey
from datetime import datetime
from app.database import Base

class MedicalTimelineEventModel(Base):
    __tablename__ = "medical_timeline_events"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    event_date = Column(String, nullable=False)
    title = Column(String, nullable=False)
    event_type = Column(String, nullable=False)  # prescription, lab, clinical, ayush
    summary = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class PatientAppointmentModel(Base):
    __tablename__ = "patient_appointments"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    doctor_name = Column(String, nullable=False)
    department = Column(String, nullable=False)
    specialty = Column(String, nullable=False)
    date = Column(String, nullable=False)
    time = Column(String, nullable=False)
    type = Column(String, nullable=False)
    status = Column(String, default="Confirmed")
    token_number = Column(String, nullable=False)
    room_number = Column(String, nullable=False)
    notes = Column(String, nullable=True)
    instructions = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class PatientVisitRecordModel(Base):
    __tablename__ = "patient_visit_records"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    date = Column(String, nullable=False)
    doctor_name = Column(String, nullable=False)
    department = Column(String, nullable=False)
    hospital_or_clinic = Column(String, nullable=False)
    diagnosis = Column(JSON, default=list)
    chief_complaint = Column(String, nullable=False)
    treatment_type = Column(String, default="Allopathic")
    vitals_summary = Column(String, nullable=False)
    prescriptions = Column(JSON, default=list)
    clinical_summary = Column(String, nullable=False)
    follow_up_date = Column(String, nullable=True)
    attachments_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
