from pydantic import BaseModel
from typing import Optional

class ExtractedMedicalEntityCreate(BaseModel):
    document_id: str
    entity_type: str  # medication, lab_value, diagnosis
    medication_name: Optional[str] = None
    dosage: Optional[str] = None
    frequency: Optional[str] = None
    duration: Optional[str] = None
    instructions: Optional[str] = None
    lab_test_name: Optional[str] = None
    lab_value: Optional[str] = None
    lab_unit: Optional[str] = None
    reference_range: Optional[str] = None
    lab_status: Optional[str] = None
    confidence: Optional[float] = 95.0

class ExtractedMedicalEntityResponse(BaseModel):
    id: str
    document_id: str
    entity_type: str
    medication_name: Optional[str] = None
    dosage: Optional[str] = None
    frequency: Optional[str] = None
    duration: Optional[str] = None
    instructions: Optional[str] = None
    lab_test_name: Optional[str] = None
    lab_value: Optional[str] = None
    lab_unit: Optional[str] = None
    reference_range: Optional[str] = None
    lab_status: Optional[str] = None
    confidence: float = 95.0
