from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.patient import PatientRecordModel
from app.schemas.patient import PatientResponse
from app.core.rbac import allow_guest

router = APIRouter(prefix="/physician", tags=["Physician Summary & Workstation"])

@router.get(
    "/summary/{patient_id}", 
    response_model=PatientResponse,
    summary="Retrieve Physician EMR Summary",
    description="Retrieves complete structured EMR summary for the Doctor Workstation (Vitals, HPI, active prescriptions, lab results, OCR entities, and timeline)."
)
async def get_physician_summary(
    patient_id: str, 
    db: AsyncSession = Depends(get_db), 
    current_user: dict = Depends(allow_guest)
):
    result = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == patient_id))
    p = result.scalars().first()
    
    if not p:
        # Fallback default lookup
        result_default = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == "MED-49201"))
        p = result_default.scalars().first()
        if not p:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, 
                detail=f"Patient session '{patient_id}' not found"
            )

    return PatientResponse(
        id=p.id,
        abhaId=p.abha_id,
        name=p.name,
        gender=p.gender,
        age=p.age,
        dob=p.dob,
        phone=p.phone,
        consentGiven=p.consent_given,
        currentStep=p.current_step,
        symptoms=p.symptoms or [],
        chiefComplaintDetails=p.chief_complaint_details or "",
        hpiDetails=p.hpi_details or "",
        pastHistoryDetails=p.past_history_details or "",
        pastSurgicalDetails=p.past_surgical_details or "",
        medicationHistoryDetails=p.medication_history_details or "",
        allergyHistoryDetails=p.allergy_history_details or "",
        familyHistoryDetails=p.family_history_details or "",
        lifestyleDetails=p.lifestyle_details or "",
        vitals=p.vitals or {"temp": "98.6 °F", "bp": "120/80 mmHg", "hr": "72 bpm", "spo2": "98%"},
        allergies=p.allergies or [],
        labResults=p.lab_results or [],
        consultType=p.consult_type or "allopathic",
        status=p.status or "active",
        ayushDetails=p.ayush_details,
        isPiiMasked=p.is_pii_masked,
        securityHash=p.security_hash,
        createdAt=p.created_at.isoformat() if p.created_at else "2026-08-30T00:00:00.000Z"
    )
