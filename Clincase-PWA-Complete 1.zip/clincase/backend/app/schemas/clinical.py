from pydantic import BaseModel, Field
from typing import Optional, Dict, List, Any

class SocratesPainSchema(BaseModel):
    site: Optional[str] = None
    onset: Optional[str] = None
    character: Optional[str] = None
    radiation: Optional[str] = None
    associatedSymptoms: Optional[str] = None
    timing: Optional[str] = None
    exacerbatingRelieving: Optional[str] = None
    severityScale: Optional[int] = 5

class ROSSchema(BaseModel):
    general: Optional[str] = None
    cardiovascular: Optional[str] = None
    respiratory: Optional[str] = None
    gastrointestinal: Optional[str] = None
    musculoskeletal: Optional[str] = None
    neurological: Optional[str] = None
    dermatological: Optional[str] = None
    genitourinary: Optional[str] = None

class DashavidhaSchema(BaseModel):
    Prakriti: Optional[str] = None
    Vikriti: Optional[str] = None
    Sara: Optional[str] = None
    Samhanana: Optional[str] = None
    Pramana: Optional[str] = None
    Satmya: Optional[str] = None
    Sattva: Optional[str] = None
    AharaShakti: Optional[str] = None
    VyayamaShakti: Optional[str] = None
    Vaya: Optional[str] = None
    AharaVihara: Optional[str] = None

class HistorySessionStartRequest(BaseModel):
    patientId: str = Field(..., description="Target Patient Session ID (e.g. MED-49201)")
    consultType: Optional[str] = Field("allopathic", description="allopathic or ayush")

class HistorySessionAnswerRequest(BaseModel):
    step: int = Field(..., ge=1, le=10, description="Intake Step Counter")
    symptoms: Optional[List[str]] = Field(default=[], description="List of reported symptoms")
    chiefComplaint: Optional[str] = Field(None, description="Detailed chief complaint text")
    hpiText: Optional[str] = Field(None, description="History of Present Illness details")
    socratesPain: Optional[SocratesPainSchema] = None
    reviewOfSystems: Optional[ROSSchema] = None
    ayushDetails: Optional[DashavidhaSchema] = None

class ConversationalRequest(BaseModel):
    sessionId: str
    userUtterance: str
    step: Optional[int] = 1
    consultType: Optional[str] = "allopathic"
    currentAyushParam: Optional[str] = None
    language: Optional[str] = "en"

class ConversationalResponse(BaseModel):
    spokenResponse: str
    extractedSymptoms: List[str]
    isRedFlag: bool = False
    redFlagReason: Optional[str] = None
    clinicalSummaryFragment: Optional[str] = None
    nextStepGuidance: str = "Proceeding to next step"
