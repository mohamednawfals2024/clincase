def test_start_history_session(client):
    """Test POST /api/v1/clinical/sessions/start"""
    payload = {
        "patientId": "MED-49201",
        "consultType": "allopathic"
    }
    response = client.post("/api/v1/clinical/sessions/start", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["patient_id"] == "MED-49201"
    assert data["current_step"] == 1
    assert data["status"] == "active"
    assert "id" in data

def test_record_history_answers(client):
    """Test POST /api/v1/clinical/sessions/{session_id}/answers"""
    payload = {
        "step": 2,
        "symptoms": ["Acute Right Abdominal Cramps", "Low Grade Fever"],
        "chiefComplaint": "Severe cramping pain in the right lower abdomen starting yesterday evening",
        "hpiText": "45-year-old male presents with 36-hour history of acute right lower quadrant pain."
    }
    response = client.post("/api/v1/clinical/sessions/MED-49201/answers", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert data["step"] == 2
