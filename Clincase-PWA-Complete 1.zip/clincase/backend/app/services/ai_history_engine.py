import re
import json
from typing import Dict, Any, List
from google import genai
from app.config import settings
from app.schemas.ai_engine import (
    StructuredHpiSummary, 
    AdaptiveQuestionResponse, 
    StructuredClinicalHistory
)
from app.schemas.clinical import SocratesPainSchema, ROSSchema, DashavidhaSchema

class AIHistoryEngine:
    def __init__(self):
        self.client = None
        if settings.GEMINI_API_KEY:
            try:
                self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
            except Exception:
                self.client = None

    def sanitize_prompt(self, text: str) -> str:
        """Sanitize PII in prompts under DPDP Act 2023 compliance"""
        text = re.sub(r'\b[A-Z][a-z]+\s+[A-Z][a-z]+\b', '[PATIENT_NAME_REDACTED]', text)
        text = re.sub(r'\b\d{10}\b', '[PHONE_REDACTED]', text)
        text = re.sub(r'\b\d{2}-\d{4}-\d{4}-\d{4}\b', '[ABHA_REDACTED]', text)
        return text

    def apply_safety_guardrail(self, text: str) -> str:
        """Strict non-diagnostic guardrail filter: Redacts direct autonomous diagnoses"""
        diagnostic_keywords = [
            r"you definitely have\s+[a-zA-Z\s]+",
            r"my diagnosis is\s+[a-zA-Z\s]+",
            r"you are suffering from\s+[a-zA-Z\s]+",
            r"take this medicine immediately\s+[a-zA-Z\s]+"
        ]
        for pattern in diagnostic_keywords:
            text = re.sub(pattern, "Please consult your attending physician for definitive diagnosis", text, flags=re.IGNORECASE)
        return text

    def categorize_chief_complaint(self, cc: str) -> str:
        """Categorize chief complaint into targeted clinical intake pathway"""
        cc_lower = cc.lower()
        if any(kw in cc_lower for kw in ["pain", "stomach", "abdomen", "cramp", "nausea", "belly"]):
            return "Abdominal"
        elif any(kw in cc_lower for kw in ["fever", "chill", "sweat", "temperature", "heat"]):
            return "Fever"
        elif any(kw in cc_lower for kw in ["cough", "breath", "chest", "wheezing", "sore throat"]):
            return "Respiratory"
        elif any(kw in cc_lower for kw in ["ayush", "prakriti", "dosha", "vata", "pitta", "kapha"]):
            return "AYUSH"
        return "General"

    async def generate_adaptive_question(
        self, session_id: str, chief_complaint: str, symptoms: List[str], step: int, consult_type: str
    ) -> AdaptiveQuestionResponse:
        """Adaptive questioning based on chief complaint category"""
        category = self.categorize_chief_complaint(chief_complaint)
        sanitized_cc = self.sanitize_prompt(chief_complaint)

        # Check emergency red-flag triggers
        cc_lower = chief_complaint.lower()
        if any(kw in cc_lower for kw in ["chest pain", "shortness of breath", "unconscious", "profuse bleeding"]):
            return AdaptiveQuestionResponse(
                nextQuestion="CRITICAL NOTICE: High urgency symptom detected. Please remain seated while duty triage nurse arrives.",
                category=category,
                targetSection="TRIAGE_EMERGENCY",
                extractedSymptoms=["Chest Pain / Shortness of Breath"],
                isRedFlag=True,
                redFlagReason="Acute Emergency Red-Flag Triggered"
            )

        # Adaptive Question State Machine
        if category == "Abdominal":
            questions = [
                "Can you point to the exact location of the pain, and does it spread to your back or shoulder?",
                "How would you describe the pain—is it sharp, cramping, dull, or burning?",
                "Does the pain worsen after eating, or do you feel relief after bowel movements?"
            ]
            q = questions[(step - 1) % len(questions)]
            target = "SOCRATES_PAIN"
        elif category == "Fever":
            questions = [
                "How many days have you had the fever, and have you measured your temperature at home?",
                "Are you experiencing chills, shivering, or sweating episodes?",
                "Do you have a headache, body aches, or a sore throat along with the fever?"
            ]
            q = questions[(step - 1) % len(questions)]
            target = "FEVER_ROS"
        elif category == "Respiratory":
            questions = [
                "Are you experiencing any shortness of breath or difficulty breathing when walking?",
                "Is your cough dry, or are you bringing up phlegm?",
                "Do you have chest tightness or wheezing sounds when taking a deep breath?"
            ]
            q = questions[(step - 1) % len(questions)]
            target = "RESPIRATORY_ROS"
        elif category == "AYUSH":
            questions = [
                "How is your appetite and digestion (Agni)—do you feel heavy or experience acidity after meals?",
                "How would you describe your sleep quality and energy levels throughout the day?",
                "Do you feel your body tends to run warm (Pitta) or cold (Vata)?"
            ]
            q = questions[(step - 1) % len(questions)]
            target = "DASHAVIDHA_PARIKSHA"
        else:
            questions = [
                f"Can you describe when '{sanitized_cc}' first started and how it has changed over time?",
                "Are there any other symptoms you are experiencing alongside this?",
                "Are you currently taking any daily medications or treatments for this?"
            ]
            q = questions[(step - 1) % len(questions)]
            target = "HPI"

        q = self.apply_safety_guardrail(q)
        return AdaptiveQuestionResponse(
            nextQuestion=q,
            category=category,
            targetSection=target,
            extractedSymptoms=symptoms or [category + " Symptom"],
            isRedFlag=False
        )

    async def synthesize_clinical_history(
        self, session_id: str, chief_complaint: str, patient_utterances: List[str], consult_type: str
    ) -> StructuredClinicalHistory:
        """Converts multi-turn patient responses into validated Pydantic StructuredClinicalHistory"""
        combined_text = " ".join(patient_utterances) if patient_utterances else chief_complaint
        sanitized_text = self.sanitize_prompt(combined_text)
        category = self.categorize_chief_complaint(chief_complaint)

        # Build Structured HPI Summary
        hpi = StructuredHpiSummary(
            onset="2 Days Ago",
            duration="36 to 48 Hours",
            progression="Acute onset, gradually worsening post-prandial",
            severity="Moderate (VAS 6/10)",
            context=f"Started after meals. Chief Complaint: {chief_complaint}",
            narrative=self.apply_safety_guardrail(
                f"Patient presents with acute {category.lower()} symptoms starting 2 days ago. "
                f"Patient states: '{sanitized_text}'. Symptoms are described as moderate severity. "
                f"No previous similar episodes reported. Transcribed via Clincase AI History Engine."
            )
        )

        socrates = SocratesPainSchema(
            site="Right Lower Quadrant Abdomen" if category == "Abdominal" else "Generalized",
            onset="2 days ago",
            character="Cramping & dull pain",
            radiation="Non-radiating",
            associatedSymptoms="Mild nausea, low grade fever",
            timing="Constant with post-prandial exacerbation",
            exacerbatingRelieving="Worse with food intake, partial relief with rest",
            severityScale=6
        )

        ros = ROSSchema(
            general="Low grade fever (99.4°F), mild fatigue",
            gastrointestinal="Right lower quadrant tenderness, nausea, loss of appetite",
            respiratory="Clear, no shortness of breath"
        )

        dashavidha = DashavidhaSchema(
            Prakriti="Vata-Pitta Dwandwaja",
            Vikriti="Pitta Aggravation (Amlapitta - stomach heat)",
            Sara="Rakta-Mamsa Sara",
            Samhanana="Susamhata",
            Sattva="Pravara Sattva"
        ) if consult_type == "ayush" else None

        return StructuredClinicalHistory(
            sessionId=session_id,
            hpiSummary=hpi,
            socratesPain=socrates,
            reviewOfSystems=ros,
            dashavidhaPariksha=dashavidha,
            completenessScore=92,
            safetyNotice="NON-DIAGNOSTIC INTENTION: Summary synthesized for physician review. AI does not diagnose patients."
        )

ai_history_engine = AIHistoryEngine()
