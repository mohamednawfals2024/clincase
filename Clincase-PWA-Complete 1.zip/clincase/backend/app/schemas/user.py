from pydantic import BaseModel
from typing import Optional

class DoctorUserCreate(BaseModel):
    username: str
    password: str
    full_name: str
    role: Optional[str] = "doctor"
    license_number: Optional[str] = None
    specialty: Optional[str] = None

class DoctorUserResponse(BaseModel):
    id: str
    username: str
    full_name: str
    role: str
    license_number: Optional[str] = None
    specialty: Optional[str] = None
    is_active: bool = True
