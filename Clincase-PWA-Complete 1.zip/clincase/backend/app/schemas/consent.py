from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class ConsentArtifactSchema(BaseModel):
    consentId: str
    patientId: str
    purposeCode: str = "CA_OPD_CLINICAL_INTAKE"
    grantedAt: str
    validUntil: str
    status: str = "ACTIVE_GRANTED"
    digitalSignature: str
    dataMinimizationScope: List[str] = ["VITALS", "SYMPTOMS", "HPI"]
    consentManagerId: str = "abdm.consent.gov.in"

class SecurityAuditBlockSchema(BaseModel):
    index: int
    timestamp: str
    action: str
    actor: str
    kioskId: str
    dataFingerprint: str
    previousHash: str
    hash: str
    verified: bool = True
    metadata: Optional[Dict[str, Any]] = None

class SecurityStatusSchema(BaseModel):
    encryptionStandard: str = "AES-256-GCM Hardware Accelerated"
    keyFingerprint: str
    dpdpCompliant: bool = True
    ephemeralAudioZeroRetention: bool = True
    rawDocumentPurged: bool = True
    totalAuditEvents: int
    piiMaskingActive: bool = True
    chainIntegrityValid: bool = True
    lastTamperCheck: str
    consentManagerEndpoint: str = "https://abdm.gov.in/consent-manager"
