from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, JSON
from datetime import datetime
from app.database import Base

class PatientModel(Base):
    __tablename__ = "patients"

    id = Column(String, primary_key=True, index=True)
    abha_id = Column(String, index=True, unique=True, nullable=True)
    name = Column(String, nullable=False)
    gender = Column(String, nullable=False)
    age = Column(Integer, nullable=False)
    dob = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    consent_given = Column(Boolean, default=True)
    current_step = Column(Integer, default=1)
    
    # Symptom & Intake Details
    symptoms = Column(JSON, default=list)
    chief_complaint_details = Column(Text, default="")
    hpi_details = Column(Text, default="")
    past_history_details = Column(Text, default="")
    past_surgical_details = Column(Text, default="")
    medication_history_details = Column(Text, default="")
    allergy_history_details = Column(Text, default="")
    family_history_details = Column(Text, default="")
    lifestyle_details = Column(Text, default="")
    ayush_details = Column(JSON, nullable=True)
    
    # Structured JSON Fields
    vitals_json = Column(JSON, nullable=False)
    allergies_json = Column(JSON, default=list)
    lab_results_json = Column(JSON, default=list)
    
    consult_type = Column(String, default="allopathic")  # allopathic, ayush
    status = Column(String, default="active")  # active, red_flag, acknowledged, completed
    is_pii_masked = Column(Boolean, default=True)
    security_hash = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    @property
    def vitals(self):
        return self.vitals_json

    @vitals.setter
    def vitals(self, val):
        self.vitals_json = val

    @property
    def allergies(self):
        return self.allergies_json

    @allergies.setter
    def allergies(self, val):
        self.allergies_json = val

    @property
    def lab_results(self):
        return self.lab_results_json

    @lab_results.setter
    def lab_results(self, val):
        self.lab_results_json = val

PatientRecordModel = PatientModel
