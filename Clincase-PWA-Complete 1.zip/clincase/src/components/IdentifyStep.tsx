import React, { useState } from 'react';
import { 
  CreditCard, 
  QrCode, 
  UserPlus, 
  CheckCircle, 
  Volume2, 
  ShieldCheck, 
  ArrowRight,
  Sparkles,
  KeyRound,
  User,
  Calendar,
  Clock
} from 'lucide-react';
import { PatientSession, LanguageCode } from '../types';
import { translations } from '../data/translations';
import { audioService } from '../services/api';

interface IdentifyStepProps {
  lang: LanguageCode;
  patient: PatientSession | null;
  onVerifyAbha: (abhaId: string) => void;
  onOpenPatientDashboard?: (abhaId: string) => void;
  onOpenNewRegistration: () => void;
  onOpenQrScanner: () => void;
  consentGiven: boolean;
  onToggleConsent: (val: boolean) => void;
}

export const IdentifyStep: React.FC<IdentifyStepProps> = ({
  lang,
  patient,
  onVerifyAbha,
  onOpenPatientDashboard,
  onOpenNewRegistration,
  onOpenQrScanner,
  consentGiven,
  onToggleConsent
}) => {
  const [abhaInput, setAbhaInput] = useState<string>(patient?.abhaId || "91-4528-9021-0044");
  const t = translations[lang] || translations.en;

  const handlePlayConsentAudio = () => {
    audioService.playBeep('click');
    audioService.speak(t.consentText, lang);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consentGiven) {
      alert("Please accept the voluntary consent declaration to proceed.");
      return;
    }
    audioService.playBeep('click');
    onVerifyAbha(abhaInput.trim() || "91-4528-9021-0044");
  };

  const handleDashboardAccess = () => {
    if (!consentGiven) {
      alert("Please accept the voluntary consent declaration to proceed.");
      return;
    }
    audioService.playBeep('click');
    if (onOpenPatientDashboard) {
      onOpenPatientDashboard(abhaInput.trim() || "91-4528-9021-0044");
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto flex flex-col gap-6 animate-fadeIn">
      {/* Title & Instructions */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-[#EBE8E3] text-[#1A1A1A] text-[10px] font-mono uppercase font-bold tracking-widest mb-2">
          Step 01 / 04 • Identity Verification & Authentication
        </div>
        <h1 className="text-2xl md:text-3xl font-bold font-serif text-[#1A1A1A]">
          {t.identifyTitle}
        </h1>
        <p className="text-xs md:text-sm text-[#5C5852] mt-1">
          {t.identifySubtitle}
        </p>
      </div>

      {/* Method 1: ABHA / Aadhaar ID Verification Card */}
      <div 
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-color)',
          color: 'var(--text-main)'
        }}
        className="border p-6 rounded-2xl shadow-md"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                Ayushman Bharat Health Account (ABHA)
              </h3>
              <p className="text-xs opacity-80" style={{ color: 'var(--text-muted)' }}>Enter your 14-digit ABHA Number or Mobile number</p>
            </div>
          </div>
          <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/20">
            ABDM Verified
          </span>
        </div>

        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[11px] font-bold uppercase tracking-wider opacity-80" style={{ color: 'var(--text-muted)' }}>
                ABHA ID / Aadhaar Linked Number
              </label>
              <button
                type="button"
                onClick={() => setAbhaInput("91-4528-9021-0044")}
                className="text-[10px] text-teal-400 hover:underline font-semibold"
              >
                Use Demo ABHA (John Doe)
              </button>
            </div>
            <div className="relative">
              <input
                type="text"
                value={abhaInput}
                onChange={(e) => setAbhaInput(e.target.value)}
                placeholder={t.enterIdPlaceholder}
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-main)'
                }}
                className="w-full h-12 px-4 rounded-xl border focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none font-mono text-sm font-semibold tracking-wide"
              />
              <KeyRound className="absolute right-3.5 top-3.5 w-5 h-5 opacity-40" />
            </div>
          </div>

          {/* Voluntary Consent Box */}
          <div 
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.03)',
              borderColor: 'var(--border-color)'
            }}
            className="p-4 rounded-xl border flex flex-col gap-2"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold" style={{ color: 'var(--text-main)' }}>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{t.consentTitle}</span>
              </div>
              <button
                type="button"
                onClick={handlePlayConsentAudio}
                className="flex items-center gap-1 text-[11px] text-teal-400 font-bold hover:underline"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>{t.listenToConsent}</span>
              </button>
            </div>
            <p className="text-[11px] leading-relaxed opacity-80" style={{ color: 'var(--text-muted)' }}>
              {t.consentText}
            </p>
            <label className="flex items-center gap-2.5 mt-1 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={consentGiven}
                onChange={(e) => onToggleConsent(e.target.checked)}
                className="w-4 h-4 rounded text-teal-500 focus:ring-teal-500 accent-teal-500"
              />
              <span className="text-xs font-semibold" style={{ color: 'var(--text-main)' }}>
                {t.consentCheckbox}
              </span>
            </label>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-1">
            <button
              type="submit"
              disabled={!consentGiven}
              className={`flex-1 h-12 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all ${
                consentGiven
                  ? 'bg-teal-600 hover:bg-teal-500 text-white cursor-pointer active:scale-98'
                  : 'bg-slate-700 text-slate-400 cursor-not-allowed opacity-60'
              }`}
            >
              <span>{t.verify} & Start Intake</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {onOpenPatientDashboard && (
              <button
                type="button"
                disabled={!consentGiven}
                onClick={handleDashboardAccess}
                className={`flex-1 h-12 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md border transition-all ${
                  consentGiven
                    ? 'bg-sky-600 hover:bg-sky-500 text-white border-sky-500 cursor-pointer active:scale-98'
                    : 'bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed opacity-60'
                }`}
                title="Authenticate and open your personal Medical History, Recent Visits & Upcoming Appointments Dashboard"
              >
                <User className="w-4 h-4" />
                <span>Patient Dashboard</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenQrScanner}
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.06)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="h-12 px-4 border hover:border-teal-500 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shrink-0"
            >
              <QrCode className="w-4 h-4 text-teal-400" />
              <span>Scan QR</span>
            </button>
          </div>
        </form>
      </div>

      {/* Divider */}
      <div className="flex items-center gap-4">
        <div className="h-px flex-1" style={{ backgroundColor: 'var(--border-color)' }} />
        <span className="text-xs font-bold tracking-widest uppercase opacity-60" style={{ color: 'var(--text-muted)' }}>
          {t.orDivider}
        </span>
        <div className="h-px flex-1" style={{ backgroundColor: 'var(--border-color)' }} />
      </div>

      {/* Method 2: Register New Patient Card */}
      <div 
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-color)',
          color: 'var(--text-main)'
        }}
        className="border p-6 rounded-2xl shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-400 flex items-center justify-center shrink-0">
            <UserPlus className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold font-serif" style={{ color: 'var(--text-main)' }}>
              {t.newPatientTitle}
            </h3>
            <p className="text-xs mt-0.5 opacity-80" style={{ color: 'var(--text-muted)' }}>
              {t.newPatientDesc}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenNewRegistration}
          className="w-full sm:w-auto px-5 h-11 bg-teal-600 hover:bg-teal-500 text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-colors shrink-0 shadow-sm"
        >
          {t.startNewRegistration}
        </button>
      </div>
    </div>
  );
};
