from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from app.schemas.clinical import SocratesPainSchema, ROSSchema, DashavidhaSchema

class StructuredHpiSummary(BaseModel):
    onset: str = Field(..., description="When symptoms first started")
    duration: str = Field(..., description="Duration of symptoms")
    progression: str = Field(..., description="Stable, worsening, or improving")
    severity: str = Field(..., description="Severity scale or description")
    context: str = Field(..., description="Context or triggering factors")
    narrative: str = Field(..., description="Synthesized HPI clinical narrative")

class AdaptiveQuestionRequest(BaseModel):
    sessionId: str
    chiefComplaint: str = Field(..., description="Patient's primary chief complaint")
    symptoms: List[str] = Field(default=[], description="List of currently extracted symptoms")
    currentStep: int = Field(1, description="Current intake step number")
    consultType: Optional[str] = Field("allopathic", description="allopathic or ayush")

class AdaptiveQuestionResponse(BaseModel):
    nextQuestion: str = Field(..., description="Targeted adaptive clinical question")
    category: str = Field(..., description="Abdominal, Fever, Respiratory, AYUSH, or General")
    targetSection: str = Field(..., description="HPI, SOCRATES, ROS, or Dashavidha")
    extractedSymptoms: List[str] = Field(default=[])
    isRedFlag: bool = False
    redFlagReason: Optional[str] = None

class StructuredHistoryRequest(BaseModel):
    sessionId: str
    chiefComplaint: str
    patientUtterances: List[str]
    vitals: Optional[Dict[str, str]] = None
    consultType: Optional[str] = "allopathic"

class StructuredClinicalHistory(BaseModel):
    sessionId: str
    hpiSummary: StructuredHpiSummary
    socratesPain: Optional[SocratesPainSchema] = None
    reviewOfSystems: Optional[ROSSchema] = None
    dashavidhaPariksha: Optional[DashavidhaSchema] = None
    completenessScore: int = Field(85, ge=0, le=100)
    safetyNotice: str = Field(
        "NON-DIAGNOSTIC INTENTION: Summary synthesized for physician review. AI does not diagnose patients.",
        description="Clinical safety compliance statement"
    )
