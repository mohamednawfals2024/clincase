from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Dict, Any

class VitalSignsSchema(BaseModel):
    temp: str = "98.6 °F"
    bp: str = "120/80 mmHg"
    hr: str = "72 bpm"
    spo2: str = "98%"
    respRate: Optional[str] = "16 bpm"

class AllergySchema(BaseModel):
    name: str
    reaction: str
    severity: Optional[str] = "Mild"

class LabResultSchema(BaseModel):
    test: str
    result: str
    refRange: str
    status: str = "Normal"

class PatientRegistrationRequest(BaseModel):
    name: str = Field(..., min_length=2, description="Patient Full Name")
    age: int = Field(..., ge=0, le=120, description="Patient Age in Years")
    gender: str = Field(..., description="Male, Female, or Other")
    dob: str = Field(..., description="Date of Birth in DD-Mon-YYYY format")
    phone: str = Field(..., description="10-digit primary contact phone number")
    abhaId: Optional[str] = Field(None, description="Optional ABHA ID (e.g. 91-4528-9021-0044)")
    consultType: Optional[str] = Field("allopathic", description="allopathic or ayush")
    vitals: Optional[VitalSignsSchema] = None

    @field_validator('phone')
    def validate_phone(cls, v):
        clean = v.replace(" ", "").replace("-", "").replace("+91", "")
        if not clean.isdigit() or len(clean) != 10:
            raise ValueError("Phone number must be a valid 10-digit Indian phone number")
        return clean

class PatientIdentificationRequest(BaseModel):
    identifier: str = Field(..., description="ABHA ID (91-4528-9021-0044) or 10-digit Phone number")

class PatientCreate(BaseModel):
    abhaId: Optional[str] = None
    name: Optional[str] = "John Doe"
    gender: Optional[str] = "Male"
    age: Optional[int] = 45
    dob: Optional[str] = "15-May-1979"
    phone: Optional[str] = "9876543210"
    consultType: Optional[str] = "allopathic"

class PatientUpdate(BaseModel):
    name: Optional[str] = None
    gender: Optional[str] = None
    age: Optional[int] = None
    dob: Optional[str] = None
    phone: Optional[str] = None
    symptoms: Optional[List[str]] = None
    chiefComplaintDetails: Optional[str] = None
    hpiDetails: Optional[str] = None
    vitals: Optional[VitalSignsSchema] = None
    consultType: Optional[str] = None
    status: Optional[str] = None

class PatientResponse(BaseModel):
    id: str
    abhaId: Optional[str] = None
    name: str
    gender: str
    age: int
    dob: str
    phone: str
    consentGiven: bool = True
    currentStep: int = 1
    symptoms: List[str] = []
    chiefComplaintDetails: Optional[str] = ""
    hpiDetails: Optional[str] = ""
    pastHistoryDetails: Optional[str] = ""
    pastSurgicalDetails: Optional[str] = ""
    medicationHistoryDetails: Optional[str] = ""
    allergyHistoryDetails: Optional[str] = ""
    familyHistoryDetails: Optional[str] = ""
    lifestyleDetails: Optional[str] = ""
    vitals: VitalSignsSchema
    allergies: List[AllergySchema] = []
    labResults: List[LabResultSchema] = []
    consultType: str = "allopathic"
    status: str = "active"
    ayushDetails: Optional[Dict[str, Any]] = None
    isPiiMasked: bool = True
    securityHash: Optional[str] = None
    createdAt: str
