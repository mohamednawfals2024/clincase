import React, { useState } from 'react';
import { 
  Stethoscope, 
  Plus, 
  Trash2, 
  FileText, 
  Sparkles, 
  Activity, 
  AlertTriangle, 
  ShieldCheck, 
  FileCode2, 
  Printer, 
  Leaf, 
  Clock, 
  Check, 
  RefreshCw,
  Heart,
  Thermometer,
  Wind,
  Zap,
  Gauge,
  Layers,
  HelpCircle,
  FileSearch,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { PatientSession, Prescription, ConsultType } from '../types';
import { generateAiSummary, audioService } from '../services/api';
import { calculateHistoryCompleteness } from '../data/clinicalQuestions';

interface PhysicianPortalProps {
  patient: PatientSession;
  onUpdatePatient: (updates: Partial<PatientSession>) => void;
  onOpenWriteRx: () => void;
  onOpenFhir: () => void;
  onOpenSecurity?: () => void;
}

export const PhysicianPortal: React.FC<PhysicianPortalProps> = ({
  patient,
  onUpdatePatient,
  onOpenWriteRx,
  onOpenFhir,
  onOpenSecurity
}) => {
  const [isRegeneratingHpi, setIsRegeneratingHpi] = useState<boolean>(false);
  const [isCopiedSummary, setIsCopiedSummary] = useState<boolean>(false);

  const initials = patient.name 
    ? patient.name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2) 
    : "PT";

  const isPurged = patient.documents?.some(d => d.url.includes("purged")) || patient.status === "acknowledged";
  const isAyush = patient.consultType === 'ayush';
  const completeness = calculateHistoryCompleteness(patient);

  const handleDeleteRx = (rxId: string) => {
    audioService.playBeep('click');
    const updated = (patient.prescriptions || []).filter(item => item.id !== rxId);
    onUpdatePatient({ prescriptions: updated });
  };

  const handleRegenerateHpiWithAi = async () => {
    setIsRegeneratingHpi(true);
    audioService.playBeep('click');
    try {
      const summary = await generateAiSummary({
        symptoms: patient.symptoms,
        chiefComplaint: patient.chiefComplaintDetails,
        consultType: patient.consultType,
        ayushDetails: patient.ayushDetails,
        pastHistory: patient.pastHistoryDetails,
        pastSurgical: patient.pastSurgicalDetails,
        medicationHistory: patient.medicationHistoryDetails,
        allergyHistory: patient.allergyHistoryDetails,
        familyHistory: patient.familyHistoryDetails,
        lifestyle: patient.lifestyleDetails,
        reviewOfSystems: patient.reviewOfSystems,
        socratesPain: patient.socratesPain,
        documents: patient.documents,
        labResults: patient.labResults,
        vitals: patient.vitals
      });
      onUpdatePatient({ hpiDetails: summary });
      audioService.playBeep('success');
    } catch (err) {
      console.error(err);
    } finally {
      setIsRegeneratingHpi(false);
    }
  };

  const handleCopyClinicalSummary = () => {
    const text = `
PATIENT CLINICAL SUMMARY: ${patient.name} (${patient.age}y/${patient.gender})
ABHA ID: ${patient.abhaId} | Session ID: ${patient.id}
CHIEF COMPLAINT: ${patient.chiefComplaintDetails || 'N/A'}
HPI: ${patient.hpiDetails || 'N/A'}
PAST MEDICAL/SURGICAL: ${patient.pastHistoryDetails || 'None'} / ${patient.pastSurgicalDetails || 'None'}
MEDICATIONS: ${patient.medicationHistoryDetails || 'None reported'}
ALLERGIES: ${patient.allergies?.map(a => `${a.name} (${a.reaction})`).join('; ') || 'NKDA'}
VITALS: Temp: ${patient.vitals?.temp}, BP: ${patient.vitals?.bp}, HR: ${patient.vitals?.hr}, SpO2: ${patient.vitals?.spo2}
PRESCRIPTIONS ISSUED:
${patient.prescriptions?.map(p => `- ${p.medicine} (${p.dosage}) | ${p.frequency} x ${p.duration} | ${p.instructions}`).join('\n') || 'None'}
    `.trim();

    navigator.clipboard.writeText(text);
    setIsCopiedSummary(true);
    setTimeout(() => setIsCopiedSummary(false), 2000);
  };

  return (
    <div id="physician-portal-container" className="w-full max-w-7xl mx-auto flex flex-col gap-6 animate-fadeIn pb-12 select-none text-slate-100">
      
      {/* 1. Top Physician 30-Second Glance Brief Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950/80 border border-teal-500/30 p-5 rounded-2xl shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 backdrop-blur-md">
        
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-500/20 border border-teal-500/40 text-teal-300 font-bold text-lg flex items-center justify-center font-mono shadow-inner shrink-0">
            {initials}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl md:text-2xl font-bold font-serif text-white">
                {patient.name}
              </h1>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-xs font-mono font-bold text-teal-400 border border-slate-700">
                {patient.id}
              </span>
              <span className={`px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wider ${
                isAyush ? 'bg-amber-950/80 text-amber-300 border border-amber-800' : 'bg-teal-950/80 text-teal-300 border border-teal-800'
              }`}>
                {isAyush ? 'AYUSH Ayurveda' : 'Allopathic OPD'}
              </span>

              {/* Medication Stream Badge */}
              <span className={`px-2.5 py-0.5 rounded text-xs font-bold uppercase tracking-wider ${
                patient.medicationStream === 'ayush'
                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                  : patient.medicationStream === 'both'
                  ? 'bg-sky-950/80 text-sky-300 border border-sky-800'
                  : 'bg-teal-950/80 text-teal-300 border border-teal-800'
              }`}>
                {patient.medicationStream === 'ayush' 
                  ? '🌿 AYUSH Regimen' 
                  : patient.medicationStream === 'both' 
                  ? '🔄 Dual / Integrative' 
                  : '💊 Allopathic Meds'}
              </span>
              
              {/* History Completeness Tag */}
              <span className="px-2.5 py-0.5 rounded text-xs font-bold font-mono bg-emerald-950/80 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5" />
                History Score: {completeness.score}%
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 font-medium">
              {patient.gender} • {patient.age} years • DOB: {patient.dob} • Phone: {patient.phone} • ABHA: <span className="font-mono font-bold text-slate-200">{patient.abhaId}</span>
            </p>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {onOpenSecurity && (
            <button
              id="btn-physician-dpdp-shield"
              onClick={onOpenSecurity}
              className="px-3.5 py-2 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 rounded-xl font-bold text-xs uppercase tracking-wider border border-emerald-700 transition-all flex items-center gap-1.5 shadow-sm"
              title="Open DPDP Act 2023 & Security Console"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>DPDP Shield</span>
            </button>
          )}

          <button
            id="btn-physician-copy-summary"
            onClick={handleCopyClinicalSummary}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs uppercase tracking-wider border border-slate-700 transition-all flex items-center gap-1.5"
          >
            {isCopiedSummary ? <Check className="w-4 h-4 text-emerald-400" /> : <FileText className="w-4 h-4 text-teal-400" />}
            <span>{isCopiedSummary ? 'Copied' : 'Copy Brief'}</span>
          </button>

          <button
            id="btn-physician-fhir"
            onClick={onOpenFhir}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs uppercase tracking-wider border border-slate-700 transition-all flex items-center gap-1.5"
            title="Inspect FHIR R4 Bundle"
          >
            <FileCode2 className="w-4 h-4 text-teal-400" />
            <span>FHIR R4</span>
          </button>

          <button
            id="btn-physician-write-rx"
            onClick={onOpenWriteRx}
            className="px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl font-bold text-xs uppercase tracking-wider shadow-lg transition-all flex items-center gap-1.5 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Write Rx</span>
          </button>
        </div>
      </div>

      {/* 2. Physician 30-Second Fast Intake Summary Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
        
        {/* Quick Item 1: Chief Complaint & Pain */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
          <div className="text-[10px] font-bold uppercase tracking-wider text-teal-400 mb-1 flex items-center gap-1">
            <Activity className="w-3.5 h-3.5" />
            Chief Complaint / Pain
          </div>
          <p className="font-semibold text-slate-200 truncate">
            {patient.chiefComplaintDetails || "No chief complaint recorded."}
          </p>
          {patient.socratesPain && patient.socratesPain.site && (
            <span className="text-[10px] text-amber-400 mt-1 block">
              SOCRATES Site: {patient.socratesPain.site} ({patient.socratesPain.severityScale || 'Mod'})
            </span>
          )}
        </div>

        {/* Quick Item 2: Drug Allergies */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
          <div className="text-[10px] font-bold uppercase tracking-wider text-rose-400 mb-1 flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            Allergies & Contraindications
          </div>
          <p className="font-semibold text-slate-200 truncate">
            {patient.allergyHistoryDetails || (patient.allergies?.map(a => a.name).join(', ') || "No known drug allergies (NKDA)")}
          </p>
        </div>

        {/* Quick Item 3: Key Vitals */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
          <div className="text-[10px] font-bold uppercase tracking-wider text-teal-400 mb-1 flex items-center gap-1">
            <Heart className="w-3.5 h-3.5" />
            Vitals (BP / HR / SpO2)
          </div>
          <p className="font-mono font-bold text-slate-200">
            {patient.vitals?.bp || '120/80'} • {patient.vitals?.hr || '72 bpm'} • {patient.vitals?.spo2 || '98%'}
          </p>
        </div>

        {/* Quick Item 4: Scanned Prescriptions */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
          <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 mb-1 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5" />
            Digitized Prior Records
          </div>
          <p className="font-semibold text-slate-200 truncate">
            {patient.documents?.length || 0} Records Scanned (OCR Extracted)
          </p>
        </div>

      </div>

      {/* 3. Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Complaints, Generated HPI, Lab Investigations, Prescriptions */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Section A: History of Present Illness (HPI) with Gemini AI */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-teal-400" />
                <span>AI Clinical Narrative & HPI Synthesis</span>
              </h2>
              <button
                onClick={handleRegenerateHpiWithAi}
                disabled={isRegeneratingHpi}
                className="flex items-center gap-1 text-[11px] text-teal-400 hover:text-teal-300 font-bold"
                title="Regenerate with Google Gemini AI"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRegeneratingHpi ? 'animate-spin' : ''}`} />
                <span>{isRegeneratingHpi ? 'Synthesizing...' : 'AI Enhance'}</span>
              </button>
            </div>

            <div className="text-xs text-slate-200 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono whitespace-pre-wrap">
              {patient.hpiDetails || patient.chiefComplaintDetails || "No narrative generated."}
              <div className="text-[10px] text-slate-400 mt-3 pt-2 border-t border-slate-800 flex items-center justify-between font-sans">
                <span>Structured via Gemini Clinical Intake Model.</span>
                <span className="font-mono text-teal-400 font-bold">FHIR R4 & ABDM Compliant</span>
              </div>
            </div>
          </div>

          {/* Section B: Complete Clinical History Dimensions (HPI, ROS, Family, Personal) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
              <FileSearch className="w-4 h-4 text-teal-400" />
              <span>Multi-Dimensional Clinical History</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-bold text-[10px] uppercase text-teal-400 block mb-1">Past Medical History</span>
                <p className="text-slate-300">{patient.pastHistoryDetails || "None reported."}</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-bold text-[10px] uppercase text-teal-400 block mb-1">Past Surgical History</span>
                <p className="text-slate-300">{patient.pastSurgicalDetails || "None reported."}</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-bold text-[10px] uppercase text-teal-400 block mb-1">Medication History</span>
                <p className="text-slate-300">{patient.medicationHistoryDetails || "None reported."}</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-bold text-[10px] uppercase text-teal-400 block mb-1">Family History</span>
                <p className="text-slate-300">{patient.familyHistoryDetails || "None reported."}</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-bold text-[10px] uppercase text-teal-400 block mb-1">Personal & Lifestyle History</span>
                <p className="text-slate-300">{patient.lifestyleDetails || "None reported."}</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <span className="font-bold text-[10px] uppercase text-teal-400 block mb-1">Review of Systems (ROS)</span>
                <p className="text-slate-300">{patient.reviewOfSystems?.general || "Systemic screen negative."}</p>
              </div>
            </div>
          </div>

          {/* Section C: Recent Investigations & Lab Results */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-400" />
              <span>Biochemistry & Diagnostic Lab Results</span>
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <th className="pb-2">Test Name</th>
                    <th className="pb-2">Value</th>
                    <th className="pb-2">Reference Range</th>
                    <th className="pb-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {patient.labResults && patient.labResults.length > 0 ? (
                    patient.labResults.map((res, index) => (
                      <tr key={index} className="hover:bg-slate-950/50">
                        <td className="py-2.5 font-semibold text-slate-200">{res.test}</td>
                        <td className="py-2.5 font-mono font-bold text-teal-300">{res.result}</td>
                        <td className="py-2.5 text-slate-400">{res.refRange}</td>
                        <td className="py-2.5 text-right font-bold uppercase text-[10px]">
                          <span className={`px-2 py-0.5 rounded ${
                            res.status === 'High' || res.status === 'Critical' 
                              ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                              : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          }`}>
                            {res.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="py-4 text-center text-slate-500 italic">
                        No active lab results reported.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section D: Prescriptions Issued */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                <FileText className="w-4 h-4 text-teal-400" />
                <span>Prescriptions Issued ({patient.prescriptions?.length || 0})</span>
              </h2>
              <button
                onClick={onOpenWriteRx}
                className="text-xs text-teal-400 font-bold hover:text-teal-300 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Medicine</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {patient.prescriptions && patient.prescriptions.length > 0 ? (
                patient.prescriptions.map(rx => (
                  <div
                    key={rx.id}
                    className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-start justify-between gap-3 hover:border-teal-500/40 transition-colors"
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-100">{rx.medicine} ({rx.dosage})</div>
                      <div className="text-[11px] text-slate-400 mt-0.5 font-medium">
                        {rx.frequency} • {rx.duration}
                      </div>
                      <div className="text-[10px] text-teal-400 font-semibold mt-1">
                        Instructions: {rx.instructions}
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteRx(rx.id)}
                      className="text-xs text-rose-400 hover:bg-rose-950/60 font-bold p-1 rounded transition-colors"
                      title="Remove prescription"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              ) : (
                <div className="py-6 text-center text-xs text-slate-500 italic">
                  No active medications issued. Click "Write Rx" to add medicines.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Vitals, Allergies, AYUSH Matrix, Scanned OCR Docs */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Section E: Current Vitals */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-400" />
              <span>Current Vitals (Kiosk Station)</span>
            </h2>
            <div className="grid grid-cols-2 gap-3 text-xs">
              {[
                { label: "TEMP", val: patient.vitals?.temp || "98.6 °F", icon: <Thermometer className="w-4 h-4 text-teal-400" /> },
                { label: "BLOOD PRESSURE", val: patient.vitals?.bp || "120/80", icon: <Activity className="w-4 h-4 text-teal-400" /> },
                { label: "HEART RATE", val: patient.vitals?.hr || "72 bpm", icon: <Heart className="w-4 h-4 text-teal-400" /> },
                { label: "SPO2", val: patient.vitals?.spo2 || "98%", icon: <Wind className="w-4 h-4 text-teal-400" /> }
              ].map((vit, idx) => (
                <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                    {vit.icon}
                  </div>
                  <div>
                    <div className="text-[9px] font-bold text-slate-400 uppercase">{vit.label}</div>
                    <div className="font-bold text-sm font-mono text-slate-100 mt-0.5">{vit.val}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section F: Drug Allergies */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
            <h2 className="text-xs font-bold uppercase tracking-wider text-rose-400 mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>Drug Allergies & Contraindications</span>
            </h2>
            <div className="space-y-2">
              {patient.allergies?.map((all, idx) => (
                <div key={idx} className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-xl flex items-start gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold text-xs uppercase tracking-wider text-rose-300">{all.name}</span>
                    <span className="text-xs block text-slate-300 mt-0.5">{all.reaction}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section G: AYUSH Dashavidha Pariksha Matrix (If in AYUSH Mode) */}
          {isAyush && (
            <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-5 shadow-md animate-fadeIn">
              <div className="flex items-center justify-between mb-3 border-b border-amber-500/20 pb-2">
                <h2 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <Leaf className="w-4 h-4" />
                  <span>AYUSH Dashavidha Pariksha Matrix</span>
                </h2>
                <span className="text-[9px] font-bold uppercase tracking-widest bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800">
                  10 Parameters
                </span>
              </div>
              
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1 text-xs">
                {Object.entries(patient.ayushDetails || {}).map(([param, val]) => (
                  <div key={param} className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="font-bold text-[10px] uppercase text-amber-400 block">{param}</span>
                    <p className="text-slate-300 text-[11px] mt-0.5 leading-relaxed">{val}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section H: Digitized OCR Records */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-400" />
              <span>Digitized OCR Records ({patient.documents?.length || 0})</span>
            </h2>
            <div className="space-y-2">
              {patient.documents && patient.documents.length > 0 ? (
                patient.documents.map(d => (
                  <div key={d.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                    <div className="flex justify-between items-center font-bold text-slate-200">
                      <span className="truncate">{d.name}</span>
                      <span className="text-[10px] text-teal-400 font-mono">{d.ocrConfidence || 94}% OCR</span>
                    </div>
                    {d.extractedMeds && d.extractedMeds.length > 0 && (
                      <div className="text-[10px] text-slate-400 mt-1">
                        Meds: {d.extractedMeds.join(', ')}
                      </div>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-slate-500 italic text-xs py-2">No documents digitized.</p>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
