const { app, BrowserWindow, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');

let mainWindow;
let serverProcess;

const PORT = process.env.PORT || 3000;
const SERVER_URL = `http://localhost:${PORT}`;

function startServer(callback) {
  // Check if server is already running
  http.get(SERVER_URL, (res) => {
    console.log('[Electron] Connected to existing Clincase server instance.');
    callback();
  }).on('error', () => {
    console.log('[Electron] Starting embedded Clincase backend server...');
    const serverScript = path.join(__dirname, 'dist', 'server.cjs');
    
    // Check if production build exists
    const isProd = require('fs').existsSync(serverScript);
    
    if (isProd) {
      serverProcess = spawn(process.execPath, [serverScript], {
        cwd: __dirname,
        env: { ...process.env, NODE_ENV: 'production' }
      });
    } else {
      const npxCmd = process.platform === 'win32' ? 'npx.cmd' : 'npx';
      serverProcess = spawn(npxCmd, ['tsx', 'server.ts'], {
        cwd: __dirname,
        shell: true,
        env: process.env
      });
    }

    serverProcess.stdout.on('data', (data) => {
      console.log(`[Server]: ${data}`);
    });

    serverProcess.stderr.on('data', (data) => {
      console.error(`[Server Error]: ${data}`);
    });

    // Poll until server is responding
    let attempts = 0;
    const checkServer = setInterval(() => {
      attempts++;
      http.get(SERVER_URL, (res) => {
        clearInterval(checkServer);
        callback();
      }).on('error', () => {
        if (attempts > 30) {
          clearInterval(checkServer);
          console.error('[Electron] Server failed to start in time.');
          callback();
        }
      });
    }, 500);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 720,
    title: 'Clincase - AI Clinical History Platform',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false
    },
    autoHideMenuBar: true
  });

  mainWindow.loadURL(SERVER_URL);

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http:') || url.startsWith('https:')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  startServer(() => {
    createWindow();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

process.on('exit', () => {
  if (serverProcess) {
    serverProcess.kill();
  }
});
