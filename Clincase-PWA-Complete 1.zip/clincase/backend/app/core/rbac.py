from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from typing import List, Optional
from app.core.security import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)

class RoleChecker:
    def __init__(self, allowed_roles: List[str]):
        self.allowed_roles = allowed_roles

    def __call__(self, token: Optional[str] = Depends(oauth2_scheme)) -> dict:
        if not token:
            # Guest mode allowed for public OPD intake
            if "guest" in self.allowed_roles:
                return {"username": "guest_kiosk", "role": "guest"}
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authentication credentials required",
                headers={"WWW-Authenticate": "Bearer"},
            )

        payload = decode_access_token(token)
        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired access token",
            )

        role = payload.get("role", "guest")
        if role not in self.allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{role}' is not authorized to access this resource",
            )

        return payload

allow_guest = RoleChecker(["guest", "patient", "doctor", "admin"])
allow_patient = RoleChecker(["patient", "doctor", "admin"])
allow_doctor = RoleChecker(["doctor", "admin"])
allow_admin = RoleChecker(["admin"])
