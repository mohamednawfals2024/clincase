export type ConsultType = 'allopathic' | 'ayush';

export type ThemeMode = 'clinical-teal' | 'midnight-ocean' | 'healing-sage' | 'clean-ivory';

export type LanguageCode = 'en' | 'hi' | 'ta' | 'te' | 'bn' | 'mr';

export interface LanguageOption {
  code: LanguageCode;
  nativeName: string;
  englishName: string;
  script: string;
  greetingVoice: string;
}

export interface VitalSigns {
  temp: string;
  bp: string;
  hr: string;
  spo2: string;
  respRate?: string;
}

export interface Allergy {
  name: string;
  reaction: string;
  severity?: 'Mild' | 'Moderate' | 'Severe';
}

export interface LabResult {
  test: string;
  result: string;
  refRange: string;
  status: 'Normal' | 'High' | 'Low' | 'Critical';
}

export interface ExtractedMedication {
  medicine: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
  confidence: number;
  isUncertain?: boolean;
}

export interface ExtractedLabValue {
  test: string;
  value: string;
  unit: string;
  refRange: string;
  status: 'Normal' | 'High' | 'Low' | 'Critical';
  date?: string;
  confidence: number;
}

export interface DrugInteractionWarning {
  type?: 'interaction' | 'allergy' | 'duplicate';
  severity: 'high' | 'moderate' | 'low' | 'Severe' | 'Moderate' | 'Mild';
  drugs?: string[];
  description?: string;
  recommendation?: string;
  message?: string;
}

export interface HistoryCompletenessReport {
  score: number; // 0 - 100%
  completedSections: string[];
  missingSections: string[];
}

export interface DocumentRecord {
  id: string;
  name: string;
  pages: string;
  size: string;
  type: 'prescription' | 'lab_report' | 'discharge_summary' | 'other';
  url: string;
  timestamp: string;
  extractedText?: string;
  extractedMeds?: string[];
  extractedDiagnoses?: string[];
  structuredMeds?: ExtractedMedication[];
  structuredLabs?: ExtractedLabValue[];
  ocrConfidence?: number;
  isHandwritten?: boolean;
  ocrLanguage?: string;
  datesIdentified?: string[];
  proceduresIdentified?: string[];
}

export interface SocratesPainProfile {
  site?: string;
  onset?: string;
  character?: string;
  radiation?: string;
  associatedSymptoms?: string;
  timing?: string;
  exacerbatingRelieving?: string;
  severityScale?: number; // 1-10
}

export interface ReviewOfSystemsData {
  general?: string;
  cardiovascular?: string;
  respiratory?: string;
  gastrointestinal?: string;
  musculoskeletal?: string;
  neurological?: string;
  dermatological?: string;
  genitourinary?: string;
}

export interface ClinicalHistoryData {
  hpi?: string;
  pastMedical?: string;
  pastSurgical?: string;
  medicationHistory?: string;
  allergyHistory?: string;
  familyHistory?: string;
  personalHistory?: string; // diet, habits, sleep, occupation
  reviewOfSystems?: ReviewOfSystemsData;
  socratesPain?: SocratesPainProfile;
}

export interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  type: 'prescription' | 'lab' | 'clinical' | 'ayush';
  summary?: string;
}

export interface Prescription {
  id: string;
  medicine: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
}

export interface DashavidhaData {
  Prakriti?: string;
  Vikriti?: string;
  Sara?: string;
  Samhanana?: string;
  Pramana?: string;
  Satmya?: string;
  Sattva?: string;
  'Ahara Shakti'?: string;
  'Vyayama Shakti'?: string;
  Vaya?: string;
  'Ahara-Vihara'?: string;
  [key: string]: string | undefined;
}

export interface PatientSession {
  id: string;
  abhaId?: string;
  name: string;
  gender: string;
  age: number;
  dob: string;
  phone: string;
  consentGiven: boolean;
  currentStep: number;
  symptoms: string[];
  chiefComplaintDetails?: string;
  hpiDetails?: string;
  pastHistoryDetails?: string;
  pastSurgicalDetails?: string;
  medicationHistoryDetails?: string;
  allergyHistoryDetails?: string;
  familyHistoryDetails?: string;
  lifestyleDetails?: string;
  reviewOfSystems?: ReviewOfSystemsData;
  socratesPain?: SocratesPainProfile;
  completenessReport?: HistoryCompletenessReport;
  drugInteractions?: DrugInteractionWarning[];
  vitals: VitalSigns;
  allergies: Allergy[];
  labResults: LabResult[];
  timeline: TimelineEvent[];
  documents: DocumentRecord[];
  prescriptions: Prescription[];
  consultType: ConsultType;
  medicationStream?: 'allopathic' | 'ayush' | 'both';
  status: 'active' | 'red_flag' | 'acknowledged' | 'completed';
  redflagSymptom?: string;
  ayushDetails?: DashavidhaData;
  createdAt: string;
  consentArtifact?: ConsentArtifact;
  isPiiMasked?: boolean;
  securityHash?: string;
  appointments?: PatientAppointment[];
  pastVisits?: PatientVisitRecord[];
}

export interface PatientAppointment {
  id: string;
  doctorName: string;
  department: string;
  specialty: string;
  date: string;
  time: string;
  type: 'In-Person OPD' | 'Tele-Consultation' | 'AYUSH Evaluation' | 'Lab Follow-up';
  status: 'Confirmed' | 'Scheduled' | 'Completed' | 'Cancelled';
  tokenNumber: string;
  roomNumber: string;
  notes?: string;
  instructions?: string;
}

export interface PatientVisitRecord {
  id: string;
  date: string;
  doctorName: string;
  department: string;
  hospitalOrClinic: string;
  diagnosis: string[];
  chiefComplaint: string;
  treatmentType: 'Allopathic' | 'AYUSH' | 'Integrative';
  vitalsSummary: string;
  prescriptions: string[];
  clinicalSummary: string;
  followUpDate?: string;
  attachmentsCount?: number;
}

export interface ConsentArtifact {
  consentId: string;
  patientId: string;
  purposeCode: 'CA_OPD_CLINICAL_INTAKE' | 'CA_EMERGENCY_TRIAGE' | 'CA_AYUSH_EVALUATION';
  grantedAt: string;
  validUntil: string;
  status: 'ACTIVE_GRANTED' | 'REVOKED_ERASED' | 'EXPIRED';
  digitalSignature: string;
  dataMinimizationScope: string[];
  consentManagerId: string;
}

export interface SecurityAuditEvent {
  index: number;
  timestamp: string;
  action: 
    | 'SESSION_INITIATED'
    | 'AES256_ENCRYPTED'
    | 'CONSENT_RECORDED'
    | 'PII_MASKED'
    | 'PII_UNMASKED_AUDITED'
    | 'AUDIO_PROCESSED_EPHEMERAL'
    | 'RAW_AUDIO_PURGED'
    | 'DOCUMENT_OCR_MINIMIZED'
    | 'TRIAGE_ALERT_SECURED'
    | 'FHIR_EXPORT_ENCRYPTED'
    | 'RIGHT_TO_FORGOTTEN_PURGED'
    | 'INTEGRITY_VERIFIED';
  actor: 'PATIENT_KIOSK' | 'PHYSICIAN_WORKSTATION' | 'DUTY_NURSE' | 'SECURITY_DAEMON';
  kioskId: string;
  dataFingerprint: string;
  previousHash: string;
  hash: string;
  verified?: boolean;
  metadata?: Record<string, any>;
}

export interface SecurityStatus {
  encryptionStandard: 'AES-256-GCM Hardware Accelerated';
  keyFingerprint: string;
  dpdpCompliant: boolean;
  ephemeralAudioZeroRetention: boolean;
  rawDocumentPurged: boolean;
  totalAuditEvents: number;
  piiMaskingActive: boolean;
  chainIntegrityValid: boolean;
  lastTamperCheck: string;
  consentManagerEndpoint: string;
}

export interface RedFlagAlert {
  session_id: string;
  patient_name: string;
  symptom: string;
  kiosk_id: string;
  timestamp: number;
}

export interface NoiseGateConfig {
  enabled: boolean;
  thresholdDb: number;        // Ambient noise cut-off in decibels (e.g., -45 dB)
  floorGain: number;          // Gain reduction factor when signal is below threshold (e.g. 0.02)
  attackMs: number;           // Time to open the gate when speech starts (e.g., 8 ms)
  releaseMs: number;          // Time to close the gate after speech pauses (e.g., 200 ms)
  holdMs: number;             // Time to hold the gate open before releasing (e.g., 100 ms)
  ambientBaselineDb: number;  // Calibrated background noise baseline in OPD lobby (e.g., -48 dB)
  snrMarginDb: number;        // Signal-to-noise margin above ambient noise (e.g., 6 dB)
  highPassCutoffHz: number;   // Cutoff frequency to remove rumble/AC noise (e.g., 85 Hz)
}

export interface EmergencyHospital {
  id: string;
  name: string;
  vicinity: string;
  distanceKm: number;
  etaMinutes: number;
  phone: string;
  rating?: number;
  userRatingsTotal?: number;
  openNow?: boolean;
  traumaLevel: string;
  icuBedsAvailable?: number;
  googleMapsUrl: string;
  status: 'contacted' | 'notified' | 'confirmed' | 'standby';
}

export interface AmbulanceUnit {
  id: string;
  callSign: string;
  serviceName: string;
  type: 'ACLS (Advanced Cardiac Life Support)' | 'BLS (Basic Life Support)' | 'ICU Ventilator Ambulance';
  driverName: string;
  phone: string;
  currentDistanceKm: number;
  etaMinutes: number;
  vehicleNumber: string;
  status: 'dispatched' | 'en_route' | 'arrived' | 'available';
  liveLocation?: { lat: number; lng: number };
}

export interface EmergencyDoctor {
  id: string;
  name: string;
  specialty: string;
  hospital: string;
  phone: string;
  pagerExt: string;
  onDutyStatus: 'on_duty' | 'in_er' | 'paged' | 'responding';
  estimatedResponseTime: string;
}

export interface EmergencyDispatchRecord {
  dispatchId: string;
  sessionId: string;
  patientName: string;
  redFlagReason: string;
  timestamp: string;
  dispatchedAt: string;
  location: {
    name: string;
    lat: number;
    lng: number;
  };
  nearbyHospitals: EmergencyHospital[];
  dispatchedAmbulance: AmbulanceUnit;
  contactedDoctor: EmergencyDoctor;
  dispatchStatus: 'active' | 'en_route' | 'arrived' | 'resolved';
  googleDataAttribution: string;
}

