def test_get_patient_timeline(client):
    """Test GET /api/v1/timeline/{patient_id}"""
    response = client.get("/api/v1/timeline/MED-49201")
    assert response.status_code == 200
    events = response.json()
    assert isinstance(events, list)
    assert len(events) > 0
    assert "title" in events[0]
    assert "type" in events[0]

def test_get_patient_appointments(client):
    """Test GET /api/v1/timeline/appointments/{patient_id}"""
    response = client.get("/api/v1/timeline/appointments/MED-49201")
    assert response.status_code == 200
    apts = response.json()
    assert isinstance(apts, list)
    assert len(apts) > 0
    assert apts[0]["doctorName"] == "Dr. Arvind Varma, MD"
    assert apts[0]["status"] == "Confirmed"

def test_get_patient_visit_records(client):
    """Test GET /api/v1/timeline/visits/{patient_id}"""
    response = client.get("/api/v1/timeline/visits/MED-49201")
    assert response.status_code == 200
    visits = response.json()
    assert isinstance(visits, list)
    assert len(visits) > 0
    assert "diagnosis" in visits[0]
