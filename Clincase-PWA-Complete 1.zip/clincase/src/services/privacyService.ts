// ============================================================================
// CLINCASE DATA PRIVACY & ANONYMIZATION ENGINE (DPDP ACT 2023 & HIPAA COMPLIANCE)
// ============================================================================

export interface DigitalConsentReceipt {
  receiptId: string;
  patientId: string;
  patientNameMasked: string;
  timestamp: string;
  jurisdiction: 'DPDP_ACT_2023_INDIA' | 'HIPAA_USA' | 'ABDM_NDHM';
  purposes: {
    clinicalCare: boolean;
    aiSummarization: boolean;
    emrInteroperability: boolean;
    academicResearch: boolean;
  };
  consentHash: string;
  expiryDate: string;
}

/**
 * Mask Patient Name (e.g., "John Doe" -> "J*** D***")
 */
export function maskName(name: string): string {
  if (!name || name.trim().length === 0) return 'P***';
  const parts = name.trim().split(/\s+/);
  return parts
    .map(p => {
      if (p.length <= 1) return p;
      return p[0] + '*'.repeat(Math.max(2, p.length - 1));
    })
    .join(' ');
}

/**
 * Mask Phone Number (e.g., "+91 9876543210" -> "+91 ***** **210")
 */
export function maskPhone(phone: string): string {
  if (!phone) return '+91 ***** *****';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length < 4) return '****';
  const last3 = cleaned.slice(-3);
  return `+91 ***** **${last3}`;
}

/**
 * Mask ABHA Health ID (e.g., "91-4528-9021-0044" -> "91-****-****-0044")
 */
export function maskAbha(abhaId: string): string {
  if (!abhaId) return '91-****-****-****';
  const parts = abhaId.split('-');
  if (parts.length === 4) {
    return `${parts[0]}-****-****-${parts[3]}`;
  }
  return abhaId.substring(0, 3) + '****' + abhaId.slice(-4);
}

/**
 * Sanitize AI Prompt String: Replaces PII with Privacy Hashes
 */
export function sanitizePromptForAi(text: string, patientName?: string, phone?: string): string {
  let sanitized = text;
  if (patientName) {
    const nameRegex = new RegExp(patientName.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
    sanitized = sanitized.replace(nameRegex, '[PATIENT_NAME_REDACTED]');
  }
  if (phone) {
    const phoneRegex = new RegExp(phone.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
    sanitized = sanitized.replace(phoneRegex, '[PHONE_REDACTED]');
  }
  // Sanitize 10-digit phone numbers and ABHA numbers in string
  sanitized = sanitized.replace(/\b\d{10}\b/g, '[PHONE_REDACTED]');
  sanitized = sanitized.replace(/\b\d{2}-\d{4}-\d{4}-\d{4}\b/g, '[ABHA_ID_REDACTED]');
  return sanitized;
}

/**
 * Generate a Cryptographic Digital Consent Receipt
 */
export function generateDigitalConsentReceipt(
  patientId: string,
  patientName: string,
  purposes = { clinicalCare: true, aiSummarization: true, emrInteroperability: true, academicResearch: false }
): DigitalConsentReceipt {
  const timestamp = new Date().toISOString();
  const receiptId = `DPDP-CR-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const maskedName = maskName(patientName);

  const rawConsentString = `${receiptId}|${patientId}|${maskedName}|${timestamp}|${JSON.stringify(purposes)}`;
  
  // Simple SHA-256 hash calculation for receipt signature
  let hashVal = 0;
  for (let i = 0; i < rawConsentString.length; i++) {
    hashVal = ((hashVal << 5) - hashVal) + rawConsentString.charCodeAt(i);
    hashVal |= 0;
  }
  const consentHash = `sha256-${Math.abs(hashVal).toString(16).padStart(16, '0')}${Date.now().toString(16)}`;

  const expiry = new Date();
  expiry.setFullYear(expiry.getFullYear() + 1);

  return {
    receiptId,
    patientId,
    patientNameMasked: maskedName,
    timestamp,
    jurisdiction: 'DPDP_ACT_2023_INDIA',
    purposes,
    consentHash,
    expiryDate: expiry.toISOString().split('T')[0]
  };
}
