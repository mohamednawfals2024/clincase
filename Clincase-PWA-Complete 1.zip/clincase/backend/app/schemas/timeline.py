from pydantic import BaseModel
from typing import List, Optional

class TimelineEventSchema(BaseModel):
    id: str
    date: str
    title: str
    type: str  # prescription, lab, clinical, ayush
    summary: Optional[str] = None

class PatientAppointmentSchema(BaseModel):
    id: str
    doctorName: str
    department: str
    specialty: str
    date: str
    time: str
    type: str
    status: str = "Confirmed"
    tokenNumber: str
    roomNumber: str
    notes: Optional[str] = None
    instructions: Optional[str] = None

class PatientVisitRecordSchema(BaseModel):
    id: str
    date: str
    doctorName: str
    department: str
    hospitalOrClinic: str
    diagnosis: List[str]
    chiefComplaint: str
    treatmentType: str = "Allopathic"
    vitalsSummary: str
    prescriptions: List[str]
    clinicalSummary: str
    followUpDate: Optional[str] = None
    attachmentsCount: Optional[int] = 0
