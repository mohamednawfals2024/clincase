import React from 'react';
import { Volume2, Globe2, Sparkles, CheckCircle2 } from 'lucide-react';
import { languages } from '../data/translations';
import { LanguageCode } from '../types';
import { audioService } from '../services/api';

interface LanguageSelectProps {
  selectedLang: LanguageCode;
  onSelectLanguage: (code: LanguageCode) => void;
}

export const LanguageSelect: React.FC<LanguageSelectProps> = ({
  selectedLang,
  onSelectLanguage
}) => {
  const handlePlayGreeting = (e: React.MouseEvent, l: typeof languages[0]) => {
    e.stopPropagation();
    audioService.playBeep('click');
    audioService.speak(l.greetingVoice, l.code);
  };

  return (
    <div className="flex flex-col items-center justify-center my-auto w-full max-w-4xl mx-auto px-4 py-8">
      {/* Title block */}
      <div className="text-center mb-8 max-w-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold uppercase tracking-widest border border-teal-500/20 mb-3">
          <Globe2 className="w-3.5 h-3.5" />
          Bhashini Indic Voice Supported
        </div>
        <h1 className="text-2xl md:text-4xl font-bold font-serif tracking-tight" style={{ color: 'var(--text-main)' }}>
          Please select your preferred language
        </h1>
        <p className="text-sm mt-2 opacity-80" style={{ color: 'var(--text-muted)' }}>
          कृपया अपनी पसंदीदा भाषा चुनें • உங்கள் மொழியைத் தேர்ந்தெடுக்கவும் • దయచేసి మీ భాషను ఎంచుకోండి
        </p>
      </div>

      {/* Grid of Languages */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 w-full">
        {languages.map(l => {
          const isSelected = selectedLang === l.code;
          return (
            <div
              key={l.code}
              onClick={() => {
                audioService.playBeep('click');
                onSelectLanguage(l.code);
              }}
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: isSelected ? 'var(--accent-primary)' : 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className={`p-5 rounded-2xl border transition-all cursor-pointer text-left flex flex-col justify-between h-36 relative shadow-md hover:shadow-xl hover:scale-[1.01] ${
                isSelected
                  ? 'ring-2 ring-teal-500/30'
                  : 'hover:border-teal-500/50'
              }`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                    {l.nativeName}
                  </div>
                  <div className="text-xs mt-0.5 font-medium opacity-80" style={{ color: 'var(--text-muted)' }}>
                    {l.englishName} ({l.script})
                  </div>
                </div>
                {isSelected ? (
                  <CheckCircle2 className="w-5 h-5 text-teal-400" />
                ) : (
                  <button
                    onClick={(e) => handlePlayGreeting(e, l)}
                    className="p-2 rounded-full hover:bg-white/10 opacity-70 hover:opacity-100 hover:text-teal-400 transition-colors"
                    title={`Hear greeting in ${l.englishName}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div 
                className="flex items-center justify-between mt-auto pt-3 border-t text-[11px] font-bold uppercase tracking-wider"
                style={{ borderColor: 'var(--border-color)', color: 'var(--accent-primary)' }}
              >
                <span>Select {l.englishName}</span>
                <span className="text-sm">→</span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8 flex items-center gap-2 text-xs opacity-75" style={{ color: 'var(--text-muted)' }}>
        <Sparkles className="w-3.5 h-3.5 text-teal-400" />
        <span>Voice speech recognition and touch interaction available for all 6 Indic languages</span>
      </div>
    </div>
  );
};
