import os
import sys
import pytest
from fastapi.testclient import TestClient

# Add backend app directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from app.main import app
from app.config import settings

@pytest.fixture(scope="module")
def client():
    """FastAPI TestClient fixture for integration testing"""
    with TestClient(app) as c:
        yield c

@pytest.fixture
def auth_headers_doctor():
    """Doctor role authorization header fixture"""
    from app.core.security import create_access_token
    token = create_access_token({"sub": "DOC-MD-8921", "role": "doctor"})
    return {"Authorization": f"Bearer {token}"}

@pytest.fixture
def auth_headers_admin():
    """Admin role authorization header fixture"""
    from app.core.security import create_access_token
    token = create_access_token({"sub": "ADMIN-SEC-01", "role": "admin"})
    return {"Authorization": f"Bearer {token}"}
