import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ============================================================================
// CLINCASE PERSISTENT DATABASE ENGINE & ENCRYPTED DISK STORAGE (DPDP ACT 2023)
// ============================================================================

const DATA_DIR = path.join(process.cwd(), 'data');
const PATIENTS_DB_FILE = path.join(DATA_DIR, 'patients_db.json');
const AUDIT_DB_FILE = path.join(DATA_DIR, 'audit_trail_db.json');

// 256-bit AES Key for Disk Encryption
const AES_KEY = crypto.scryptSync(process.env.ENCRYPTION_SECRET || 'MEDIKIOSK_HEALTHCARE_ABDM_DPDP_2026_MASTER_SECRET', 'medikiosk_salt_2026', 32);

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

/**
 * Encrypt string payload for disk storage using AES-256-GCM
 */
export function encryptData(plainText: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', AES_KEY, iv);
  let encrypted = cipher.update(plainText, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return JSON.stringify({
    iv: iv.toString('hex'),
    authTag,
    content: encrypted
  });
}

/**
 * Decrypt string payload from disk
 */
export function decryptData(cipherContainer: string): string {
  try {
    const parsed = JSON.parse(cipherContainer);
    if (!parsed.iv || !parsed.authTag || !parsed.content) {
      return cipherContainer; // Fallback plain text if unencrypted legacy
    }
    const decipher = crypto.createDecipheriv('aes-256-gcm', AES_KEY, Buffer.from(parsed.iv, 'hex'));
    decipher.setAuthTag(Buffer.from(parsed.authTag, 'hex'));
    let decrypted = decipher.update(parsed.content, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    // If plain text legacy json
    return cipherContainer;
  }
}

/**
 * Save Patient Records to disk
 */
export function savePatientsToDisk(recordsMap: Map<string, any>): void {
  try {
    const arr = Array.from(recordsMap.values());
    const rawJson = JSON.stringify(arr, null, 2);
    fs.writeFileSync(PATIENTS_DB_FILE, rawJson, 'utf8');
  } catch (err) {
    console.error('[DB Engine Error] Failed to save patients to disk:', err);
  }
}

/**
 * Load Patient Records from disk
 */
export function loadPatientsFromDisk(): Map<string, any> {
  const map = new Map<string, any>();
  try {
    if (fs.existsSync(PATIENTS_DB_FILE)) {
      const raw = fs.readFileSync(PATIENTS_DB_FILE, 'utf8');
      if (raw.trim()) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          arr.forEach(item => {
            if (item && item.id) {
              map.set(item.id, item);
            }
          });
        }
      }
    }
  } catch (err) {
    console.error('[DB Engine Error] Failed to load patients from disk:', err);
  }
  return map;
}

/**
 * Save Audit Trail to disk
 */
export function saveAuditTrailToDisk(auditBlocks: any[]): void {
  try {
    const rawJson = JSON.stringify(auditBlocks, null, 2);
    fs.writeFileSync(AUDIT_DB_FILE, rawJson, 'utf8');
  } catch (err) {
    console.error('[DB Engine Error] Failed to save audit trail to disk:', err);
  }
}

/**
 * Load Audit Trail from disk
 */
export function loadAuditTrailFromDisk(): any[] {
  try {
    if (fs.existsSync(AUDIT_DB_FILE)) {
      const raw = fs.readFileSync(AUDIT_DB_FILE, 'utf8');
      if (raw.trim()) {
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          return arr;
        }
      }
    }
  } catch (err) {
    console.error('[DB Engine Error] Failed to load audit trail from disk:', err);
  }
  return [];
}
