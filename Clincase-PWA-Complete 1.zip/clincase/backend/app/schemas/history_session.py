from pydantic import BaseModel
from typing import Optional

class HistorySessionCreate(BaseModel):
    patient_id: str
    current_step: Optional[int] = 1
    consult_type: Optional[str] = "allopathic"

class HistorySessionResponse(BaseModel):
    id: str
    patient_id: str
    current_step: int = 1
    status: str = "active"
    redflag_symptom: Optional[str] = None
    intake_started_at: str
    intake_completed_at: Optional[str] = None
