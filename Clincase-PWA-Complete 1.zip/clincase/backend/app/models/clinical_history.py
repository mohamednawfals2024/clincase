from sqlalchemy import Column, String, Text, DateTime, JSON, ForeignKey
from datetime import datetime
from app.database import Base

class ClinicalHistoryModel(Base):
    __tablename__ = "clinical_history"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    session_id = Column(String, ForeignKey("history_sessions.id", ondelete="CASCADE"), nullable=False)
    
    chief_complaint = Column(Text, nullable=True)
    hpi_details = Column(Text, nullable=True)
    past_medical_history = Column(Text, nullable=True)
    past_surgical_history = Column(Text, nullable=True)
    medication_history = Column(Text, nullable=True)
    allergy_history = Column(Text, nullable=True)
    family_history = Column(Text, nullable=True)
    lifestyle_details = Column(Text, nullable=True)
    
    # Structured JSON Fields
    socrates_pain_json = Column(JSON, nullable=True)
    review_of_systems_json = Column(JSON, nullable=True)
    dashavidha_pariksha_json = Column(JSON, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow)
