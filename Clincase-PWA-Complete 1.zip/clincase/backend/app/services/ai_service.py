import re
from typing import Dict, Any, Optional
from google import genai
from app.config import settings

class AIService:
    def __init__(self):
        self.client = None
        if settings.GEMINI_API_KEY:
            try:
                self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
            except Exception:
                self.client = None

    def sanitize_prompt(self, text: str) -> str:
        """Sanitize PII in prompts under DPDP Act 2023 compliance"""
        text = re.sub(r'\b[A-Z][a-z]+\s+[A-Z][a-z]+\b', '[PATIENT_NAME_REDACTED]', text)
        text = re.sub(r'\b\d{10}\b', '[PHONE_REDACTED]', text)
        text = re.sub(r'\b\d{2}-\d{4}-\d{4}-\d{4}\b', '[ABHA_REDACTED]', text)
        return text

    async def generate_clinical_dialogue(self, utterance: str, consult_type: str = "allopathic") -> Dict[str, Any]:
        """Generate conversational AI intake response using Gemini"""
        sanitized = self.sanitize_prompt(utterance)
        
        # Rule-based fallback if Gemini API key not set or offline
        if not self.client:
            return {
                "spokenResponse": f"Thank you. I have recorded '{sanitized}'. Can you describe when these symptoms first started?",
                "extractedSymptoms": [sanitized] if len(sanitized) < 30 else ["Acute Complaint"],
                "isRedFlag": False,
                "clinicalSummaryFragment": f"Patient reports: {sanitized}",
                "nextStepGuidance": "Proceeding to history elaboration"
            }

        try:
            prompt = f"You are Clincase OPD Intake AI ({consult_type}). User says: '{sanitized}'. Provide a empathetic 1-sentence follow-up clinical question and extract key symptoms as JSON."
            response = self.client.models.generate_content(
                model='gemini-2.5-flash',
                contents=prompt,
            )
            return {
                "spokenResponse": response.text.strip() if response.text else "Can you elaborate further?",
                "extractedSymptoms": ["Reported Symptoms"],
                "isRedFlag": False,
                "clinicalSummaryFragment": f"Patient states: {sanitized}",
                "nextStepGuidance": "Proceeding to history elaboration"
            }
        except Exception:
            return {
                "spokenResponse": "I have noted that down. Are you experiencing any other symptoms like fever, nausea, or dizziness?",
                "extractedSymptoms": ["General Symptoms"],
                "isRedFlag": False,
                "clinicalSummaryFragment": f"Patient states: {sanitized}",
                "nextStepGuidance": "Proceeding to history elaboration"
            }

ai_service = AIService()
