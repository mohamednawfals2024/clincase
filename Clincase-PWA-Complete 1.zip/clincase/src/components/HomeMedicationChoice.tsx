import React, { useState } from 'react';
import { 
  Pill, 
  Leaf, 
  Sparkles, 
  ArrowRight, 
  ShieldCheck, 
  CheckCircle2, 
  Globe2, 
  Volume2, 
  HeartPulse, 
  Activity, 
  Layers,
  HelpCircle,
  Clock,
  FlaskConical,
  Stethoscope
} from 'lucide-react';
import { ConsultType, LanguageCode } from '../types';
import { languages } from '../data/translations';
import { audioService } from '../services/api';

interface HomeMedicationChoiceProps {
  currentType: ConsultType;
  selectedLang: LanguageCode;
  onSelectLanguage: (code: LanguageCode) => void;
  onConfirmChoice: (type: ConsultType, medicationStream: 'allopathic' | 'ayush' | 'both') => void;
}

export const HomeMedicationChoice: React.FC<HomeMedicationChoiceProps> = ({
  currentType,
  selectedLang,
  onSelectLanguage,
  onConfirmChoice
}) => {
  const [selectedStream, setSelectedStream] = useState<'allopathic' | 'ayush' | 'both'>(
    currentType === 'ayush' ? 'ayush' : 'allopathic'
  );
  const [activeTab, setActiveTab] = useState<'all' | 'allopathic' | 'ayush'>('all');

  const handlePlayVoice = (e: React.MouseEvent, l: typeof languages[0]) => {
    e.stopPropagation();
    audioService.playBeep('click');
    audioService.speak(l.greetingVoice, l.code);
  };

  const handleSelectMedication = (stream: 'allopathic' | 'ayush' | 'both') => {
    setSelectedStream(stream);
    audioService.playBeep('click');
    const consultType: ConsultType = stream === 'ayush' ? 'ayush' : 'allopathic';
    onConfirmChoice(consultType, stream);
  };

  return (
    <div className="flex flex-col items-center justify-center my-auto w-full max-w-5xl mx-auto px-4 py-4 md:py-8 space-y-6">
      
      {/* Welcome Banner */}
      <div className="text-center max-w-3xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold uppercase tracking-widest border border-teal-500/20 shadow-xs">
          <HeartPulse className="w-4 h-4 text-teal-400 animate-pulse" />
          <span>Patient Intake & Medication Triage Portal</span>
        </div>
        
        <h1 
          className="text-2xl md:text-4xl font-extrabold font-serif tracking-tight"
          style={{ color: 'var(--text-main)' }}
        >
          Are you undergoing Allopathic or AYUSH Medications?
        </h1>
        
        <p className="text-xs md:text-sm max-w-2xl mx-auto opacity-80 leading-relaxed" style={{ color: 'var(--text-muted)' }}>
          Please select the type of medical treatment or prescription system you are currently taking or consulting for today. Our AI adapts the clinical history taking, drug allergy checks, and diagnostic parameters accordingly.
        </p>
      </div>

      {/* Language Quick-Bar */}
      <div 
        className="w-full p-3 rounded-2xl border flex flex-wrap items-center justify-between gap-3 shadow-sm"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-color)'
        }}
      >
        <div className="flex items-center gap-2 px-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
          <Globe2 className="w-4 h-4 text-teal-400" />
          <span>Intake Language:</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {languages.map((l) => {
            const isSelected = selectedLang === l.code;
            return (
              <button
                key={l.code}
                onClick={() => {
                  audioService.playBeep('click');
                  onSelectLanguage(l.code);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-teal-500 text-slate-950 font-bold border-teal-400 shadow-xs'
                    : 'bg-white/5 border-transparent opacity-75 hover:opacity-100 hover:bg-white/10'
                }`}
                style={{
                  color: isSelected ? '#020617' : 'var(--text-main)'
                }}
              >
                <span>{l.nativeName}</span>
                <span className="text-[10px] opacity-70">({l.englishName})</span>
                {isSelected && <CheckCircle2 className="w-3 h-3 text-slate-950" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary Medication Option Cards (Allopathic vs AYUSH vs Both) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 w-full">
        
        {/* Option 1: Allopathic Medications */}
        <div
          onClick={() => handleSelectMedication('allopathic')}
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: selectedStream === 'allopathic' ? 'var(--border-highlight)' : 'var(--border-color)',
            color: 'var(--text-main)'
          }}
          className={`p-6 rounded-2xl border transition-all cursor-pointer shadow-md hover:shadow-2xl flex flex-col justify-between group relative overflow-hidden ${
            selectedStream === 'allopathic' 
              ? 'ring-2 ring-teal-500/40 border-teal-500 bg-teal-500/5' 
              : 'hover:border-teal-500/40'
          }`}
        >
          <div className="absolute top-0 right-0 bg-teal-600 text-slate-950 text-[9px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-bl-xl shadow-xs">
            Modern Medicine
          </div>

          <div>
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center mb-4 group-hover:bg-teal-500 group-hover:text-slate-950 transition-all group-hover:scale-105">
              <Pill className="w-6 h-6" />
            </div>

            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold font-serif group-hover:text-teal-400 transition-colors" style={{ color: 'var(--text-main)' }}>
                Allopathic Medications
              </h2>
            </div>
            
            <p className="text-xs mt-2 leading-relaxed opacity-80" style={{ color: 'var(--text-muted)' }}>
              For patients taking or consulting for Western pharmaceuticals: <strong>Antibiotics, Antihypertensives, Diabetes pills/Insulin, Pain relievers, Inhalers, Cardiac drugs</strong>.
            </p>

            <div className="mt-4 space-y-1.5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>AI Clinical Protocols:</span>
              </div>
              <ul className="text-xs space-y-1 opacity-75 list-disc list-inside" style={{ color: 'var(--text-muted)' }}>
                <li>SOCRATES Chief Complaint Mapping</li>
                <li>Real-Time Drug-Drug Interaction Safety</li>
                <li>Penicillin & NSAID Allergy Contraindications</li>
                <li>Digital Prescription Digitization & OCR</li>
              </ul>
            </div>
          </div>

          <div 
            className="mt-6 pt-4 border-t flex items-center justify-between font-bold text-xs uppercase tracking-wider text-teal-400"
            style={{ borderColor: 'var(--border-color)' }}
          >
            <span>Select Allopathic</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Option 2: AYUSH Medications */}
        <div
          onClick={() => handleSelectMedication('ayush')}
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: selectedStream === 'ayush' ? '#10B981' : 'var(--border-color)',
            color: 'var(--text-main)'
          }}
          className={`p-6 rounded-2xl border transition-all cursor-pointer shadow-md hover:shadow-2xl flex flex-col justify-between group relative overflow-hidden ${
            selectedStream === 'ayush' 
              ? 'ring-2 ring-emerald-500/40 border-emerald-500 bg-emerald-500/5' 
              : 'hover:border-emerald-500/40'
          }`}
        >
          <div className="absolute top-0 right-0 bg-emerald-600 text-white text-[9px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-bl-xl shadow-xs">
            Ministry of AYUSH
          </div>

          <div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mb-4 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-all group-hover:scale-105">
              <Leaf className="w-6 h-6" />
            </div>

            <h2 className="text-xl font-bold font-serif text-emerald-400">
              AYUSH Medications
            </h2>
            
            <p className="text-xs mt-2 leading-relaxed opacity-80" style={{ color: 'var(--text-muted)' }}>
              For patients undergoing <strong>Ayurveda, Yoga/Naturopathy, Unani, Siddha, or Homeopathy</strong>: Herbal formulations, Kashayams, Churnas, Rasayanas, Bhasmas.
            </p>

            <div className="mt-4 space-y-1.5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Ayurvedic Protocols:</span>
              </div>
              <ul className="text-xs space-y-1 opacity-75 list-disc list-inside" style={{ color: 'var(--text-muted)' }}>
                <li>Dashavidha Pariksha (10 Parameters)</li>
                <li>Prakriti & Dosha Assessment (Vata, Pitta, Kapha)</li>
                <li>Ahara-Vihara (Dietary & Daily Lifestyle)</li>
                <li>Herbal Formulation Safety & Potency</li>
              </ul>
            </div>
          </div>

          <div 
            className="mt-6 pt-4 border-t flex items-center justify-between font-bold text-xs uppercase tracking-wider text-emerald-400"
            style={{ borderColor: 'var(--border-color)' }}
          >
            <span>Select AYUSH Care</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Option 3: Integrative / Both Regimens */}
        <div
          onClick={() => handleSelectMedication('both')}
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: selectedStream === 'both' ? '#38BDF8' : 'var(--border-color)',
            color: 'var(--text-main)'
          }}
          className={`p-6 rounded-2xl border transition-all cursor-pointer shadow-md hover:shadow-2xl flex flex-col justify-between group relative overflow-hidden ${
            selectedStream === 'both' 
              ? 'ring-2 ring-sky-500/40 border-sky-500 bg-sky-500/5' 
              : 'hover:border-sky-500/40'
          }`}
        >
          <div className="absolute top-0 right-0 bg-sky-600 text-white text-[9px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-bl-xl shadow-xs">
            Dual / Integrative
          </div>

          <div>
            <div className="w-12 h-12 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center mb-4 group-hover:bg-sky-500 group-hover:text-slate-950 transition-all group-hover:scale-105">
              <Layers className="w-6 h-6" />
            </div>

            <h2 className="text-xl font-bold font-serif text-sky-400">
              Both (Integrative)
            </h2>
            
            <p className="text-xs mt-2 leading-relaxed opacity-80" style={{ color: 'var(--text-muted)' }}>
              For patients simultaneously taking <strong>Allopathic prescriptions AND AYUSH herbal supplements</strong>, ensuring cross-system safety and herb-drug interaction alerts.
            </p>

            <div className="mt-4 space-y-1.5">
              <div className="text-[11px] font-bold uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Integrative Features:</span>
              </div>
              <ul className="text-xs space-y-1 opacity-75 list-disc list-inside" style={{ color: 'var(--text-muted)' }}>
                <li>Cross-System Herb-Drug Interaction Detection</li>
                <li>Holistic Prakriti + Standard Vitals Tracking</li>
                <li>Dual Allopathic & Ayurvedic Timeline</li>
                <li>Consolidated FHIR R4 Health Record</li>
              </ul>
            </div>
          </div>

          <div 
            className="mt-6 pt-4 border-t flex items-center justify-between font-bold text-xs uppercase tracking-wider text-sky-400"
            style={{ borderColor: 'var(--border-color)' }}
          >
            <span>Select Integrative</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

      </div>

      {/* Safety & Compliance Badge */}
      <div 
        className="w-full p-4 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-3 text-xs"
        style={{
          backgroundColor: 'rgba(255, 255, 255, 0.02)',
          borderColor: 'var(--border-color)',
          color: 'var(--text-muted)'
        }}
      >
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>
            Compliant with <strong>ABDM (Ayushman Bharat Digital Mission)</strong>, National Health Authority (NHA) & Ministry of AYUSH Guidelines.
          </span>
        </div>

        <div className="flex items-center gap-3 shrink-0 font-mono text-[11px] opacity-75">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            AI Kiosk Ready
          </span>
        </div>
      </div>

    </div>
  );
};
