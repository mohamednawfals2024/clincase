from pydantic import BaseModel
from typing import List, Optional

class PrescriptionCreate(BaseModel):
    sessionId: str
    medicine: str
    dosage: str
    frequency: str
    duration: str
    instructions: str

class PrescriptionResponse(BaseModel):
    id: str
    medicine: str
    dosage: str
    frequency: str
    duration: str
    instructions: str
    prescribedBy: str = "Dr. Arvind Varma, MD"

class DrugInteractionWarningSchema(BaseModel):
    severity: str  # high, moderate, low
    drugs: List[str]
    description: str
    recommendation: str

class CheckInteractionsRequest(BaseModel):
    candidateMedicine: str
    currentPrescriptions: Optional[List[dict]] = []
    knownAllergies: Optional[List[dict]] = []

class CheckInteractionsResponse(BaseModel):
    warnings: List[DrugInteractionWarningSchema]
