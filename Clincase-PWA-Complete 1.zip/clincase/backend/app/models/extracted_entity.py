from sqlalchemy import Column, String, Float, DateTime, ForeignKey
from datetime import datetime
from app.database import Base

class ExtractedMedicalEntityModel(Base):
    __tablename__ = "extracted_medical_entities"

    id = Column(String, primary_key=True, index=True)
    document_id = Column(String, ForeignKey("medical_documents.id", ondelete="CASCADE"), nullable=False)
    entity_type = Column(String, nullable=False)  # medication, lab_value, diagnosis
    
    # Medication Fields
    medication_name = Column(String, nullable=True)
    dosage = Column(String, nullable=True)
    frequency = Column(String, nullable=True)
    duration = Column(String, nullable=True)
    instructions = Column(String, nullable=True)
    
    # Lab Value Fields
    lab_test_name = Column(String, nullable=True)
    lab_value = Column(String, nullable=True)
    lab_unit = Column(String, nullable=True)
    reference_range = Column(String, nullable=True)
    lab_status = Column(String, nullable=True)  # Normal, High, Low, Critical
    
    confidence = Column(Float, default=95.0)
    created_at = Column(DateTime, default=datetime.utcnow)
