import random
from datetime import datetime
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_

from app.database import get_db
from app.models.patient import PatientRecordModel
from app.schemas.patient import (
    PatientCreate, 
    PatientUpdate, 
    PatientResponse, 
    PatientRegistrationRequest, 
    PatientIdentificationRequest
)
from app.core.rbac import allow_guest
from app.core.security import sha256

router = APIRouter(prefix="/patients", tags=["Patient Management"])

@router.post(
    "/register", 
    response_model=PatientResponse, 
    status_code=status.HTTP_201_CREATED,
    summary="Register New Patient OPD Session",
    description="Registers a new patient with ABHA ID, demographics, vitals, and treatment stream."
)
async def register_patient(
    payload: PatientRegistrationRequest, 
    db: AsyncSession = Depends(get_db), 
    current_user: dict = Depends(allow_guest)
):
    session_id = f"MED-{random.randint(10000, 99999)}"
    assigned_abha = payload.abhaId or f"91-{random.randint(1000,9999)}-{random.randint(1000,9999)}-{random.randint(1000,9999)}"
    
    # Check if ABHA ID already exists
    if payload.abhaId:
        existing = await db.execute(select(PatientRecordModel).where(PatientRecordModel.abha_id == payload.abhaId))
        if existing.scalars().first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Patient with ABHA ID '{payload.abhaId}' is already registered"
            )

    vitals = payload.vitals.dict() if payload.vitals else {
        "temp": "98.6 °F", "bp": "120/80 mmHg", "hr": "72 bpm", "spo2": "98%", "respRate": "16 bpm"
    }

    patient = PatientRecordModel(
        id=session_id,
        abha_id=assigned_abha,
        name=payload.name,
        gender=payload.gender,
        age=payload.age,
        dob=payload.dob,
        phone=payload.phone,
        consent_given=True,
        current_step=1,
        symptoms=[],
        chief_complaint_details="",
        hpi_details="",
        vitals=vitals,
        allergies=[{"name": "Penicillin", "reaction": "Severe - Anaphylaxis", "severity": "Severe"}],
        lab_results=[{"test": "CBC (WBC)", "result": "11,800 /µL", "refRange": "4,500 - 11,000", "status": "High"}],
        consult_type=payload.consultType or "allopathic",
        status="active",
        security_hash=f"SHA256:{sha256(session_id + assigned_abha)}"
    )

    db.add(patient)
    await db.commit()
    await db.refresh(patient)

    return PatientResponse(
        id=patient.id,
        abhaId=patient.abha_id,
        name=patient.name,
        gender=patient.gender,
        age=patient.age,
        dob=patient.dob,
        phone=patient.phone,
        consentGiven=patient.consent_given,
        currentStep=patient.current_step,
        symptoms=patient.symptoms or [],
        chiefComplaintDetails=patient.chief_complaint_details or "",
        hpiDetails=patient.hpi_details or "",
        vitals=patient.vitals,
        allergies=patient.allergies,
        labResults=patient.lab_results,
        consultType=patient.consult_type,
        status=patient.status,
        createdAt=patient.created_at.isoformat()
    )

@router.post(
    "/identify", 
    response_model=PatientResponse,
    summary="Identify Patient by ABHA or Phone",
    description="Looks up an existing patient session by ABHA ID (e.g. 91-4528-9021-0044) or Phone number."
)
async def identify_patient(
    payload: PatientIdentificationRequest, 
    db: AsyncSession = Depends(get_db), 
    current_user: dict = Depends(allow_guest)
):
    target = payload.identifier.strip()
    result = await db.execute(
        select(PatientRecordModel).where(
            or_(
                PatientRecordModel.abha_id == target,
                PatientRecordModel.phone == target,
                PatientRecordModel.id == target
            )
        )
    )
    p = result.scalars().first()
    if not p:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No patient record found matching identifier '{target}'"
        )

    return PatientResponse(
        id=p.id,
        abhaId=p.abha_id,
        name=p.name,
        gender=p.gender,
        age=p.age,
        dob=p.dob,
        phone=p.phone,
        consentGiven=p.consent_given,
        currentStep=p.current_step,
        symptoms=p.symptoms or [],
        chiefComplaintDetails=p.chief_complaint_details or "",
        hpiDetails=p.hpi_details or "",
        vitals=p.vitals,
        allergies=p.allergies or [],
        labResults=p.lab_results or [],
        consultType=p.consult_type or "allopathic",
        status=p.status or "active",
        createdAt=p.created_at.isoformat() if p.created_at else datetime.utcnow().isoformat()
    )

@router.get("", response_model=List[PatientResponse], summary="List All Patient Sessions")
async def list_patients(db: AsyncSession = Depends(get_db), current_user: dict = Depends(allow_guest)):
    result = await db.execute(select(PatientRecordModel))
    patients = result.scalars().all()
    
    res = []
    for p in patients:
        res.append(PatientResponse(
            id=p.id,
            abhaId=p.abha_id,
            name=p.name,
            gender=p.gender,
            age=p.age,
            dob=p.dob,
            phone=p.phone,
            consentGiven=p.consent_given,
            currentStep=p.current_step,
            symptoms=p.symptoms or [],
            chiefComplaintDetails=p.chief_complaint_details or "",
            hpiDetails=p.hpi_details or "",
            vitals=p.vitals or {"temp": "98.6 °F", "bp": "120/80 mmHg", "hr": "72 bpm", "spo2": "98%"},
            allergies=p.allergies or [],
            labResults=p.lab_results or [],
            consultType=p.consult_type or "allopathic",
            status=p.status or "active",
            ayushDetails=p.ayush_details,
            isPiiMasked=p.is_pii_masked,
            securityHash=p.security_hash,
            createdAt=p.created_at.isoformat() if p.created_at else datetime.utcnow().isoformat()
        ))
    return res

@router.get("/{patient_id}", response_model=PatientResponse, summary="Get Patient by ID")
async def get_patient(patient_id: str, db: AsyncSession = Depends(get_db), current_user: dict = Depends(allow_guest)):
    result = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == patient_id))
    p = result.scalars().first()
    if not p:
        raise HTTPException(status_code=404, detail="Patient session not found")

    return PatientResponse(
        id=p.id,
        abhaId=p.abha_id,
        name=p.name,
        gender=p.gender,
        age=p.age,
        dob=p.dob,
        phone=p.phone,
        consentGiven=p.consent_given,
        currentStep=p.current_step,
        symptoms=p.symptoms or [],
        chiefComplaintDetails=p.chief_complaint_details or "",
        hpiDetails=p.hpi_details or "",
        vitals=p.vitals,
        allergies=p.allergies or [],
        labResults=p.lab_results or [],
        consultType=p.consult_type or "allopathic",
        status=p.status or "active",
        createdAt=p.created_at.isoformat() if p.created_at else datetime.utcnow().isoformat()
    )

@router.delete("/{patient_id}", summary="DPDP Section 12 Right to Erasure")
async def delete_patient(patient_id: str, db: AsyncSession = Depends(get_db), current_user: dict = Depends(allow_guest)):
    result = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == patient_id))
    p = result.scalars().first()
    if p:
        p.name = "[PURGED-RIGHT-TO-BE-FORGOTTEN]"
        p.phone = "0000000000"
        p.chief_complaint_details = "[PURGED UNDER DPDP ACT 2023 SECTION 12]"
        p.hpi_details = "[PURGED UNDER DPDP ACT 2023 SECTION 12]"
        p.symptoms = []
        p.status = "acknowledged"
        await db.commit()

    return {"status": "success", "message": "Patient data zeroized and revoked."}
