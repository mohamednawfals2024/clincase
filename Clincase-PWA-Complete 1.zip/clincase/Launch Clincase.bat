@echo off
title Clincase AI Clinical Platform
cd /d "%~dp0"

:: Add Node.js runtime to PATH
set "PATH=C:\Program Files\nodejs;%PATH%"

echo =======================================================================
echo                    CLINCASE AI CLINICAL PLATFORM                       
echo =======================================================================
echo.
echo [1/2] Starting Clincase local backend server...

:: Launch browser after 2 seconds
start "" powershell -NoProfile -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:3000'"

echo [2/2] Application ready at http://localhost:3000
echo.
echo =======================================================================
echo  STATUS: App is active! 
echo  Open browser to: http://localhost:3000
echo  NOTE: Keep this window open while using the application.
echo =======================================================================
echo.

node.exe dist/server.cjs
pause
