// Multi-Lingual Web Speech Recognition & Audio Meter Service for Indian OPD MediKiosk
import { audioService } from './api';

export type SpeechLanguage = 'en' | 'hi' | 'ta' | 'te' | 'bn' | 'mr';

const LANGUAGE_LOCALE_MAP: Record<SpeechLanguage, string[]> = {
  en: ['en-IN', 'en-US', 'en-GB'],
  hi: ['hi-IN', 'hi'],
  ta: ['ta-IN', 'ta-LK', 'ta'],
  te: ['te-IN', 'te'],
  bn: ['bn-IN', 'bn-BD', 'bn'],
  mr: ['mr-IN', 'mr']
};

export interface SpeechRecognitionHandlers {
  onStart?: () => void;
  onInterim?: (text: string) => void;
  onResult?: (finalText: string) => void;
  onError?: (error: string) => void;
  onEnd?: () => void;
  onVolumeChange?: (volume: number) => void;
  onGateChange?: (isOpen: boolean, db: number) => void;
}

export class SpeechEngine {
  private recognition: any = null;
  private isListening: boolean = false;
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private highPassFilter: BiquadFilterNode | null = null;
  private animFrameId: number | null = null;

  public isSupported(): boolean {
    return typeof window !== 'undefined' && (
      'SpeechRecognition' in window || 'webkitSpeechRecognition' in window
    );
  }

  public async startListening(
    lang: SpeechLanguage,
    handlers: SpeechRecognitionHandlers
  ): Promise<boolean> {
    // Stop any existing session
    this.stopListening();

    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) {
      if (handlers.onError) {
        handlers.onError("Web Speech API not supported in this browser environment. Using manual keyboard input.");
      }
      return false;
    }

    try {
      this.recognition = new SpeechRecognitionClass();
      const localeList = LANGUAGE_LOCALE_MAP[lang] || ['en-IN'];
      this.recognition.lang = localeList[0];
      this.recognition.continuous = false;
      this.recognition.interimResults = true;
      this.recognition.maxAlternatives = 3;

      let finalTranscript = '';

      this.recognition.onstart = () => {
        this.isListening = true;
        handlers.onStart?.();
        this.startAudioMeter(handlers.onVolumeChange, handlers.onGateChange);
      };

      this.recognition.onresult = (event: any) => {
        // Check if noise gate is open or if speech audio passed the threshold
        const isGateOpen = audioService.isNoiseGateOpen();

        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }

        const currentText = (finalTranscript + interimTranscript).trim();
        // Only deliver transcriptions if noise gate is open or final text confirmed
        if (interimTranscript && isGateOpen) {
          handlers.onInterim?.(currentText);
        } else if (finalTranscript) {
          handlers.onResult?.(finalTranscript.trim());
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn("Speech recognition error:", event.error);
        if (event.error === 'no-speech') {
          handlers.onError?.("No speech detected. Please speak clearly closer to the microphone.");
        } else if (event.error === 'not-allowed') {
          handlers.onError?.("Microphone permission denied. Please allow microphone access in your browser.");
        } else if (event.error === 'audio-capture') {
          handlers.onError?.("No microphone found. Please check your audio input device.");
        } else {
          handlers.onError?.(`Speech recognition error: ${event.error}`);
        }
        this.stopAudioMeter();
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.stopAudioMeter();
        if (finalTranscript.trim()) {
          handlers.onResult?.(finalTranscript.trim());
        }
        handlers.onEnd?.();
      };

      this.recognition.start();
      return true;
    } catch (err: any) {
      console.error("Failed to start speech recognition:", err);
      handlers.onError?.(err?.message || "Could not start voice recognition.");
      this.stopAudioMeter();
      return false;
    }
  }

  public stopListening(): void {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
      this.recognition = null;
    }
    this.isListening = false;
    this.stopAudioMeter();
  }

  public getIsListening(): boolean {
    return this.isListening;
  }

  private async startAudioMeter(
    onVolumeChange?: (volume: number) => void,
    onGateChange?: (isOpen: boolean, db: number) => void
  ) {
    if (!onVolumeChange && !onGateChange) return;

    try {
      const config = audioService.getNoiseGateConfig();

      if (!this.mediaStream) {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          }
        });
      }

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!this.audioContext && AudioCtx) {
        this.audioContext = new AudioCtx();
      }

      if (this.audioContext && this.mediaStream) {
        if (this.audioContext.state === 'suspended') {
          await this.audioContext.resume();
        }

        const source = this.audioContext.createMediaStreamSource(this.mediaStream);

        // 1. High-Pass Filter node to strip out low-frequency background rumble / HVAC
        this.highPassFilter = this.audioContext.createBiquadFilter();
        this.highPassFilter.type = 'highpass';
        this.highPassFilter.frequency.setValueAtTime(config.highPassCutoffHz || 85, this.audioContext.currentTime);

        // 2. Gain Node for dynamic noise-gate floor attenuation
        this.gainNode = this.audioContext.createGain();
        this.gainNode.gain.setValueAtTime(1.0, this.audioContext.currentTime);

        // 3. Analyser Node
        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 256;

        // Pipeline: source -> highpass -> gain -> analyser
        source.connect(this.highPassFilter);
        this.highPassFilter.connect(this.gainNode);
        this.gainNode.connect(this.analyser);

        const dataArray = new Float32Array(this.analyser.fftSize);

        const updateMeter = () => {
          if (!this.analyser || !this.isListening) return;
          this.analyser.getFloatTimeDomainData(dataArray);

          // Calculate Root-Mean-Square (RMS)
          let sumSquares = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sumSquares += dataArray[i] * dataArray[i];
          }
          const rms = Math.sqrt(sumSquares / dataArray.length);

          // Evaluate against audioService noise gate configuration
          const gateResult = audioService.evaluateAudioFrame(rms);

          // Adjust WebAudio gain node smoothly based on gate state
          if (this.gainNode && this.audioContext) {
            this.gainNode.gain.setTargetAtTime(
              gateResult.effectiveGain,
              this.audioContext.currentTime,
              gateResult.isGateOpen ? (config.attackMs / 1000) : (config.releaseMs / 1000)
            );
          }

          onGateChange?.(gateResult.isGateOpen, gateResult.currentDb);

          // Normalize volume for UI display (0 to 100)
          const visualVolume = gateResult.isGateOpen
            ? Math.min(100, Math.max(10, Math.round(rms * 280)))
            : Math.min(15, Math.round(rms * 50));

          onVolumeChange?.(visualVolume);
          this.animFrameId = requestAnimationFrame(updateMeter);
        };

        updateMeter();
      }
    } catch (err) {
      console.warn("Could not start WebAudio noise gate meter:", err);
    }
  }

  private stopAudioMeter() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }
    this.highPassFilter = null;
    this.gainNode = null;
    this.analyser = null;
  }
}

export const speechRecognizer = new SpeechEngine();
