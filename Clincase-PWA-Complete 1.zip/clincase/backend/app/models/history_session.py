from sqlalchemy import Column, String, Integer, DateTime, ForeignKey
from datetime import datetime
from app.database import Base

class HistorySessionModel(Base):
    __tablename__ = "history_sessions"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    current_step = Column(Integer, default=1)
    status = Column(String, default="active")  # active, red_flag, acknowledged, completed
    redflag_symptom = Column(String, nullable=True)
    intake_started_at = Column(DateTime, default=datetime.utcnow)
    intake_completed_at = Column(DateTime, nullable=True)
