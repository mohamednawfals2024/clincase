# 🏥 CLINCASE — AI-Powered Intelligent OPD Kiosk & Clinical EMR Platform

<div align="center">

![Clincase Banner](https://img.shields.io/badge/Clincase-PWA_Ready-teal?style=for-the-badge&logo=pwa)
![Offline First](https://img.shields.io/badge/Offline--First-Zero_Downtime-emerald?style=for-the-badge)
![FastAPI & Express](https://img.shields.io/badge/FastAPI_&_Express-Dual_Engine-blue?style=for-the-badge)
![FHIR R4](https://img.shields.io/badge/HL7_FHIR-R4.0.1-purple?style=for-the-badge)
![DPDP Act 2023](https://img.shields.io/badge/DPDP_Act_2023-Compliant-amber?style=for-the-badge)

**Next-Generation Multi-Lingual Healthcare OPD Triage, Offline-First PWA, Voice Clinical Intake, and Automated Emergency Dispatch.**

</div>

---

## 🌟 Key Features

### 1. 📱 Installable Progressive Web App (PWA)
* **Installable on Android, iOS, and Desktop Chrome/Edge**.
* Standalone window display with high-resolution adaptive & maskable icons (`192x192`, `512x512`).
* Supports native app launcher shortcuts (Quick Kiosk Intake, Doctor Workstation, Emergency SOS).

### 2. ⚡ Offline & Online Dual-Mode Continuity
* **Service Worker Caching**: Full app shell (HTML, CSS, JS, Fonts, Icons) cached for instant offline loading.
* **Deterministic Local AI Engine**: Offline voice clinical intake, symptom extraction, and emergency triage without requiring an active internet connection.
* **Offline Mutation Outbox & Auto-Sync**: Changes made while offline are stored locally in IndexedDB/LocalStorage and automatically synchronized to the Express server and Cloud Firestore when connectivity is restored.

### 3. 🚨 Live Emergency Multi-Agency Automated Dispatch
* **Real-time Red Flag Detection**: Instantly triggers for acute chest pain, stroke symptoms, respiratory distress, and severe trauma.
* **Google Places Live Data**: Fetches nearby verified hospitals, trauma centers, on-call emergency physicians, and 108/ACLS ambulance units.
* **1-Tap Direct Actions**: Direct emergency phone call links (`tel:`) and Google Maps turn-by-turn routing coordinates.

### 4. 🩺 Physician Workstation & Clinical Summaries
* **Hospital Ingestion Queue**: Physicians can view and switch between all registered patients.
* **AI Clinical Synthesis**: Powered by Gemini 2.5 Flash / Local engine for History of Present Illness (HPI), SOCRATES pain matrices, and Review of Systems (ROS).
* **Integrated Prescription Writer**: Write digital prescriptions with automatic dosage, frequency, duration, and meal instructions.

### 5. 🛡️ Hospital Admin & Patient Data Management
* **Comprehensive Patient CRUD**: Search, filter, view, edit demographics/vitals, and manage all patient submissions.
* **DPDP Act 2023 Compliance**: One-click cryptographic PII erasure (*Right to be Forgotten*).
* **SHA-256 Chained Audit Trail**: Immutable cryptographic audit logging for every access and modification event.

### 6. 🌿 AYUSH Dashavidha Pariksha & Integrative Medicine
* Full clinical support for Allopathic OPD and Ayurvedic Dashavidha Pariksha (*Prakriti, Vikriti, Sara, Samhanana, Pramana, Satmya, Satva, Ahara Shakti, Vyayama Shakti, Vaya*).

---

## 🚀 Quick Start & Installation

### Prerequisites
* **Node.js**: v18.0.0 or higher
* **Python**: 3.9+ (Optional, for FastAPI ML backend)

### 1. Install Dependencies
```bash
# In the clincase project folder:
npm install
```

### 2. Configure Environment Variables
Create or edit `.env.local`:
```env
PORT=3000
VITE_API_URL=http://localhost:3000
GEMINI_API_KEY=your_gemini_api_key_here
```

### 3. Build & Run Application
```bash
# Build production bundle and server:
npm run build

# Start production server:
npm start
```
The application will be accessible at: **`http://localhost:3000`**

For development with hot-reloading:
```bash
npm run dev
```

---

## 📂 Project Architecture

```
clincase/
├── public/                     # PWA assets
│   ├── icons/                  # 192x192, 512x512, maskable icons
│   ├── manifest.json           # Web App Manifest
│   └── sw.js                   # Service Worker (Offline Cache & Sync)
├── src/                        # React Frontend Source
│   ├── components/             # UI Components (Kiosk, Portals, Modals)
│   │   ├── AdminDashboard.tsx  # Admin Patient Data Management & Audit
│   │   ├── PhysicianPortal.tsx # Doctor Workstation & Patient Queue
│   │   ├── TriageConsole.tsx   # Nurse Emergency Triage Hub
│   │   ├── EmergencyOverlay.tsx# Live Multi-Agency Dispatch Overlay
│   │   └── Header.tsx          # Connectivity Status & Role Switcher
│   ├── data/                   # Mock records, translations, clinical rules
│   ├── services/               # API, Firebase, PWA, and Offline Engine
│   │   ├── api.ts              # Unified REST & Deterministic Engine
│   │   ├── emergencyService.ts # Google Places Emergency Dispatch
│   │   ├── firebase.ts         # Cloud Firestore Real-time Sync
│   │   ├── offlineSync.ts      # Offline DB & Mutation Queue
│   │   └── pwa.ts              # Service Worker Registration
│   ├── types.ts                # TypeScript Interfaces & Models
│   ├── App.tsx                 # Root Workspace & Route Orchestrator
│   └── main.tsx                # Entry point
├── backend/                    # Optional FastAPI Microservice
├── server.ts                   # Express Backend with DPDP Engine & APIs
├── package.json                # Project dependencies and build scripts
└── vite.config.ts              # Vite & PWA Build Configuration
```

---

## 🔐 Role Access Credentials

| Role | Access Method | Capabilities |
| :--- | :--- | :--- |
| **User / Patient** | Kiosk Intake & Registration | Voice dialogue, OCR upload, health summary, vitals |
| **Doctor / Hospital** | Doctor Login / Quick Demo | Ingestion queue, patient switcher, write Rx, AI HPI, FHIR |
| **Hospital Admin** | Admin Login / Quick Demo | Patient Data CRUD, DPDP purge, audit trail, triage console |

---

## 📄 License
MIT License. Built for Healthcare OPD Continuity & Public Health Innovation.
