// ============================================================================
// CLINCASE PWA SERVICE WORKER REGISTRATION & INSTALLATION HANDLER
// ============================================================================

let deferredPrompt: any = null;
let isInstallableCallback: ((canInstall: boolean) => void) | null = null;

export function registerServiceWorker() {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) {
    console.log('[PWA] Service workers are not supported in this browser environment.');
    return;
  }

  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/'
      });

      console.log('[PWA] ServiceWorker successfully registered with scope:', registration.scope);

      // Check for worker updates
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              console.log('[PWA] New version available. Refresh to update.');
            }
          });
        }
      });
    } catch (error) {
      console.warn('[PWA] ServiceWorker registration failed:', error);
    }
  });

  // Capture beforeinstallprompt for Android Chrome & Desktop PWA installation
  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    deferredPrompt = e;
    console.log('[PWA] beforeinstallprompt event captured. App is installable.');
    if (isInstallableCallback) {
      isInstallableCallback(true);
    }
  });

  window.addEventListener('appinstalled', () => {
    console.log('[PWA] Clincase PWA installed successfully.');
    deferredPrompt = null;
    if (isInstallableCallback) {
      isInstallableCallback(false);
    }
  });
}

/**
 * Triggers the browser's native PWA installation prompt
 */
export async function promptPWAInstall(): Promise<boolean> {
  if (!deferredPrompt) {
    console.log('[PWA] Installation prompt is not available or app is already installed.');
    return false;
  }

  try {
    deferredPrompt.prompt();
    const choiceResult = await deferredPrompt.userChoice;
    deferredPrompt = null;
    return choiceResult.outcome === 'accepted';
  } catch (err) {
    console.warn('[PWA] Install prompt error:', err);
    return false;
  }
}

export function isPWAStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true ||
    document.referrer.includes('android-app://')
  );
}

export function onInstallableChange(cb: (canInstall: boolean) => void) {
  isInstallableCallback = cb;
  if (deferredPrompt) {
    cb(true);
  }
}
