def test_record_consent_receipt(client):
    """Test POST /api/v1/consent/record and verify SHA-256 digital signature"""
    payload = {
        "patientId": "MED-49201",
        "purposeCode": "CA_OPD_CLINICAL_INTAKE",
        "validDays": 365
    }
    response = client.post("/api/v1/consent/record", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["patientId"] == "MED-49201"
    assert data["consentId"] == "DPDP-CR-MED-49201"
    assert data["status"] == "ACTIVE_GRANTED"
    assert len(data["digitalSignature"]) == 64  # SHA-256 hex length

def test_get_consent_artifact(client):
    """Test GET /api/v1/consent/{patient_id}"""
    response = client.get("/api/v1/consent/MED-49201")
    assert response.status_code == 200
    data = response.json()
    assert data["patientId"] == "MED-49201"
    assert "dataMinimizationScope" in data
