from sqlalchemy import Column, String, Float, Boolean, DateTime, ForeignKey
from datetime import datetime
from app.database import Base

class MedicalDocumentModel(Base):
    __tablename__ = "medical_documents"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    name = Column(String, nullable=False)
    document_type = Column(String, nullable=False)  # prescription, lab_report, discharge_summary
    file_url = Column(String, nullable=False)
    file_size_mb = Column(String, default="1.0 MB")
    ocr_confidence = Column(Float, default=95.0)
    is_handwritten = Column(Boolean, default=False)
    ocr_language = Column(String, default="English & Indic")
    created_at = Column(DateTime, default=datetime.utcnow)
