import React from 'react';
import { Stethoscope, Leaf, Sparkles, CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';
import { ConsultType } from '../types';
import { audioService } from '../services/api';

interface ConsultTypeSelectProps {
  onSelectType: (type: ConsultType) => void;
}

export const ConsultTypeSelect: React.FC<ConsultTypeSelectProps> = ({
  onSelectType
}) => {
  return (
    <div className="flex flex-col items-center justify-center my-auto w-full max-w-4xl mx-auto px-4 py-8">
      {/* Title */}
      <div className="text-center mb-8 max-w-2xl">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold uppercase tracking-widest mb-3 border border-teal-500/20">
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          Select Diagnostic Pathway
        </div>
        <h1 className="text-2xl md:text-4xl font-bold font-serif tracking-tight" style={{ color: 'var(--text-main)' }}>
          Choose Clinical Intake Mode
        </h1>
        <p className="text-sm mt-2 opacity-80" style={{ color: 'var(--text-muted)' }}>
          Select whether this session is for standard Allopathic OPD or an Ayurvedic AYUSH Consultation.
        </p>
      </div>

      {/* Pathways Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
        {/* Pathway 1: Allopathic */}
        <div
          onClick={() => {
            audioService.playBeep('click');
            onSelectType('allopathic');
          }}
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-color)',
            color: 'var(--text-main)'
          }}
          className="p-6 md:p-8 border rounded-2xl transition-all cursor-pointer shadow-md hover:shadow-xl hover:border-teal-500/60 hover:scale-[1.01] flex flex-col justify-between group"
        >
          <div>
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center mb-4 group-hover:bg-teal-500 group-hover:text-slate-950 transition-colors">
              <Stethoscope className="w-6 h-6" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold font-serif group-hover:text-teal-400 transition-colors" style={{ color: 'var(--text-main)' }}>
              Allopathic Clinical Intake
            </h2>
            <p className="text-xs md:text-sm mt-2.5 leading-relaxed opacity-80" style={{ color: 'var(--text-muted)' }}>
              Standard Western medicine pathway focusing on <strong>Chief Complaint (SOCRATES)</strong>, History of Present Illness (HPI), Past Medical History, Drug Allergies, and Vitals.
            </p>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {['Chief Complaint', 'HPI Generator', 'Past Conditions', 'Family History', 'Prescriptions'].map(tag => (
                <span 
                  key={tag} 
                  className="text-[10px] px-2 py-0.5 rounded font-medium border"
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-main)'
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div 
            className="mt-6 pt-4 border-t flex items-center justify-between font-bold text-xs uppercase tracking-wider text-teal-400"
            style={{ borderColor: 'var(--border-color)' }}
          >
            <span>Start Allopathic Intake</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Pathway 2: AYUSH Ayurveda */}
        <div
          onClick={() => {
            audioService.playBeep('click');
            onSelectType('ayush');
          }}
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-color)',
            color: 'var(--text-main)'
          }}
          className="p-6 md:p-8 border rounded-2xl transition-all cursor-pointer shadow-md hover:shadow-xl hover:border-emerald-500/60 hover:scale-[1.01] flex flex-col justify-between group relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 bg-emerald-600 text-white text-[9px] font-bold uppercase tracking-widest px-3 py-1 rounded-bl-xl shadow-xs">
            Ministry of AYUSH
          </div>

          <div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mb-4 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-colors">
              <Leaf className="w-6 h-6" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold font-serif text-emerald-400">
              AYUSH Dashavidha Pariksha
            </h2>
            <p className="text-xs md:text-sm mt-2.5 leading-relaxed opacity-80" style={{ color: 'var(--text-muted)' }}>
              Comprehensive Ayurvedic holistic diagnostic model capturing all <strong>10 Dashavidha Pariksha</strong> parameters (Prakriti, Vikriti, Sara, Samhanana, Pramana, Satmya, Sattva, Ahara/Vyayama Shakti, Vaya) plus <strong>Ahara-Vihara</strong>.
            </p>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {['Prakriti (Dosha)', 'Vikriti', 'Dhatu Sara', 'Agni Shakti', 'Ahara-Vihara'].map(tag => (
                <span 
                  key={tag} 
                  className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded font-bold border border-emerald-500/20"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div 
            className="mt-6 pt-4 border-t flex items-center justify-between font-bold text-xs uppercase tracking-wider text-emerald-400"
            style={{ borderColor: 'var(--border-color)' }}
          >
            <span>Start AYUSH Ayurveda Intake</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 text-xs opacity-75" style={{ color: 'var(--text-muted)' }}>
        <ShieldCheck className="w-4 h-4 text-emerald-400" />
        <span>ABDM Compliant • Both pathways generate structured FHIR R4 clinical summaries</span>
      </div>
    </div>
  );
};
