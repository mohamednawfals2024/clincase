import random
from typing import List
from fastapi import APIRouter, Depends
from app.schemas.prescription import PrescriptionCreate, PrescriptionResponse, CheckInteractionsRequest, CheckInteractionsResponse
from app.schemas.patient import PatientResponse
from app.services.interaction_service import interaction_service
from app.core.rbac import allow_doctor

router = APIRouter(prefix="/doctor", tags=["Doctor Workstation & Safety"])

@router.get("/queue", response_model=List[PatientResponse])
async def get_doctor_queue(current_user: dict = Depends(allow_doctor)):
    """Fetch active OPD patient intake queue for physician workstation"""
    return [
        PatientResponse(
            id="MED-49201",
            abhaId="91-4528-9021-0044",
            name="John Doe",
            gender="Male",
            age=45,
            dob="15-May-1979",
            phone="9876543210",
            consentGiven=True,
            currentStep=1,
            symptoms=["Fever (2 Days)", "Right Lower Quadrant Pain", "Mild Nausea"],
            chiefComplaintDetails="Severe cramping pain in the right lower abdomen starting yesterday evening, accompanied by moderate fever (100.2°F).",
            hpiDetails="45-year-old male with 3-year history of Type-2 DM presents with acute onset right lower abdominal pain (VAS 6/10) for 36 hours.",
            vitals={"temp": "99.4 °F", "bp": "124/82 mmHg", "hr": "78 bpm", "spo2": "98%", "respRate": "16 bpm"},
            allergies=[{"name": "Penicillin", "reaction": "Severe - Anaphylaxis", "severity": "Severe"}],
            labResults=[{"test": "CBC (WBC)", "result": "11,800 /µL", "refRange": "4,500 - 11,000", "status": "High"}],
            consultType="allopathic",
            status="active",
            createdAt="2026-08-30T00:00:00.000Z"
        )
    ]

@router.post("/check-interactions", response_model=CheckInteractionsResponse)
async def check_drug_interactions(req: CheckInteractionsRequest, current_user: dict = Depends(allow_doctor)):
    """Check drug-drug interactions and allergy contraindications in real-time"""
    warnings = interaction_service.check_interactions(
        req.candidateMedicine,
        req.currentPrescriptions or [],
        req.knownAllergies or []
    )
    return CheckInteractionsResponse(warnings=warnings)

@router.post("/write-rx", response_model=PrescriptionResponse)
async def write_prescription(req: PrescriptionCreate, current_user: dict = Depends(allow_doctor)):
    """Save new prescription record to patient EMR"""
    rx_id = f"rx-{random.randint(100, 999)}"
    return PrescriptionResponse(
        id=rx_id,
        medicine=req.medicine,
        dosage=req.dosage,
        frequency=req.frequency,
        duration=req.duration,
        instructions=req.instructions,
        prescribedBy="Dr. Arvind Varma, MD"
    )
