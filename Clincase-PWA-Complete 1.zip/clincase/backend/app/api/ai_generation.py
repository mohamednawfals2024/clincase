from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import List, Optional
from app.services.ai_service import ai_service
from app.services.ai_history_engine import ai_history_engine
from app.schemas.ai_engine import (
    AdaptiveQuestionRequest, 
    AdaptiveQuestionResponse, 
    StructuredHistoryRequest, 
    StructuredClinicalHistory
)
from app.core.rbac import allow_guest

router = APIRouter(prefix="/ai", tags=["AI History Engine & Generation"])

class HpiGenerationRequest(BaseModel):
    symptoms: List[str]
    chiefComplaint: Optional[str] = ""
    age: Optional[int] = 45
    gender: Optional[str] = "Male"

class HpiGenerationResponse(BaseModel):
    hpiSummary: str

class AyushEvalRequest(BaseModel):
    prakritiAnswers: List[str]
    symptoms: List[str]

class AyushEvalResponse(BaseModel):
    prakritiType: str
    vikritiImbalance: str
    recommendations: List[str]

@router.post(
    "/adaptive-question", 
    response_model=AdaptiveQuestionResponse,
    summary="Generate Adaptive Clinical Question",
    description="Generates next adaptive clinical question based on chief complaint category (Abdominal, Fever, Respiratory, AYUSH) and step count."
)
async def generate_adaptive_question(
    req: AdaptiveQuestionRequest, 
    current_user: dict = Depends(allow_guest)
):
    if not req.chiefComplaint or not req.chiefComplaint.strip():
        raise HTTPException(status_code=400, detail="chiefComplaint is required")

    return await ai_history_engine.generate_adaptive_question(
        req.sessionId,
        req.chiefComplaint,
        req.symptoms or [],
        req.currentStep or 1,
        req.consultType or "allopathic"
    )

@router.post(
    "/structure-history", 
    response_model=StructuredClinicalHistory,
    summary="Synthesize Structured Clinical History",
    description="Converts multi-turn patient dialogue responses into validated Pydantic StructuredClinicalHistory JSON."
)
async def synthesize_history(
    req: StructuredHistoryRequest, 
    current_user: dict = Depends(allow_guest)
):
    if not req.chiefComplaint:
        raise HTTPException(status_code=400, detail="chiefComplaint is required")

    return await ai_history_engine.synthesize_clinical_history(
        req.sessionId,
        req.chiefComplaint,
        req.patientUtterances or [],
        req.consultType or "allopathic"
    )

@router.post("/generate-hpi", response_model=HpiGenerationResponse, summary="Synthesize HPI Summary")
async def generate_hpi(req: HpiGenerationRequest, current_user: dict = Depends(allow_guest)):
    sym_str = ", ".join(req.symptoms) if req.symptoms else "acute symptoms"
    summary = f"{req.age}-year-old {req.gender} presents with {sym_str}. {req.chiefComplaint or 'Symptoms started recently.'} No acute distress reported. Transcribed via Clincase AI History Engine."
    return HpiGenerationResponse(hpiSummary=summary)

@router.post("/ayush-eval", response_model=AyushEvalResponse, summary="Evaluate AYUSH Prakriti")
async def evaluate_ayush(req: AyushEvalRequest, current_user: dict = Depends(allow_guest)):
    return AyushEvalResponse(
        prakritiType="Vata-Pitta Dwandwaja (Lean build, warm extremities)",
        vikritiImbalance="Pitta Aggravation (Amlapitta - stomach heat, feverishness)",
        recommendations=["Spathya diet: Warm cooked mung bean soup", "Cooling herbs: Shatavari & Guduchi"]
    )
