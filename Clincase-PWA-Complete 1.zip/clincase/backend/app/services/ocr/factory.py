from app.config import settings
from app.services.ocr.base import OCRProvider
from app.services.ocr.providers import MockOCRProvider, GoogleGeminiOCRProvider, TesseractOCRProvider

def get_ocr_provider() -> OCRProvider:
    """Factory function returning active OCR provider based on OCR_PROVIDER env config"""
    provider_name = settings.OCR_PROVIDER.lower().strip()
    
    if provider_name == "gemini":
        return GoogleGeminiOCRProvider()
    elif provider_name == "tesseract":
        return TesseractOCRProvider()
    else:
        return MockOCRProvider()
