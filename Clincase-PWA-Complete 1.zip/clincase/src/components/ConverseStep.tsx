import React, { useState, useEffect } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Activity, 
  Radio, 
  CheckCircle2, 
  ArrowRight, 
  AlertTriangle,
  RotateCcw,
  Edit3,
  Bot,
  Send,
  Loader2,
  Sliders,
  Gauge,
  HelpCircle,
  Stethoscope,
  Clock,
  Compass,
  Zap,
  Check
} from 'lucide-react';
import { PatientSession, LanguageCode, ConsultType, NoiseGateConfig, SocratesPainProfile } from '../types';
import { translations, dashavidhaParikshaList } from '../data/translations';
import { clinicalIntakeSteps, socratesQuestions, calculateHistoryCompleteness } from '../data/clinicalQuestions';
import { audioService, converseDialogueAgent, DialogueAgentResponse } from '../services/api';
import { speechRecognizer } from '../services/speech';

interface ConverseStepProps {
  lang: LanguageCode;
  patient: PatientSession;
  consultType: ConsultType;
  onUpdatePatient: (updates: Partial<PatientSession>) => void;
  onProceedToScan: () => void;
  onTriggerEmergency: () => void;
}

export const ConverseStep: React.FC<ConverseStepProps> = ({
  lang,
  patient,
  consultType,
  onUpdatePatient,
  onProceedToScan,
  onTriggerEmergency
}) => {
  const isAyush = consultType === 'ayush';
  
  // Step indexing
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [socratesStepIndex, setSocratesStepIndex] = useState<number>(0);
  const [isPainPathwayActive, setIsPainPathwayActive] = useState<boolean>(false);
  const [socratesData, setSocratesData] = useState<SocratesPainProfile>(patient.socratesPain || {});

  // Audio / Speech State
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [isSuppressionActive, setIsSuppressionActive] = useState<boolean>(true);
  const [isGateOpen, setIsGateOpen] = useState<boolean>(false);
  const [currentAudioDb, setCurrentAudioDb] = useState<number>(-90);
  const [noiseGateConfig, setNoiseGateConfig] = useState<NoiseGateConfig>(audioService.getNoiseGateConfig());
  const [isCalibratingNoise, setIsCalibratingNoise] = useState<boolean>(false);
  const [showNoisePanel, setShowNoisePanel] = useState<boolean>(false);

  const [capturedVoiceText, setCapturedVoiceText] = useState<string>("");
  const [interimVoiceText, setInterimVoiceText] = useState<string>("");
  const [waveformLevels, setWaveformLevels] = useState<number[]>([15, 25, 20, 30, 20, 25, 18, 22, 16, 20, 15, 10]);
  const [isAgentThinking, setIsAgentThinking] = useState<boolean>(false);
  const [agentFeedback, setAgentFeedback] = useState<DialogueAgentResponse | null>(null);
  const [isSpeakingAgent, setIsSpeakingAgent] = useState<boolean>(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [isManualEditing, setIsManualEditing] = useState<boolean>(false);

  const t = translations[lang] || translations.en;

  // Active step definition
  const allopathicSteps = clinicalIntakeSteps;
  const currentStep = isAyush ? null : allopathicSteps[currentStepIndex];
  const currentAyushItem = isAyush ? dashavidhaParikshaList[currentStepIndex] : null;
  const totalSteps = isAyush ? dashavidhaParikshaList.length : allopathicSteps.length;
  const currentSocratesQuestion = isPainPathwayActive ? socratesQuestions[socratesStepIndex] : null;

  // Completeness score
  const completeness = calculateHistoryCompleteness(patient);

  // Sync noise gate configuration
  useEffect(() => {
    audioService.setNoiseGateEnabled(isSuppressionActive);
    setNoiseGateConfig(audioService.getNoiseGateConfig());
  }, [isSuppressionActive]);

  // Load existing answers on step switch
  useEffect(() => {
    setInterimVoiceText("");
    setSpeechError(null);
    setAgentFeedback(null);
    audioService.stop();
    speechRecognizer.stopListening();
    setIsRecording(false);
    setIsGateOpen(false);

    let existingAnswer = "";
    if (isAyush && currentAyushItem) {
      existingAnswer = patient.ayushDetails?.[currentAyushItem.param] || "";
    } else if (isPainPathwayActive && currentSocratesQuestion) {
      existingAnswer = (socratesData as any)[currentSocratesQuestion.key] || "";
    } else if (currentStep) {
      if (currentStep.key === 'chiefComplaint') existingAnswer = patient.chiefComplaintDetails || "";
      else if (currentStep.key === 'pastMedical') existingAnswer = patient.pastHistoryDetails || "";
      else if (currentStep.key === 'pastSurgical') existingAnswer = patient.pastSurgicalDetails || "";
      else if (currentStep.key === 'medicationHistory') existingAnswer = patient.medicationHistoryDetails || "";
      else if (currentStep.key === 'allergyHistory') existingAnswer = patient.allergyHistoryDetails || "";
      else if (currentStep.key === 'familyHistory') existingAnswer = patient.familyHistoryDetails || "";
      else if (currentStep.key === 'personalHistory') existingAnswer = patient.lifestyleDetails || "";
      else if (currentStep.key === 'reviewOfSystems') existingAnswer = patient.reviewOfSystems?.general || "";
    }
    setCapturedVoiceText(existingAnswer);
  }, [currentStepIndex, socratesStepIndex, isPainPathwayActive, isAyush]);

  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      audioService.stop();
      speechRecognizer.stopListening();
    };
  }, []);

  const getQuestionText = () => {
    if (isAyush) return currentAyushItem?.question || "";
    if (isPainPathwayActive && currentSocratesQuestion) {
      return currentSocratesQuestion.question[lang] || currentSocratesQuestion.question.en;
    }
    if (currentStep) {
      return currentStep.questionText[lang] || currentStep.questionText.en;
    }
    return "Please describe your health concern.";
  };

  const speakQuestionAloud = () => {
    audioService.playBeep('click');
    const textToSpeak = getQuestionText();
    audioService.speak(textToSpeak, lang, () => setIsSpeakingAgent(false), () => setIsSpeakingAgent(true));
  };

  const speakAgentResponseAloud = (text: string) => {
    audioService.playBeep('click');
    audioService.speak(text, lang, () => setIsSpeakingAgent(false), () => setIsSpeakingAgent(true));
  };

  const stopSpeaking = () => {
    audioService.stop();
    setIsSpeakingAgent(false);
  };

  const handleCalibrateNoise = async () => {
    setIsCalibratingNoise(true);
    audioService.playBeep('listen');
    await audioService.calibrateAmbientNoise(1200);
    setNoiseGateConfig(audioService.getNoiseGateConfig());
    setIsCalibratingNoise(false);
    audioService.playBeep('success');
  };

  // Process text with Gemini Clinical Dialogue Agent
  const processWithDialogueAgent = async (userText: string) => {
    if (!userText.trim()) return;

    setIsAgentThinking(true);
    setSpeechError(null);

    try {
      const response = await converseDialogueAgent({
        sessionId: patient.id,
        userUtterance: userText.trim(),
        step: isPainPathwayActive ? 100 + socratesStepIndex : currentStepIndex + 1,
        consultType,
        currentAyushParam: isAyush && currentAyushItem ? currentAyushItem.param : undefined,
        language: lang
      });

      setAgentFeedback(response);
      setIsAgentThinking(false);

      // Emergency Red-Flag detection check
      if (response.isRedFlag) {
        audioService.playBeep('alarm');
        onTriggerEmergency();
      } else {
        audioService.playBeep('success');
      }

      // Check if pain is detected in chief complaint to dynamically activate SOCRATES pathway
      const lower = userText.toLowerCase();
      const hasPainSymptom = lower.includes("pain") || lower.includes("dard") || lower.includes("ache") || 
                             lower.includes("vali") || lower.includes("noppi") || lower.includes("vedana") ||
                             lower.includes("stomach") || lower.includes("chest") || lower.includes("headache");

      if (currentStep?.key === 'chiefComplaint' && hasPainSymptom && !isPainPathwayActive) {
        setIsPainPathwayActive(true);
        setSocratesStepIndex(0);
      }

      // Apply structured updates to patient session
      if (isAyush && currentAyushItem) {
        const updatedAyush = {
          ...(patient.ayushDetails || {}),
          [currentAyushItem.param]: response.clinicalSummaryFragment || userText.trim()
        };
        onUpdatePatient({
          ayushDetails: updatedAyush,
          chiefComplaintDetails: "AYUSH Dashavidha Pariksha Intake in progress. Constitutional parameters mapped."
        });
      } else if (isPainPathwayActive && currentSocratesQuestion) {
        const updatedSocrates = {
          ...socratesData,
          [currentSocratesQuestion.key]: userText.trim()
        };
        setSocratesData(updatedSocrates);
        onUpdatePatient({
          socratesPain: updatedSocrates,
          hpiDetails: `SOCRATES Pain Profile: Site: ${updatedSocrates.site || 'Reported'}, Onset: ${updatedSocrates.onset || 'Acute'}, Character: ${updatedSocrates.character || 'Distressing'}, Radiation: ${updatedSocrates.radiation || 'None'}, Severity: ${updatedSocrates.severityScale || 'Moderate'}.`
        });
      } else if (currentStep) {
        if (currentStep.key === 'chiefComplaint') {
          const mergedSymptoms = Array.from(
            new Set([...(patient.symptoms || []), ...response.extractedSymptoms])
          );
          onUpdatePatient({
            symptoms: mergedSymptoms,
            chiefComplaintDetails: response.clinicalSummaryFragment || userText.trim()
          });
        } else if (currentStep.key === 'pastMedical') {
          onUpdatePatient({ pastHistoryDetails: response.clinicalSummaryFragment || userText.trim() });
        } else if (currentStep.key === 'pastSurgical') {
          onUpdatePatient({ pastSurgicalDetails: response.clinicalSummaryFragment || userText.trim() });
        } else if (currentStep.key === 'medicationHistory') {
          onUpdatePatient({ medicationHistoryDetails: response.clinicalSummaryFragment || userText.trim() });
        } else if (currentStep.key === 'allergyHistory') {
          onUpdatePatient({ allergyHistoryDetails: response.clinicalSummaryFragment || userText.trim() });
        } else if (currentStep.key === 'familyHistory') {
          onUpdatePatient({ familyHistoryDetails: response.clinicalSummaryFragment || userText.trim() });
        } else if (currentStep.key === 'personalHistory') {
          onUpdatePatient({ lifestyleDetails: response.clinicalSummaryFragment || userText.trim() });
        } else if (currentStep.key === 'reviewOfSystems') {
          onUpdatePatient({
            reviewOfSystems: {
              ...(patient.reviewOfSystems || {}),
              general: response.clinicalSummaryFragment || userText.trim()
            }
          });
        }
      }

      // Voice readback of AI confirmation
      if (response.spokenResponse) {
        speakAgentResponseAloud(response.spokenResponse);
      }
    } catch (err: any) {
      console.error("Error processing dialogue:", err);
      setIsAgentThinking(false);
    }
  };

  const handleStartRecording = async () => {
    if (isRecording) {
      handleStopRecording();
      return;
    }

    audioService.stop();
    audioService.playBeep('listen');
    setSpeechError(null);
    setInterimVoiceText("");
    setIsRecording(true);

    const started = await speechRecognizer.startListening(lang, {
      onStart: () => {
        setIsRecording(true);
      },
      onInterim: (interim) => {
        setInterimVoiceText(interim);
      },
      onResult: (finalText) => {
        setIsRecording(false);
        setIsGateOpen(false);
        setCapturedVoiceText(finalText);
        setInterimVoiceText("");
        processWithDialogueAgent(finalText);
      },
      onError: (errMsg) => {
        setIsRecording(false);
        setIsGateOpen(false);
        setSpeechError(errMsg);
        setWaveformLevels([15, 25, 20, 30, 20, 25, 18, 22, 16, 20, 15, 10]);
      },
      onEnd: () => {
        setIsRecording(false);
        setIsGateOpen(false);
        setWaveformLevels([15, 25, 20, 30, 20, 25, 18, 22, 16, 20, 15, 10]);
      },
      onVolumeChange: (vol) => {
        const bars = Array.from({ length: 12 }, (_, i) => {
          const factor = 1 - Math.abs(i - 5.5) / 6;
          return Math.min(80, Math.max(12, Math.round(vol * factor + Math.random() * 10)));
        });
        setWaveformLevels(bars);
      },
      onGateChange: (gateOpen, db) => {
        setIsGateOpen(gateOpen);
        setCurrentAudioDb(db);
      }
    });

    if (!started) {
      setIsRecording(false);
      setIsGateOpen(false);
    }
  };

  const handleStopRecording = () => {
    speechRecognizer.stopListening();
    setIsRecording(false);
    setIsGateOpen(false);
    audioService.playBeep('click');
    setWaveformLevels([15, 25, 20, 30, 20, 25, 18, 22, 16, 20, 15, 10]);
  };

  const handleManualSubmit = () => {
    if (!capturedVoiceText.trim()) return;
    audioService.playBeep('click');
    setIsManualEditing(false);
    processWithDialogueAgent(capturedVoiceText);
  };

  const handleSelectQuickOption = (opt: string) => {
    audioService.playBeep('click');
    setCapturedVoiceText(opt);
    processWithDialogueAgent(opt);
  };

  const handleNextStep = () => {
    audioService.playBeep('click');
    audioService.stop();

    if (isPainPathwayActive) {
      if (socratesStepIndex < socratesQuestions.length - 1) {
        setSocratesStepIndex(socratesStepIndex + 1);
        setCapturedVoiceText("");
        setAgentFeedback(null);
        return;
      } else {
        // Finished SOCRATES pain analysis, transition back to standard clinical history (Past Medical)
        setIsPainPathwayActive(false);
        setCurrentStepIndex(1); // Proceed to Past Medical
        setCapturedVoiceText("");
        setAgentFeedback(null);
        return;
      }
    }

    if (currentStepIndex >= totalSteps - 1) {
      onProceedToScan();
    } else {
      const next = currentStepIndex + 1;
      setCurrentStepIndex(next);
      setCapturedVoiceText("");
      setAgentFeedback(null);
      onUpdatePatient({ currentStep: next + 1 });
    }
  };

  const handlePreviousStep = () => {
    audioService.playBeep('click');
    audioService.stop();

    if (isPainPathwayActive) {
      if (socratesStepIndex > 0) {
        setSocratesStepIndex(socratesStepIndex - 1);
      } else {
        setIsPainPathwayActive(false);
        setCurrentStepIndex(0);
      }
      setCapturedVoiceText("");
      setAgentFeedback(null);
      return;
    }

    if (currentStepIndex > 0) {
      const prev = currentStepIndex - 1;
      setCurrentStepIndex(prev);
      setCapturedVoiceText("");
      setAgentFeedback(null);
      onUpdatePatient({ currentStep: prev + 1 });
    }
  };

  // Quick options for current context
  const getQuickOptions = (): string[] => {
    if (isAyush && currentAyushItem) {
      return currentAyushItem.quickOptions;
    }
    if (isPainPathwayActive && currentSocratesQuestion) {
      return currentSocratesQuestion.quickOptions[lang] || currentSocratesQuestion.quickOptions.en;
    }
    if (currentStep) {
      return currentStep.quickOptions[lang] || currentStep.quickOptions.en;
    }
    return [];
  };

  return (
    <div id="converse-step-container" className="flex flex-col h-full bg-slate-950 text-slate-100 select-none">
      
      {/* Top Header & Clinical Progress Navigation */}
      <div id="converse-header" className="bg-slate-900/90 border-b border-slate-800/80 px-6 py-4 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-teal-400 bg-teal-950/60 px-2 py-0.5 rounded border border-teal-800/50">
                  {isAyush ? 'AYUSH Dashavidha Pariksha' : isPainPathwayActive ? 'SOCRATES Pain Protocol' : 'Clinical OPD Intake'}
                </span>
                <span className="text-xs text-slate-400">
                  Step {isPainPathwayActive ? `Pain (${socratesStepIndex + 1}/${socratesQuestions.length})` : `${currentStepIndex + 1} of ${totalSteps}`}
                </span>
              </div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                {isAyush 
                  ? `${currentAyushItem?.sanskritName} (${currentAyushItem?.param})`
                  : isPainPathwayActive 
                    ? `[${currentSocratesQuestion?.letter}] ${currentSocratesQuestion?.concept}`
                    : currentStep?.titleKey}
              </h2>
            </div>
          </div>

          {/* History Completeness Badge & Controls */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
            
            {/* AI History Completeness Gauge */}
            <div className="flex items-center gap-2 bg-slate-800/70 border border-slate-700/60 px-3 py-1.5 rounded-lg">
              <Gauge className="w-4 h-4 text-emerald-400" />
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-medium">History Completeness</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 transition-all duration-500"
                      style={{ width: `${completeness.score}%` }}
                    />
                  </div>
                  <span className="text-xs font-bold text-emerald-400">{completeness.score}%</span>
                </div>
              </div>
            </div>

            {/* Noise Suppression & Calibrate Toggle */}
            <button
              id="btn-noise-settings"
              onClick={() => setShowNoisePanel(!showNoisePanel)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-all ${
                isSuppressionActive 
                  ? 'bg-teal-950/40 border-teal-700/60 text-teal-300 hover:bg-teal-900/40' 
                  : 'bg-slate-800/60 border-slate-700 text-slate-400'
              }`}
              title="Noise Gate for Crowded OPD Lobbies"
            >
              <Sliders className="w-3.5 h-3.5 text-teal-400" />
              <span className="hidden sm:inline">Noise Filter</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </button>

            {/* Emergency Red-Flag Trigger */}
            <button
              id="btn-emergency-trigger"
              onClick={onTriggerEmergency}
              className="px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-700/80 text-rose-200 text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-rose-950/50 transition-all active:scale-95"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
              <span>EMERGENCY</span>
            </button>
          </div>
        </div>

        {/* Multi-Step Clinical Progress Tracker */}
        <div className="max-w-7xl mx-auto mt-3 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {isAyush ? (
            dashavidhaParikshaList.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentStepIndex(idx);
                  setIsPainPathwayActive(false);
                }}
                className={`flex-1 min-w-[70px] py-1.5 px-2 rounded text-[11px] font-medium border text-center transition-all ${
                  idx === currentStepIndex
                    ? 'bg-amber-500/20 border-amber-500/60 text-amber-300 font-bold shadow-sm'
                    : patient.ayushDetails?.[item.param]
                      ? 'bg-slate-800/80 border-teal-600/50 text-teal-300'
                      : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:bg-slate-800/40'
                }`}
              >
                {item.param}
              </button>
            ))
          ) : (
            allopathicSteps.map((step, idx) => (
              <button
                key={step.id}
                onClick={() => {
                  setCurrentStepIndex(idx);
                  setIsPainPathwayActive(false);
                }}
                className={`flex-1 min-w-[100px] py-1.5 px-2 rounded text-[11px] font-medium border text-center transition-all flex items-center justify-center gap-1 ${
                  idx === currentStepIndex && !isPainPathwayActive
                    ? 'bg-teal-500/20 border-teal-500/60 text-teal-300 font-bold shadow-sm'
                    : (idx === 0 && patient.chiefComplaintDetails) ||
                      (idx === 1 && patient.pastHistoryDetails) ||
                      (idx === 2 && patient.pastSurgicalDetails) ||
                      (idx === 3 && patient.medicationHistoryDetails) ||
                      (idx === 4 && patient.allergyHistoryDetails) ||
                      (idx === 5 && patient.familyHistoryDetails) ||
                      (idx === 6 && patient.lifestyleDetails) ||
                      (idx === 7 && patient.reviewOfSystems)
                      ? 'bg-slate-800/80 border-emerald-600/50 text-emerald-300'
                      : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:bg-slate-800/40'
                }`}
              >
                {((idx === 0 && patient.chiefComplaintDetails) ||
                  (idx === 1 && patient.pastHistoryDetails) ||
                  (idx === 2 && patient.pastSurgicalDetails) ||
                  (idx === 3 && patient.medicationHistoryDetails) ||
                  (idx === 4 && patient.allergyHistoryDetails) ||
                  (idx === 5 && patient.familyHistoryDetails) ||
                  (idx === 6 && patient.lifestyleDetails) ||
                  (idx === 7 && patient.reviewOfSystems)) && (
                  <Check className="w-3 h-3 text-emerald-400" />
                )}
                <span className="truncate">{step.titleKey.split(' ')[0]}</span>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Noise Gate Calibration Sub-Panel */}
      {showNoisePanel && (
        <div id="noise-panel" className="bg-slate-900 border-b border-slate-800 px-6 py-3 transition-all animate-fadeIn">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-semibold text-slate-300">OPD Noise Gate:</span>
              <button
                onClick={() => setIsSuppressionActive(!isSuppressionActive)}
                className={`px-2.5 py-1 rounded font-medium ${
                  isSuppressionActive ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {isSuppressionActive ? 'Filtering Enabled' : 'Filtering Disabled'}
              </button>
              <span className="text-slate-400">Current Mic Input: <span className="font-mono text-teal-400 font-bold">{currentAudioDb} dB</span></span>
              <span className={`px-2 py-0.5 rounded font-mono text-[10px] ${isGateOpen ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-slate-800 text-slate-500'}`}>
                {isGateOpen ? 'VOICE GATE OPEN' : 'NOISE BLOCKED'}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                id="btn-calibrate-noise"
                onClick={handleCalibrateNoise}
                disabled={isCalibratingNoise}
                className="px-3 py-1 rounded bg-teal-900/60 hover:bg-teal-800 border border-teal-700 text-teal-200 flex items-center gap-1.5 transition-all disabled:opacity-50"
              >
                {isCalibratingNoise ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-teal-400" />}
                <span>{isCalibratingNoise ? 'Sampling Ambient Lobby Noise...' : 'Auto-Calibrate for OPD Lobby'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Clinical Interaction Body */}
      <div id="converse-main-content" className="flex-1 overflow-y-auto px-6 py-6 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Adaptive Question & Real-Time ASR / TTS Interface (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between gap-5">
          
          {/* Question Card */}
          <div id="question-card" className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden backdrop-blur-md">
            
            {/* Background Decorative Gradient */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-400">
                    {isAyush 
                      ? `AYUSH Pariksha #${currentStepIndex + 1}` 
                      : isPainPathwayActive 
                        ? `Pain Analysis (SOCRATES)` 
                        : currentStep?.category}
                  </span>
                  {isPainPathwayActive && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 border border-amber-700/60 text-amber-300 animate-pulse">
                      Active Pain Pathway
                    </span>
                  )}
                </div>
                <h1 className="text-xl md:text-2xl font-bold text-white leading-snug">
                  {getQuestionText()}
                </h1>
                <p className="text-xs text-slate-400 mt-2">
                  {isAyush 
                    ? currentAyushItem?.description 
                    : isPainPathwayActive 
                      ? "SOCRATES systematic pain analysis for accurate OPD diagnosis" 
                      : currentStep?.subtitleText[lang] || currentStep?.subtitleText.en}
                </p>
              </div>

              {/* Text-to-Speech Aloud Button */}
              <button
                id="btn-speak-question"
                onClick={isSpeakingAgent ? stopSpeaking : speakQuestionAloud}
                className={`p-3 rounded-xl border transition-all shrink-0 ${
                  isSpeakingAgent 
                    ? 'bg-teal-500/30 border-teal-400 text-teal-300 ring-2 ring-teal-500/40 animate-pulse' 
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
                title="Listen to question spoken aloud in your language"
              >
                {isSpeakingAgent ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-teal-400" />}
              </button>
            </div>

            {/* Quick Answer Pills for Instant Selection or Voice Assist */}
            <div className="mt-4 pt-4 border-t border-slate-800/80">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold mb-2.5 block">
                Suggested Quick Answers (Tap or Speak):
              </span>
              <div className="flex flex-wrap gap-2">
                {getQuickOptions().map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectQuickOption(opt)}
                    className="px-3 py-2 rounded-xl bg-slate-800/70 hover:bg-teal-900/40 border border-slate-700/70 hover:border-teal-600/60 text-slate-200 hover:text-teal-200 text-xs font-medium transition-all text-left shadow-sm active:scale-95"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Real-Time Speech-to-Text Voice Recording Console */}
          <div id="voice-recording-console" className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between backdrop-blur-md">
            
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Radio className={`w-4 h-4 ${isRecording ? 'text-rose-500 animate-pulse' : 'text-slate-500'}`} />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  {isRecording ? 'Real-Time ASR Active (Speak in Your Language)' : 'Voice Input Ready'}
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                Language: <strong className="text-teal-400 font-semibold">{lang.toUpperCase()}</strong>
              </span>
            </div>

            {/* Visualizer Waveform */}
            <div className="h-16 bg-slate-950 rounded-xl border border-slate-800/80 flex items-center justify-center gap-1.5 px-4 overflow-hidden mb-4">
              {isRecording ? (
                waveformLevels.map((val, i) => (
                  <div
                    key={i}
                    className="w-2 rounded-full bg-gradient-to-t from-teal-600 to-emerald-400 transition-all duration-75"
                    style={{ height: `${val}%` }}
                  />
                ))
              ) : (
                <div className="text-slate-500 text-xs flex items-center gap-2">
                  <Mic className="w-4 h-4" />
                  <span>Tap the large microphone button below and speak naturally.</span>
                </div>
              )}
            </div>

            {/* Live Captured / Interim Speech Transcript */}
            <div className="min-h-[80px] bg-slate-950/60 rounded-xl border border-slate-800 p-3 text-sm font-medium mb-4 relative">
              {interimVoiceText ? (
                <p className="text-teal-300 italic animate-pulse">
                  "{interimVoiceText}..."
                </p>
              ) : capturedVoiceText ? (
                <div>
                  <p className="text-slate-200">
                    "{capturedVoiceText}"
                  </p>
                  <button
                    onClick={() => setIsManualEditing(true)}
                    className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>Edit</span>
                  </button>
                </div>
              ) : (
                <p className="text-slate-500 italic text-xs">
                  Your spoken words will appear here in real time...
                </p>
              )}

              {speechError && (
                <div className="mt-2 text-xs text-rose-400 bg-rose-950/50 border border-rose-800/60 p-2 rounded-lg flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{speechError}</span>
                </div>
              )}
            </div>

            {/* Manual Edit Input Modal / Box */}
            {isManualEditing && (
              <div className="mb-4 bg-slate-800/80 border border-slate-700 rounded-xl p-3">
                <textarea
                  value={capturedVoiceText}
                  onChange={(e) => setCapturedVoiceText(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-100 focus:outline-none focus:border-teal-500 min-h-[60px]"
                  placeholder="Type or correct your symptoms manually..."
                />
                <div className="flex justify-end gap-2 mt-2">
                  <button
                    onClick={() => setIsManualEditing(false)}
                    className="px-3 py-1 text-xs text-slate-400 hover:text-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleManualSubmit}
                    className="px-4 py-1 rounded bg-teal-600 hover:bg-teal-500 text-xs font-bold text-white flex items-center gap-1"
                  >
                    <Send className="w-3 h-3" />
                    <span>Save & Analyze</span>
                  </button>
                </div>
              </div>
            )}

            {/* Big Mic Button & Controls */}
            <div className="flex items-center justify-between gap-4">
              <button
                id="btn-restart-step"
                onClick={() => {
                  setCapturedVoiceText("");
                  setAgentFeedback(null);
                }}
                className="p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-slate-200 text-xs flex items-center gap-1.5 transition-all"
                title="Clear and re-record this answer"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="hidden sm:inline">Clear</span>
              </button>

              {/* Central Pulsing Record Button */}
              <button
                id="btn-mic-main"
                onClick={handleStartRecording}
                disabled={isAgentThinking}
                className={`px-6 py-3.5 rounded-2xl font-bold text-sm flex items-center gap-3 transition-all shadow-xl active:scale-95 ${
                  isRecording 
                    ? 'bg-rose-600 hover:bg-rose-500 text-white ring-4 ring-rose-500/40 shadow-rose-900/50 animate-pulse' 
                    : 'bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 ring-2 ring-teal-500/30'
                }`}
              >
                {isRecording ? (
                  <>
                    <MicOff className="w-5 h-5" />
                    <span>STOP RECORDING</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5" />
                    <span>START SPEAKING</span>
                  </>
                )}
              </button>

              {/* Step Navigation Button */}
              <button
                id="btn-next-step"
                onClick={handleNextStep}
                className="px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-teal-600 border border-slate-700 hover:border-teal-500 text-slate-100 font-bold text-xs flex items-center gap-2 transition-all active:scale-95 shadow-md"
              >
                <span>{currentStepIndex >= totalSteps - 1 && !isPainPathwayActive ? 'Document Scan →' : 'Next Step'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: AI Clinical Feedback & Entity Extraction Panel (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          
          {/* Gemini AI Clinical Agent Feedback Card */}
          <div id="ai-agent-feedback-card" className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-md flex-1 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-400">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-200">Clinical AI Dialogue Agent</h3>
                    <span className="text-[10px] text-teal-400">Gemini 3.7 Flash Engine</span>
                  </div>
                </div>

                {isAgentThinking && (
                  <span className="text-[11px] text-teal-400 font-semibold flex items-center gap-1.5 animate-pulse">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Analyzing clinical entities...
                  </span>
                )}
              </div>

              {/* Spoken AI Acknowledgement */}
              {agentFeedback?.spokenResponse ? (
                <div className="bg-teal-950/40 border border-teal-800/60 rounded-xl p-3.5 mb-4">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] uppercase tracking-wider text-teal-400 font-bold flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Spoken AI Acknowledgement:
                    </span>
                    <button
                      onClick={() => speakAgentResponseAloud(agentFeedback.spokenResponse)}
                      className="p-1 rounded text-teal-400 hover:text-teal-200"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-200 italic leading-relaxed">
                    "{agentFeedback.spokenResponse}"
                  </p>
                </div>
              ) : (
                <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-3.5 mb-4 text-xs text-slate-500">
                  Speak into the microphone to receive real-time clinical entity validation and spoken voice confirmation.
                </div>
              )}

              {/* Extracted Clinical Symptoms */}
              <div className="mb-4">
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold mb-2 block">
                  Identified Clinical Symptoms:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(patient.symptoms && patient.symptoms.length > 0) ? (
                    patient.symptoms.map((sym, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-700/50 text-emerald-300 text-xs font-semibold flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        {sym}
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-slate-500 italic">No symptoms recorded yet</span>
                  )}
                </div>
              </div>

              {/* SOCRATES Pain Snapshot (if active) */}
              {isPainPathwayActive && (
                <div className="bg-amber-950/30 border border-amber-800/50 rounded-xl p-3 mb-3">
                  <span className="text-[10px] uppercase tracking-wider text-amber-400 font-bold mb-1.5 block">
                    SOCRATES Pain Profile (In Progress):
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                    <div className="text-slate-400">Site: <span className="text-slate-200 font-semibold">{socratesData.site || 'Pending'}</span></div>
                    <div className="text-slate-400">Onset: <span className="text-slate-200 font-semibold">{socratesData.onset || 'Pending'}</span></div>
                    <div className="text-slate-400">Character: <span className="text-slate-200 font-semibold">{socratesData.character || 'Pending'}</span></div>
                    <div className="text-slate-400">Radiation: <span className="text-slate-200 font-semibold">{socratesData.radiation || 'Pending'}</span></div>
                    <div className="text-slate-400">Severity: <span className="text-slate-200 font-semibold">{socratesData.severityScale || 'Pending'}</span></div>
                  </div>
                </div>
              )}
            </div>

            {/* DPDP Act 2023 Compliance & Security Notice */}
            <div className="pt-3 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-teal-400" />
                DPDP Act 2023: Raw Audio Purged
              </span>
              <span className="text-slate-400 font-mono">ABDM Level-3 Encrypted</span>
            </div>
          </div>

          {/* Quick Navigation / Step Overview Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400 flex items-center justify-between">
            <button
              onClick={handlePreviousStep}
              disabled={currentStepIndex === 0 && !isPainPathwayActive}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              ← Previous Step
            </button>
            <span className="text-[11px] text-slate-400">
              {isPainPathwayActive 
                ? `Pain Q ${socratesStepIndex + 1}/${socratesQuestions.length}`
                : `Section ${currentStepIndex + 1} of ${totalSteps}`}
            </span>
            <button
              onClick={handleNextStep}
              className="px-3 py-1.5 rounded-lg bg-teal-600/80 hover:bg-teal-500 text-white font-bold text-xs transition-all"
            >
              {currentStepIndex >= totalSteps - 1 && !isPainPathwayActive ? 'To Document Scan →' : 'Continue →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
