// ============================================================================
// CLINCASE PWA SERVICE WORKER (v1.1.0)
// High-Performance App Shell Caching & Resilient Offline OPD Continuity
// ============================================================================

const CACHE_NAME = 'clincase-pwa-v1.1.0';

// Core static assets for the App Shell
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.png',
  '/icons/icon.svg',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png',
  '/icons/icon-maskable-192x192.png',
  '/icons/icon-maskable-512x512.png',
  '/icons/apple-touch-icon.png',
  '/icons/favicon-32x32.png',
  '/icons/favicon-16x16.png'
];

// 1. Install Event: Pre-cache App Shell
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[SW] Pre-caching Clincase App Shell assets for offline operation');
      return cache.addAll(PRECACHE_ASSETS);
    }).then(() => {
      return self.skipWaiting();
    }).catch((err) => {
      console.warn('[SW] Pre-caching warning:', err);
    })
  );
});

// 2. Activate Event: Clean up outdated caches & take control immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((name) => {
          if (name !== CACHE_NAME) {
            console.log('[SW] Deleting obsolete cache version:', name);
            return caches.delete(name);
          }
        })
      );
    }).then(() => {
      return self.clients.claim();
    })
  );
});

// 3. Fetch Event: Smart Routing & Offline-First Strategy
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Only handle standard HTTP/HTTPS GET requests
  if (request.method !== 'GET') {
    return;
  }

  const url = new URL(request.url);

  // Skip browser extensions, chrome-extension://, or non-http protocols
  if (!url.protocol.startsWith('http')) {
    return;
  }

  // A. Dynamic API Requests, SSE Streams, and Auth Routes: Network-First with Safe Fallback
  // Do NOT cache API endpoints to prevent stale clinical data or blocked SSE streams
  const isApiRoute = 
    url.pathname.startsWith('/api/') || 
    url.pathname.startsWith('/session/') || 
    url.pathname.startsWith('/summary/') || 
    url.pathname.startsWith('/patient/') || 
    url.pathname.startsWith('/auth/') || 
    url.pathname.startsWith('/doctor/') || 
    url.pathname.startsWith('/fhir/') ||
    url.pathname.startsWith('/docs') ||
    url.pathname.startsWith('/openapi.json');

  if (isApiRoute) {
    event.respondWith(
      fetch(request).catch(() => {
        // Return offline JSON message if network is unavailable during API call
        return new Response(
          JSON.stringify({ 
            offline: true,
            error: 'NetworkOffline', 
            message: 'You are currently working in offline mode. Client-side local engine is active.' 
          }),
          { 
            status: 200, 
            headers: { 'Content-Type': 'application/json' } 
          }
        );
      })
    );
    return;
  }

  // B. Navigation Requests (HTML document / page loads): Network-First with Cache Fallback
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.status === 200) {
            const responseClone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(async () => {
          const cachedPage = await caches.match(request);
          if (cachedPage) return cachedPage;
          const cachedRoot = await caches.match('/');
          if (cachedRoot) return cachedRoot;
          return caches.match('/index.html');
        })
    );
    return;
  }

  // C. Google Fonts & CDNs: Cache-First with Network Fetch
  if (url.origin.includes('fonts.googleapis.com') || url.origin.includes('fonts.gstatic.com')) {
    event.respondWith(
      caches.match(request).then((cachedResponse) => {
        if (cachedResponse) return cachedResponse;
        return fetch(request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return networkResponse;
        }).catch(() => cachedResponse);
      })
    );
    return;
  }

  // D. Static Assets (JS, CSS, Web Fonts, Images, Icons): Stale-While-Revalidate
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // Fallback if offline
          return cachedResponse;
        });

      return cachedResponse || fetchPromise;
    })
  );
});

// 4. Message Event: Instant Skip Waiting trigger
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
