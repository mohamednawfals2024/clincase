import os
import random
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from fastapi.responses import FileResponse
from app.config import settings
from app.schemas.document import DocumentResponse, StructuredOcrPipelineResponse
from app.services.ocr_service import ocr_service
from app.services.ocr.factory import get_ocr_provider
from app.core.rbac import allow_guest

router = APIRouter(prefix="/documents", tags=["Document OCR & Digitization"])

# Ensure preservation upload directory exists
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

@router.post(
    "/pipeline", 
    response_model=StructuredOcrPipelineResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Medical Document Processing Pipeline",
    description="Accepts PDF/image uploads, runs OCR via configurable provider, extracts structured entities (meds, diagnoses, investigations, dates), and preserves original file on disk for physician verification."
)
async def process_document_pipeline(
    file: UploadFile = File(...),
    sessionId: str = Form(""),
    current_user: dict = Depends(allow_guest)
):
    if not file or not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Valid document upload is required"
        )

    content = await file.read()
    if len(content) == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Uploaded document is empty (0 bytes)"
        )

    doc_id = f"doc-{random.randint(10000, 99999)}"
    safe_filename = f"{doc_id}_{os.path.basename(file.filename)}"
    saved_filepath = os.path.join(settings.UPLOAD_DIR, safe_filename)

    # 1. Preserve original document file on disk for physician verification
    try:
        with open(saved_filepath, "wb") as f:
            f.write(content)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to preserve raw document file on disk: {str(e)}"
        )

    raw_document_url = f"/api/v1/documents/raw/{doc_id}"

    # 2. Execute configurable OCR provider extraction
    provider = get_ocr_provider()
    payload = await provider.extract(
        file_bytes=content,
        filename=file.filename,
        content_type=file.content_type or "application/pdf",
        doc_id=doc_id,
        raw_url=raw_document_url
    )

    return StructuredOcrPipelineResponse(
        documentId=payload.document_id,
        fileName=payload.file_name,
        documentType=payload.document_type,
        rawDocumentUrl=payload.raw_document_url,
        ocrConfidence=payload.ocr_confidence,
        isHandwritten=payload.is_handwritten,
        ocrProvider=payload.ocr_provider,
        extractedMedications=payload.extracted_medications,
        extractedDiagnoses=payload.extracted_diagnoses,
        extractedInvestigations=payload.extracted_investigations,
        extractedDates=payload.extracted_dates,
        rawTextSummary=payload.raw_text_summary
    )

@router.get(
    "/raw/{doc_id}",
    summary="Get Preserved Original Document File",
    description="Streams the preserved raw uploaded PDF or image file for physician side-by-side verification."
)
async def get_raw_document(doc_id: str, current_user: dict = Depends(allow_guest)):
    # Search preserved upload directory for file matching doc_id
    if not os.path.exists(settings.UPLOAD_DIR):
        raise HTTPException(status_code=404, detail="Preserved document file not found")

    for f in os.listdir(settings.UPLOAD_DIR):
        if f.startswith(doc_id):
            filepath = os.path.join(settings.UPLOAD_DIR, f)
            return FileResponse(filepath)

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND, 
        detail=f"Preserved document file '{doc_id}' not found for physician verification"
    )

@router.post(
    "/upload", 
    response_model=DocumentResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Upload Scanned Medical Document or Prescription (Legacy)",
    description="Handles multipart medical document upload, performs OCR entity extraction, and persists entities."
)
async def upload_document(
    file: UploadFile = File(...),
    sessionId: str = Form(""),
    current_user: dict = Depends(allow_guest)
):
    if not file or not file.filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Valid file upload is required"
        )

    content = await file.read()
    result = ocr_service.process_document(file.filename, file.content_type or "application/pdf", content)

    return DocumentResponse(
        id=result["id"],
        name=result["name"],
        pages=result["pages"],
        size=result["size"],
        type=result["type"],
        url=result["url"],
        timestamp=result["timestamp"],
        extractedText=result["extractedText"],
        extractedMeds=result["extractedMeds"],
        extractedDiagnoses=result["extractedDiagnoses"],
        structuredMeds=result["structuredMeds"],
        structuredLabs=result["structuredLabs"],
        ocrConfidence=result["ocrConfidence"],
        isHandwritten=result["isHandwritten"],
        ocrLanguage=result["ocrLanguage"]
    )
