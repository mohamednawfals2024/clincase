import React, { useState } from 'react';
import { 
  Stethoscope, 
  ShieldCheck, 
  Lock, 
  Key, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Sparkles, 
  ArrowRight,
  ShieldAlert
} from 'lucide-react';
import { audioService } from '../services/api';

interface RoleLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetRole: 'doctor' | 'admin';
  onLoginSuccess: (role: 'doctor' | 'admin', name: string) => void;
}

export const RoleLoginModal: React.FC<RoleLoginModalProps> = ({
  isOpen,
  onClose,
  targetRole,
  onLoginSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'doctor' | 'admin'>(targetRole);
  const [doctorId, setDoctorId] = useState('DOC-MD-8921');
  const [doctorPassword, setDoctorPassword] = useState('');
  const [adminId, setAdminId] = useState('ADMIN-SEC-01');
  const [adminPassword, setAdminPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleDoctorLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    setTimeout(() => {
      // Validate credentials or demo login
      if (!doctorId.trim()) {
        setErrorMsg('Please enter your Medical License / Employee ID.');
        setLoading(false);
        return;
      }
      audioService.playBeep('success');
      setLoading(false);
      onLoginSuccess('doctor', 'Dr. Arvind Varma, MD');
      onClose();
    }, 400);
  };

  const handleAdminLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    setTimeout(() => {
      if (!adminId.trim()) {
        setErrorMsg('Please enter your Security Officer / Admin ID.');
        setLoading(false);
        return;
      }
      audioService.playBeep('success');
      setLoading(false);
      onLoginSuccess('admin', 'Hospital Admin (Sec-01)');
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0E1626] border border-[#1E2D4A] rounded-3xl max-w-md w-full p-6 md:p-8 text-slate-100 shadow-2xl space-y-6 relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-400 border border-teal-500/20 flex items-center justify-center font-bold">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold font-serif text-white">
              Role Authentication
            </h2>
            <p className="text-xs text-slate-400">
              Restricted Dashboard Access • Enter Credentials to Proceed
            </p>
          </div>
        </div>

        {/* Role Tabs */}
        <div className="flex border-b border-slate-800 font-semibold text-xs">
          <button
            onClick={() => {
              setActiveTab('doctor');
              setErrorMsg(null);
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-3 border-b-2 transition-all cursor-pointer ${
              activeTab === 'doctor'
                ? 'border-teal-400 text-teal-400 bg-teal-500/5 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Stethoscope className="w-4 h-4" />
            <span>Doctor Login</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('admin');
              setErrorMsg(null);
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-3 border-b-2 transition-all cursor-pointer ${
              activeTab === 'admin'
                ? 'border-amber-400 text-amber-400 bg-amber-500/5 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Admin Login</span>
          </button>
        </div>

        {/* Error Banner */}
        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Doctor Login Form */}
        {activeTab === 'doctor' && (
          <form onSubmit={handleDoctorLogin} className="space-y-4 text-xs">
            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-teal-400" />
                <span>Medical License / Employee ID:</span>
              </label>
              <input
                type="text"
                value={doctorId}
                onChange={(e) => setDoctorId(e.target.value)}
                placeholder="e.g. DOC-MD-8921"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-teal-500 font-mono outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-teal-400" />
                <span>Passcode / Security Key:</span>
              </label>
              <input
                type="password"
                value={doctorPassword}
                onChange={(e) => setDoctorPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-teal-500 font-mono outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md"
            >
              {loading ? 'Authenticating...' : 'Sign In as Doctor'}
            </button>

            {/* Quick Demo Login */}
            <div className="pt-2 border-t border-slate-800/80 text-center">
              <button
                type="button"
                onClick={() => handleDoctorLogin()}
                className="w-full py-2.5 bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 border border-teal-500/30 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                <span>⚡ Quick Demo Login (Doctor)</span>
              </button>
            </div>
          </form>
        )}

        {/* Admin Login Form */}
        {activeTab === 'admin' && (
          <form onSubmit={handleAdminLogin} className="space-y-4 text-xs">
            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span>Security Officer / Admin ID:</span>
              </label>
              <input
                type="text"
                value={adminId}
                onChange={(e) => setAdminId(e.target.value)}
                placeholder="e.g. ADMIN-SEC-01"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 font-mono outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-amber-400" />
                <span>Admin Passcode:</span>
              </label>
              <input
                type="password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 font-mono outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md"
            >
              {loading ? 'Authenticating...' : 'Sign In as Admin'}
            </button>

            {/* Quick Demo Login */}
            <div className="pt-2 border-t border-slate-800/80 text-center">
              <button
                type="button"
                onClick={() => handleAdminLogin()}
                className="w-full py-2.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>⚡ Quick Demo Login (Admin)</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
