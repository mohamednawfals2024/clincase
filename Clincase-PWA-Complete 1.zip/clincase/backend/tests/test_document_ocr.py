import io

def test_document_pipeline_ocr(client):
    """Test POST /api/v1/documents/pipeline with synthetic prescription PDF bytes"""
    fake_pdf_content = b"%PDF-1.4 Fake Synthetic Prescription Document Content for Unit Test"
    files = {
        "file": ("Prescription_Synthetic_01.pdf", io.BytesIO(fake_pdf_content), "application/pdf")
    }
    data = {
        "sessionId": "MED-49201"
    }
    response = client.post("/api/v1/documents/pipeline", data=data, files=files)
    assert response.status_code == 201
    res = response.json()
    assert res["fileName"] == "Prescription_Synthetic_01.pdf"
    assert "documentId" in res
    assert "rawDocumentUrl" in res
    assert res["ocrConfidence"] >= 80.0
    assert len(res["extractedMedications"]) > 0

def test_get_raw_preserved_document(client):
    """Test GET /api/v1/documents/raw/{doc_id} streaming preserved raw file"""
    fake_pdf_content = b"%PDF-1.4 Preserved Synthetic File Test"
    files = {
        "file": ("Preservation_Test.pdf", io.BytesIO(fake_pdf_content), "application/pdf")
    }
    pipeline_res = client.post("/api/v1/documents/pipeline", data={"sessionId": "MED-49201"}, files=files)
    assert pipeline_res.status_code == 201
    doc_id = pipeline_res.json()["documentId"]

    raw_res = client.get(f"/api/v1/documents/raw/{doc_id}")
    assert raw_res.status_code == 200
    assert len(raw_res.content) > 0
