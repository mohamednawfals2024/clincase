import random

def test_register_patient_success(client):
    """Test POST /api/v1/patients/register with valid synthetic payload"""
    unique_phone = f"98{random.randint(10000000, 99999999)}"
    unique_abha = f"91-{random.randint(1000,9999)}-{random.randint(1000,9999)}-{random.randint(1000,9999)}"
    
    payload = {
        "name": "Synthetic Test Patient",
        "age": 42,
        "gender": "Male",
        "dob": "12-Aug-1984",
        "phone": unique_phone,
        "abhaId": unique_abha,
        "consultType": "allopathic",
        "vitals": {
            "temp": "98.6 °F",
            "bp": "120/80 mmHg",
            "hr": "72 bpm",
            "spo2": "98%"
        }
    }
    
    response = client.post("/api/v1/patients/register", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Synthetic Test Patient"
    assert data["phone"] == unique_phone
    assert data["abhaId"] == unique_abha
    assert "id" in data

def test_register_patient_invalid_phone(client):
    """Test registration failure on invalid 5-digit phone number"""
    payload = {
        "name": "Invalid Phone Patient",
        "age": 30,
        "gender": "Female",
        "dob": "01-Jan-1996",
        "phone": "12345"
    }
    response = client.post("/api/v1/patients/register", json=payload)
    assert response.status_code == 422  # Pydantic Unprocessable Entity validation failure

def test_identify_patient_by_phone(client):
    """Test POST /api/v1/patients/identify lookup by phone"""
    unique_phone = f"97{random.randint(10000000, 99999999)}"
    reg_payload = {
        "name": "Lookup Target Patient",
        "age": 50,
        "gender": "Female",
        "dob": "05-May-1976",
        "phone": unique_phone
    }
    reg_res = client.post("/api/v1/patients/register", json=reg_payload)
    assert reg_res.status_code == 201

    identify_res = client.post("/api/v1/patients/identify", json={"identifier": unique_phone})
    assert identify_res.status_code == 200
    data = identify_res.json()
    assert data["name"] == "Lookup Target Patient"
    assert data["phone"] == unique_phone
