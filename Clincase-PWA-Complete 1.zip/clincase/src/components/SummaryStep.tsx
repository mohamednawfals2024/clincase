import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  Volume2, 
  FileText, 
  Activity, 
  Edit3, 
  ArrowRight,
  ShieldCheck,
  Stethoscope,
  Leaf,
  Sparkles,
  Loader2,
  AlertTriangle,
  Layers,
  HeartPulse,
  Pill
} from 'lucide-react';
import { PatientSession, LanguageCode, ConsultType } from '../types';
import { translations } from '../data/translations';
import { audioService, generateAiSummary } from '../services/api';
import { calculateHistoryCompleteness } from '../data/clinicalQuestions';

interface SummaryStepProps {
  lang: LanguageCode;
  patient: PatientSession;
  consultType: ConsultType;
  onEditByVoice: () => void;
  onConfirmAndProceed: () => void;
}

export const SummaryStep: React.FC<SummaryStepProps> = ({
  lang,
  patient,
  consultType,
  onEditByVoice,
  onConfirmAndProceed
}) => {
  const t = translations[lang] || translations.en;
  const isAyush = consultType === 'ayush';
  const completeness = calculateHistoryCompleteness(patient);

  const [aiSummary, setAiSummary] = useState<string>("");
  const [isLoadingSummary, setIsLoadingSummary] = useState<boolean>(true);

  // Generate complete synthesized AI summary
  useEffect(() => {
    let isMounted = true;
    async function loadSummary() {
      setIsLoadingSummary(true);
      try {
        const summary = await generateAiSummary({
          symptoms: patient.symptoms || [],
          chiefComplaint: patient.chiefComplaintDetails,
          consultType,
          ayushDetails: patient.ayushDetails,
          pastHistory: patient.pastHistoryDetails,
          pastSurgical: patient.pastSurgicalDetails,
          medicationHistory: patient.medicationHistoryDetails,
          allergyHistory: patient.allergyHistoryDetails,
          familyHistory: patient.familyHistoryDetails,
          lifestyle: patient.lifestyleDetails,
          reviewOfSystems: patient.reviewOfSystems,
          socratesPain: patient.socratesPain,
          documents: patient.documents,
          labResults: patient.labResults,
          vitals: patient.vitals
        });
        if (isMounted) {
          setAiSummary(summary);
          setIsLoadingSummary(false);
        }
      } catch (err) {
        if (isMounted) {
          setAiSummary(`Clinical Intake: Patient presents with ${patient.symptoms?.join(', ') || 'symptoms'}. Ready for doctor examination.`);
          setIsLoadingSummary(false);
        }
      }
    }
    loadSummary();
    return () => { isMounted = false; };
  }, [patient, consultType]);

  const handleReadSummaryAloud = () => {
    audioService.playBeep('click');
    const spokenText = isAyush
      ? `You completed the Ayurvedic intake. Your history completeness is ${completeness.score} percent. ${patient.documents?.length || 0} medical documents were digitized.`
      : `Clinical intake complete with ${completeness.score} percent completeness score. Chief complaint and ${patient.symptoms?.length || 0} symptoms recorded.`;
    audioService.speak(spokenText, lang);
  };

  return (
    <div id="summary-step-container" className="w-full max-w-4xl mx-auto flex flex-col gap-6 animate-fadeIn pb-8 select-none">
      
      {/* Title Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-teal-950/60 border border-teal-800 text-teal-400 text-[10px] font-mono uppercase font-bold tracking-widest mb-2">
          Step 04 / 04 • AI Synthesized Clinical Summary
        </div>
        <h1 className="text-2xl md:text-3xl font-bold font-serif text-slate-100">
          {t.summaryTitle}
        </h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Review your structured clinical history, SOCRATES pain analysis, and digitized OCR prescriptions before seeing the doctor.
        </p>
      </div>

      {/* Main Confirmation Card */}
      <div className="bg-slate-900/90 border border-slate-800 p-6 md:p-8 rounded-2xl shadow-xl space-y-6 backdrop-blur-md text-slate-100">
        
        {/* Top Header: Completeness & Patient Card */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400 font-bold font-serif text-lg">
              {patient.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-100 text-base">{patient.name}</span>
                <span className="text-xs text-slate-400 font-mono">({patient.age}y / {patient.gender})</span>
                <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase tracking-wider border ${
                  patient.medicationStream === 'ayush'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : patient.medicationStream === 'both'
                    ? 'bg-sky-500/20 text-sky-300 border-sky-500/30'
                    : 'bg-teal-500/20 text-teal-300 border-teal-500/30'
                }`}>
                  {patient.medicationStream === 'ayush' 
                    ? 'AYUSH Regimen' 
                    : patient.medicationStream === 'both' 
                    ? 'Integrative (Dual)' 
                    : 'Allopathic Meds'}
                </span>
              </div>
              <div className="text-xs text-teal-400 font-mono mt-0.5">
                ABHA: {patient.abhaId}
              </div>
            </div>
          </div>

          {/* Completeness Badge */}
          <div className="flex items-center gap-2.5 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">History Completeness</span>
              <span className="text-sm font-bold text-emerald-400 font-mono">{completeness.score}% Completed</span>
            </div>
            <div className="w-10 h-10 rounded-full border-2 border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-xs bg-emerald-950/40">
              {completeness.score}%
            </div>
          </div>
        </div>

        {/* Real AI Synthesized Clinical Summary */}
        <div className="p-5 bg-slate-950/90 border border-slate-800 rounded-xl relative">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400">
              <Sparkles className="w-4 h-4 text-teal-400 animate-spin" />
              <span>{isAyush ? 'AYUSH Ayurvedic Clinical Synthesis' : 'Comprehensive Physician Intake Summary'}</span>
            </div>
            <button
              onClick={handleReadSummaryAloud}
              className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-teal-300 font-semibold bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-lg border border-slate-700 transition-all"
            >
              <Volume2 className="w-3.5 h-3.5 text-teal-400" />
              <span>Listen</span>
            </button>
          </div>

          {isLoadingSummary ? (
            <div className="py-6 flex flex-col items-center justify-center gap-2 text-teal-400">
              <Loader2 className="w-6 h-6 animate-spin" />
              <span className="text-xs font-medium">Synthesizing multi-modal conversation and OCR records...</span>
            </div>
          ) : (
            <p className="text-xs md:text-sm font-mono text-slate-200 leading-relaxed whitespace-pre-wrap">
              {aiSummary}
            </p>
          )}
        </div>

        {/* Clinical History Highlights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          
          {/* Card 1: Symptoms & Chief Complaint */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 font-bold text-slate-300 uppercase tracking-wider text-[11px] mb-2">
              <Activity className="w-3.5 h-3.5 text-teal-400" />
              <span>Symptoms & Present Illness</span>
            </div>
            <p className="text-slate-300 text-xs mb-2">
              {patient.chiefComplaintDetails || "No chief complaint recorded."}
            </p>
            <div className="flex flex-wrap gap-1.5">
              {patient.symptoms?.map((s, idx) => (
                <span key={idx} className="px-2 py-0.5 rounded bg-teal-950 border border-teal-800 text-teal-300 text-[11px] font-semibold">
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Card 2: Medications & Allergies */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 font-bold text-slate-300 uppercase tracking-wider text-[11px] mb-2">
              <Pill className="w-3.5 h-3.5 text-amber-400" />
              <span>Medications & Documented Allergies</span>
            </div>
            <div className="text-slate-300 text-xs mb-1.5">
              <span className="font-semibold text-slate-400">Allergies: </span>
              {patient.allergyHistoryDetails || (patient.allergies?.map(a => a.name).join(', ') || "No known drug allergies (NKDA)")}
            </div>
            <div className="text-slate-300 text-xs">
              <span className="font-semibold text-slate-400">Regular Meds: </span>
              {patient.medicationHistoryDetails || "Documented via scanner"}
            </div>
          </div>

          {/* Card 3: Past Medical & Surgical */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 font-bold text-slate-300 uppercase tracking-wider text-[11px] mb-2">
              <Stethoscope className="w-3.5 h-3.5 text-indigo-400" />
              <span>Past Medical & Surgical History</span>
            </div>
            <div className="text-slate-300 text-xs mb-1">
              <span className="font-semibold text-slate-400">Medical: </span>
              {patient.pastHistoryDetails || "None reported"}
            </div>
            <div className="text-slate-300 text-xs">
              <span className="font-semibold text-slate-400">Surgical: </span>
              {patient.pastSurgicalDetails || "None reported"}
            </div>
          </div>

          {/* Card 4: Digitized Documents OCR */}
          <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-2 font-bold text-slate-300 uppercase tracking-wider text-[11px] mb-2">
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              <span>Digitized OCR Documents ({patient.documents?.length || 0})</span>
            </div>
            <div className="space-y-1">
              {patient.documents && patient.documents.length > 0 ? (
                patient.documents.map(d => (
                  <div key={d.id} className="text-xs text-slate-300 flex items-center justify-between">
                    <span className="truncate">{d.name}</span>
                    <span className="text-[10px] text-emerald-400 font-mono">{d.ocrConfidence || 94}% OCR</span>
                  </div>
                ))
              ) : (
                <span className="text-slate-500 italic text-xs">No paper records scanned</span>
              )}
            </div>
          </div>

        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-800">
          <button
            id="btn-summary-edit-voice"
            onClick={() => {
              audioService.playBeep('click');
              onEditByVoice();
            }}
            className="flex-1 h-12 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
          >
            <Edit3 className="w-4 h-4 text-teal-400" />
            <span>{t.editByVoice}</span>
          </button>

          <button
            id="btn-summary-confirm"
            onClick={() => {
              audioService.playBeep('success');
              onConfirmAndProceed();
            }}
            className="flex-1 h-12 bg-teal-600 hover:bg-teal-500 text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
          >
            <span>{t.confirmAndProceed}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Security & DPDP Compliance Footer */}
      <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>
            <strong className="text-slate-200">DPDP Act 2023 & ABDM Level-3 Secured:</strong> Patient records cryptographically sealed with hardware AES-256-GCM and ready for instant EHR handover. Linked to ABHA ID <span className="font-mono font-bold text-teal-300">{patient.abhaId}</span>.
          </span>
        </div>
      </div>
    </div>
  );
};
