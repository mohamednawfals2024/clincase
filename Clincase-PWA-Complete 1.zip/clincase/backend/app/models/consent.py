from sqlalchemy import Column, String, Integer, DateTime, JSON, Boolean, ForeignKey
from datetime import datetime
from app.database import Base

class ConsentRecordModel(Base):
    __tablename__ = "consent_records"

    consent_id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    purpose_code = Column(String, nullable=False)  # e.g., CA_OPD_CLINICAL_INTAKE
    granted_at = Column(String, nullable=False)
    valid_until = Column(String, nullable=False)
    status = Column(String, default="ACTIVE_GRANTED")  # ACTIVE_GRANTED, REVOKED_ERASED
    digital_signature = Column(String, nullable=False)  # SHA-256 Signature
    data_minimization_scope = Column(JSON, default=list)
    consent_manager_id = Column(String, default="abdm.consent.gov.in")
    created_at = Column(DateTime, default=datetime.utcnow)

class SecurityAuditBlockModel(Base):
    __tablename__ = "security_audit_trail"

    index = Column(Integer, primary_key=True, index=True)
    timestamp = Column(String, nullable=False)
    action = Column(String, nullable=False)
    actor = Column(String, nullable=False)
    kiosk_id = Column(String, nullable=False)
    data_fingerprint = Column(String, nullable=False)
    previous_hash = Column(String, nullable=False)
    hash = Column(String, nullable=False)
    verified = Column(Boolean, default=True)
    metadata_json = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
