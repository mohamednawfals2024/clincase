from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class StructuredOcrPayload:
    document_id: str
    file_name: str
    document_type: str
    raw_document_url: str
    ocr_confidence: float
    is_handwritten: bool
    ocr_provider: str
    extracted_medications: List[Dict[str, Any]] = field(default_factory=list)
    extracted_diagnoses: List[str] = field(default_factory=list)
    extracted_investigations: List[Dict[str, Any]] = field(default_factory=list)
    extracted_dates: List[str] = field(default_factory=list)
    raw_text_summary: str = ""

class OCRProvider(ABC):
    @abstractmethod
    async def extract(
        self, 
        file_bytes: bytes, 
        filename: str, 
        content_type: str, 
        doc_id: str, 
        raw_url: str
    ) -> StructuredOcrPayload:
        """Abstract method to process medical file bytes into structured OCR entities"""
        pass
