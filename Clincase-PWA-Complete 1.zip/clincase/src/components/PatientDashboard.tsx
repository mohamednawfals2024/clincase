import React, { useState } from 'react';
import { 
  User, 
  Calendar, 
  Clock, 
  MapPin, 
  FileText, 
  Pill, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronRight, 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  ShieldCheck, 
  Stethoscope, 
  Leaf, 
  Layers, 
  HeartPulse, 
  Sparkles, 
  Phone, 
  Share2, 
  ArrowRight, 
  FileCheck, 
  X, 
  ExternalLink,
  Info,
  CalendarCheck,
  Building2,
  Lock,
  ChevronDown
} from 'lucide-react';
import { 
  PatientSession, 
  PatientAppointment, 
  PatientVisitRecord, 
  Prescription, 
  Allergy, 
  LabResult,
  LanguageCode
} from '../types';
import { audioService } from '../services/api';
import { maskName, maskPhone, maskAbha } from '../services/privacyService';
import { ConsentManagerModal } from './ConsentManagerModal';

interface PatientDashboardProps {
  patient: PatientSession;
  lang: LanguageCode;
  onStartNewIntake: () => void;
  onOpenFhirModal: () => void;
  onOpenSecurityModal: () => void;
}

export const PatientDashboard: React.FC<PatientDashboardProps> = ({
  patient,
  lang,
  onStartNewIntake,
  onOpenFhirModal,
  onOpenSecurityModal
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'appointments' | 'visits' | 'history' | 'prescriptions'>('overview');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedVisit, setSelectedVisit] = useState<PatientVisitRecord | null>(null);
  const [selectedAppointment, setSelectedAppointment] = useState<PatientAppointment | null>(null);
  const [isBookModalOpen, setIsBookModalOpen] = useState<boolean>(false);
  
  // New Appointment Form State
  const [newAptDoctor, setNewAptDoctor] = useState<string>('Dr. Arvind Varma, MD (General Medicine)');
  const [newAptDept, setNewAptDept] = useState<string>('General Medicine OPD');
  const [newAptDate, setNewAptDate] = useState<string>('2024-03-15');
  const [newAptTime, setNewAptTime] = useState<string>('11:00 AM');
  const [newAptType, setNewAptType] = useState<PatientAppointment['type']>('In-Person OPD');
  const [newAptNotes, setNewAptNotes] = useState<string>('');
  const [appointmentList, setAppointmentList] = useState<PatientAppointment[]>(patient.appointments || []);

  const handleBookAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    audioService.playBeep('click');
    const newApt: PatientAppointment = {
      id: `apt-${Date.now()}`,
      doctorName: newAptDoctor,
      department: newAptDept,
      specialty: newAptDept.includes('AYUSH') ? 'Ayurvedic Medicine' : 'Internal Medicine',
      date: `${newAptDate} (${newAptTime})`,
      time: `${newAptTime} - 30 mins`,
      type: newAptType,
      status: 'Confirmed',
      tokenNumber: `OPD-N-${Math.floor(10 + Math.random() * 90)}`,
      roomNumber: newAptDept.includes('AYUSH') ? 'AYUSH Wing, Room 04' : 'Main OPD, Room 108',
      notes: newAptNotes || 'Patient self-scheduled via Patient Portal.',
      instructions: 'Please arrive 15 minutes prior with your ABHA ID card.'
    };
    setAppointmentList([newApt, ...appointmentList]);
    setIsBookModalOpen(false);
    setNewAptNotes('');
  };

  const [isPiiMasked, setIsPiiMasked] = useState<boolean>(true);
  const [isConsentManagerOpen, setIsConsentManagerOpen] = useState<boolean>(false);

  const displayName = patient.name;
  const displayAbha = patient.abhaId || "91-4528-9021-0044";
  const displayPhone = `+91 ${patient.phone}`;

  const pastVisitsList = patient.pastVisits || [];
  const activePrescriptions = patient.prescriptions || [];

  // Filtered visits
  const filteredVisits = pastVisitsList.filter(v => 
    v.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.chiefComplaint.toLowerCase().includes(searchTerm.toLowerCase()) ||
    v.diagnosis.some(d => d.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 animate-fadeIn pb-12">
      
      {/* Patient Profile & Overview Hero Card */}
      <div 
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-color)',
          color: 'var(--text-main)'
        }}
        className="p-6 md:p-8 rounded-3xl border shadow-xl relative overflow-hidden transition-colors duration-300"
      >
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          {/* Left Avatar & Identity */}
          <div className="flex items-start sm:items-center gap-5">
            <div className="w-20 h-20 rounded-2xl bg-teal-500/15 border border-teal-500/30 text-teal-400 flex items-center justify-center font-bold text-2xl shadow-inner shrink-0">
              <User className="w-10 h-10" />
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-2xl md:text-3xl font-extrabold font-serif" style={{ color: 'var(--text-main)' }}>
                  {displayName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold font-mono bg-slate-800 text-slate-300 border border-slate-700">
                  {patient.age} Yrs • {patient.gender}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  ABDM Verified
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-y-1 gap-x-4 mt-2 text-xs opacity-80" style={{ color: 'var(--text-muted)' }}>
                <span className="font-mono">
                  <strong className="text-teal-400">ABHA:</strong> {displayAbha}
                </span>
                <span>•</span>
                <span>
                  <strong>Phone:</strong> {displayPhone}
                </span>
                <span>•</span>
                <span>
                  <strong>DOB:</strong> {patient.dob}
                </span>
              </div>

              {/* Medication Stream Badges */}
              <div className="flex flex-wrap items-center gap-2 mt-3">
                <span className={`text-[11px] px-3 py-1 rounded-lg font-bold border flex items-center gap-1.5 shadow-xs ${
                  patient.medicationStream === 'ayush'
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : patient.medicationStream === 'both'
                    ? 'bg-sky-500/15 text-sky-300 border-sky-500/30'
                    : 'bg-teal-500/15 text-teal-300 border-teal-500/30'
                }`}>
                  {patient.medicationStream === 'ayush' ? (
                    <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                  ) : patient.medicationStream === 'both' ? (
                    <Layers className="w-3.5 h-3.5 text-sky-400" />
                  ) : (
                    <Pill className="w-3.5 h-3.5 text-teal-400" />
                  )}
                  <span>
                    Current Stream: {patient.medicationStream === 'ayush' ? 'AYUSH Herbal Regimen' : patient.medicationStream === 'both' ? 'Integrative (Allopathic + AYUSH)' : 'Allopathic Prescription Care'}
                  </span>
                </span>

                <span className="text-[11px] px-3 py-1 rounded-lg font-medium border bg-white/5 border-white/10 opacity-80 flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-teal-400" />
                  <span>Vitals: BP 124/82 mmHg • SpO2 98%</span>
                </span>
              </div>
            </div>
          </div>

          {/* Right Action Center */}
          <div className="flex flex-wrap items-center gap-3 shrink-0 w-full lg:w-auto">
            <button
              onClick={() => {
                audioService.playBeep('click');
                setIsBookModalOpen(true);
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>

            <button
              onClick={() => {
                audioService.playBeep('click');
                onStartNewIntake();
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-teal-500/40 hover:border-teal-400 text-teal-400 hover:bg-teal-500/10 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Stethoscope className="w-4 h-4" />
              <span>New OPD Intake</span>
            </button>

            <button
              onClick={() => {
                audioService.playBeep('click');
                onOpenFhirModal();
              }}
              className="p-2.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              title="Download FHIR R4 Health Record"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4 mt-6 pt-6 border-t" style={{ borderColor: 'var(--border-color)' }}>
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col justify-between">
            <span className="text-[11px] opacity-70 font-semibold" style={{ color: 'var(--text-muted)' }}>Upcoming Consultations</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold font-mono text-teal-400">{appointmentList.length}</span>
              <span className="text-[10px] text-teal-400 font-semibold">Active</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col justify-between">
            <span className="text-[11px] opacity-70 font-semibold" style={{ color: 'var(--text-muted)' }}>Past Clinical Visits</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold font-mono" style={{ color: 'var(--text-main)' }}>{pastVisitsList.length}</span>
              <span className="text-[10px] opacity-60">Recorded</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col justify-between">
            <span className="text-[11px] opacity-70 font-semibold" style={{ color: 'var(--text-muted)' }}>Active Prescriptions</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold font-mono text-emerald-400">{activePrescriptions.length}</span>
              <span className="text-[10px] text-emerald-400 font-semibold">Verified</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex flex-col justify-between">
            <span className="text-[11px] opacity-70 font-semibold" style={{ color: 'var(--text-muted)' }}>Known Allergies</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold font-mono text-rose-400">{patient.allergies?.length || 2}</span>
              <span className="text-[10px] text-rose-400 font-semibold">High Alert</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-1" style={{ borderColor: 'var(--border-color)' }}>
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'overview', label: 'Dashboard Overview', icon: Activity },
            { id: 'appointments', label: `Upcoming Appointments (${appointmentList.length})`, icon: Calendar },
            { id: 'visits', label: `Recent Visits & History (${pastVisitsList.length})`, icon: Clock },
            { id: 'history', label: 'Medical Profile & Vitals', icon: Stethoscope },
            { id: 'prescriptions', label: `Prescriptions & Meds (${activePrescriptions.length})`, icon: Pill },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  audioService.playBeep('click');
                  setActiveTab(tab.id as any);
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border cursor-pointer ${
                  isActive
                    ? 'bg-teal-600 text-white border-teal-500 shadow-md'
                    : 'bg-white/5 border-transparent opacity-75 hover:opacity-100 hover:bg-white/10'
                }`}
                style={{
                  color: isActive ? '#FFFFFF' : 'var(--text-main)'
                }}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Global Search Filter in Patient Dashboard */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3.5 top-3 opacity-40" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search visits, doctors, meds..."
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-color)',
              color: 'var(--text-main)'
            }}
            className="w-full h-10 pl-9 pr-4 rounded-xl border text-xs outline-none focus:border-teal-500"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-2.5 opacity-50 hover:opacity-100 text-xs"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* TAB CONTENT 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Column 1: Next Imminent Appointment & Active Prescriptions */}
          <div className="space-y-6">
            
            {/* Imminent Appointment Card */}
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-5 rounded-2xl border shadow-md space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400">
                  <CalendarCheck className="w-4 h-4" />
                  <span>Next Scheduled Visit</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-teal-500/10 text-teal-300 border border-teal-500/20">
                  {appointmentList[0]?.status || 'Scheduled'}
                </span>
              </div>

              {appointmentList.length > 0 ? (
                <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-sm font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                        {appointmentList[0].doctorName}
                      </h3>
                      <p className="text-xs text-teal-400 font-medium">{appointmentList[0].department}</p>
                    </div>
                    <span className="text-xs font-mono font-bold bg-teal-500/20 text-teal-300 px-2.5 py-1 rounded-lg border border-teal-500/30">
                      {appointmentList[0].tokenNumber}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs opacity-80" style={{ color: 'var(--text-muted)' }}>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-teal-400" />
                      <span>{appointmentList[0].date} ({appointmentList[0].time})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-teal-400" />
                      <span>{appointmentList[0].roomNumber}</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                    <button
                      onClick={() => setSelectedAppointment(appointmentList[0])}
                      className="text-teal-400 hover:underline font-semibold flex items-center gap-1"
                    >
                      <span>View Preparation Guide</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <p className="text-xs opacity-70">No upcoming appointments scheduled.</p>
              )}

              <button
                onClick={() => {
                  audioService.playBeep('click');
                  setIsBookModalOpen(true);
                }}
                className="w-full py-2.5 rounded-xl border border-teal-500/30 hover:border-teal-400 text-teal-400 hover:bg-teal-500/10 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule New Visit</span>
              </button>
            </div>

            {/* Current Active Medications Card */}
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-5 rounded-2xl border shadow-md space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
                  <Pill className="w-4 h-4" />
                  <span>Current Active Medications</span>
                </div>
                <button
                  onClick={() => setActiveTab('prescriptions')}
                  className="text-[11px] text-teal-400 hover:underline font-semibold"
                >
                  View All ({activePrescriptions.length})
                </button>
              </div>

              <div className="space-y-2.5">
                {activePrescriptions.slice(0, 3).map((rx) => (
                  <div key={rx.id} className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold" style={{ color: 'var(--text-main)' }}>
                        {rx.medicine}
                      </div>
                      <div className="text-[11px] opacity-75 mt-0.5" style={{ color: 'var(--text-muted)' }}>
                        {rx.dosage} • {rx.frequency} ({rx.duration})
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                      Active
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Column 2: Recent Visit & Clinical Summary */}
          <div className="space-y-6">
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-5 rounded-2xl border shadow-md space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400">
                  <Clock className="w-4 h-4" />
                  <span>Most Recent Clinical Visit</span>
                </div>
                <span className="text-[11px] opacity-70 font-mono" style={{ color: 'var(--text-muted)' }}>
                  {pastVisitsList[0]?.date || 'Today'}
                </span>
              </div>

              {pastVisitsList.length > 0 && (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2.5">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="text-sm font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                          {pastVisitsList[0].doctorName}
                        </h4>
                        <p className="text-xs opacity-75">{pastVisitsList[0].department} • {pastVisitsList[0].hospitalOrClinic}</p>
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                        pastVisitsList[0].treatmentType === 'AYUSH'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-teal-500/15 text-teal-400 border border-teal-500/30'
                      }`}>
                        {pastVisitsList[0].treatmentType}
                      </span>
                    </div>

                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider opacity-60">Chief Complaint:</span>
                      <p className="text-xs mt-0.5 opacity-90 leading-relaxed">{pastVisitsList[0].chiefComplaint}</p>
                    </div>

                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider opacity-60">Diagnoses:</span>
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {pastVisitsList[0].diagnosis.map((d, i) => (
                          <span key={i} className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700">
                            {d}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-white/5">
                      <p className="text-xs opacity-80 italic line-clamp-2 leading-relaxed">
                        "{pastVisitsList[0].clinicalSummary}"
                      </p>
                    </div>

                    <div className="pt-2 flex items-center justify-between text-xs">
                      <button
                        onClick={() => setSelectedVisit(pastVisitsList[0])}
                        className="text-teal-400 hover:underline font-semibold flex items-center gap-1"
                      >
                        <span>Full Visit Summary & Rx</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <button
                onClick={() => setActiveTab('visits')}
                className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
                style={{ color: 'var(--text-main)' }}
              >
                <span>View Full Consultation History ({pastVisitsList.length})</span>
                <ArrowRight className="w-3.5 h-3.5 text-teal-400" />
              </button>
            </div>

            {/* Emergency & Red Flag Safeguards */}
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-5 rounded-2xl border shadow-md space-y-3"
            >
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-400">
                <AlertTriangle className="w-4 h-4" />
                <span>Documented Drug Allergies</span>
              </div>
              <div className="space-y-2">
                {patient.allergies?.map((all, i) => (
                  <div key={i} className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs flex items-center justify-between">
                    <div>
                      <span className="font-bold text-rose-300">{all.name}</span>
                      <p className="text-[11px] text-rose-200/80 mt-0.5">{all.reaction}</p>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-600 text-white">
                      {all.severity || 'Severe'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Column 3: Medical History Highlights & AYUSH / Vitals Profile */}
          <div className="space-y-6">
            
            {/* Medical History Summary Card */}
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-5 rounded-2xl border shadow-md space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-400">
                  <FileText className="w-4 h-4" />
                  <span>Chronic History & Baseline</span>
                </div>
                <button
                  onClick={() => setActiveTab('history')}
                  className="text-[11px] text-teal-400 hover:underline font-semibold"
                >
                  Full Profile
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Past Medical Conditions:</span>
                  <p className="opacity-90 leading-relaxed">{patient.pastHistoryDetails || "Type-2 Diabetes Mellitus (3 years), Essential Hypertension"}</p>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Family Medical History:</span>
                  <p className="opacity-90 leading-relaxed">{patient.familyHistoryDetails || "Father: Myocardial Infarction at 58. Mother: Hypertension."}</p>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Diet & Lifestyle:</span>
                  <p className="opacity-90 leading-relaxed">{patient.lifestyleDetails || "Vegetarian, non-smoker, IT professional, 30m daily brisk walking."}</p>
                </div>
              </div>
            </div>

            {/* Ayurvedic Prakriti Card (if AYUSH details available) */}
            {patient.ayushDetails && (
              <div 
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-main)'
                }}
                className="p-5 rounded-2xl border shadow-md space-y-3 relative overflow-hidden"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
                    <Leaf className="w-4 h-4" />
                    <span>AYUSH Dashavidha Pariksha</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                    Prakriti Mapped
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/15 space-y-2 text-xs">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Deha Prakriti (Constitutional Type):</span>
                    <p className="font-semibold text-emerald-200 mt-0.5">{patient.ayushDetails.Prakriti}</p>
                  </div>

                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Current Vikriti (Dosha Imbalance):</span>
                    <p className="opacity-90 mt-0.5">{patient.ayushDetails.Vikriti}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Quick ABDM Privacy & Security Card */}
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-4 rounded-2xl border shadow-xs flex items-center justify-between gap-3 text-xs"
            >
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-teal-400 shrink-0" />
                <div>
                  <div className="font-bold" style={{ color: 'var(--text-main)' }}>ABHA Consent Manager Active</div>
                  <p className="text-[11px] opacity-70" style={{ color: 'var(--text-muted)' }}>DPDP Act 2023 • AES-256 encrypted</p>
                </div>
              </div>
              <button
                onClick={() => {
                  audioService.playBeep('click');
                  onOpenSecurityModal();
                }}
                className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 font-bold text-[10px] uppercase tracking-wider"
              >
                Security Audit
              </button>
            </div>

          </div>

        </div>
      )}

      {/* TAB CONTENT 2: UPCOMING APPOINTMENTS */}
      {activeTab === 'appointments' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                Upcoming Consultations & Clinic Visits
              </h2>
              <p className="text-xs opacity-75 mt-0.5" style={{ color: 'var(--text-muted)' }}>
                View your confirmed doctor slots, room allocations, token numbers, and clinical preparation instructions.
              </p>
            </div>

            <button
              onClick={() => {
                audioService.playBeep('click');
                setIsBookModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Book New Appointment</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {appointmentList.map((apt) => (
              <div
                key={apt.id}
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-main)'
                }}
                className="p-6 rounded-2xl border shadow-md flex flex-col justify-between space-y-4 hover:border-teal-500/50 transition-all group"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${
                      apt.type === 'AYUSH Evaluation'
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                        : 'bg-teal-500/15 text-teal-300 border-teal-500/30'
                    }`}>
                      {apt.type}
                    </span>
                    <span className="text-xs font-mono font-bold bg-white/10 px-2.5 py-1 rounded-lg">
                      Token: {apt.tokenNumber}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold font-serif group-hover:text-teal-400 transition-colors" style={{ color: 'var(--text-main)' }}>
                      {apt.doctorName}
                    </h3>
                    <p className="text-xs text-teal-400 font-medium mt-0.5">{apt.department}</p>
                    <p className="text-[11px] opacity-70 mt-0.5">{apt.specialty}</p>
                  </div>

                  <div className="space-y-1.5 text-xs opacity-80 pt-2 border-t" style={{ borderColor: 'var(--border-color)', color: 'var(--text-muted)' }}>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span>{apt.date} • {apt.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span>{apt.roomNumber}</span>
                    </div>
                  </div>

                  {apt.notes && (
                    <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-xs">
                      <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Consultation Note:</span>
                      <p className="opacity-90 mt-0.5 line-clamp-2">{apt.notes}</p>
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t flex items-center justify-between gap-2" style={{ borderColor: 'var(--border-color)' }}>
                  <button
                    onClick={() => setSelectedAppointment(apt)}
                    className="text-xs text-teal-400 hover:underline font-bold flex items-center gap-1"
                  >
                    <span>View Details</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      audioService.playBeep('click');
                      alert(`Appointment ${apt.tokenNumber} details shared to your registered mobile (+91 ${patient.phone}) and downloaded to your calendar.`);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] font-bold transition-colors flex items-center gap-1"
                  >
                    <Share2 className="w-3 h-3" />
                    <span>Sync</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: RECENT VISITS & HISTORY */}
      {activeTab === 'visits' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                Consultation Records & Clinical Visit Timeline
              </h2>
              <p className="text-xs opacity-75 mt-0.5" style={{ color: 'var(--text-muted)' }}>
                Chronological record of doctor consultations, diagnoses, vital stats, and prescribed treatment plans.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {filteredVisits.length > 0 ? (
              filteredVisits.map((visit) => (
                <div
                  key={visit.id}
                  style={{
                    backgroundColor: 'var(--bg-card)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-main)'
                  }}
                  className="p-6 rounded-2xl border shadow-md space-y-4 hover:border-teal-500/40 transition-all cursor-pointer"
                  onClick={() => setSelectedVisit(visit)}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                        visit.treatmentType === 'AYUSH'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-teal-500/20 text-teal-400 border border-teal-500/30'
                      }`}>
                        {visit.treatmentType === 'AYUSH' ? <Leaf className="w-5 h-5" /> : <Stethoscope className="w-5 h-5" />}
                      </div>
                      <div>
                        <h3 className="text-base font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                          {visit.doctorName}
                        </h3>
                        <p className="text-xs text-teal-400 font-medium">{visit.department} • {visit.hospitalOrClinic}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                        visit.treatmentType === 'AYUSH'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                          : 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                      }`}>
                        {visit.treatmentType}
                      </span>
                      <span className="text-xs font-mono opacity-80">{visit.date}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Chief Complaint & Vitals:</span>
                      <p className="font-medium mt-0.5 opacity-90">{visit.chiefComplaint}</p>
                      <p className="text-[11px] opacity-75 font-mono mt-1 text-teal-300">{visit.vitalsSummary}</p>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Diagnoses & Clinical Notes:</span>
                      <div className="flex flex-wrap gap-1.5 my-1">
                        {visit.diagnosis.map((d, i) => (
                          <span key={i} className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700">
                            {d}
                          </span>
                        ))}
                      </div>
                      <p className="text-[11px] opacity-80 line-clamp-2 italic">"{visit.clinicalSummary}"</p>
                    </div>
                  </div>

                  <div className="pt-3 border-t flex items-center justify-between text-xs" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                      <Pill className="w-3.5 h-3.5" />
                      <span>{visit.prescriptions.length} Prescriptions issued</span>
                    </div>

                    <span className="text-teal-400 font-bold flex items-center gap-1">
                      <span>Inspect Details</span>
                      <ChevronRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-12 text-center rounded-2xl border" style={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-color)' }}>
                <p className="text-xs opacity-75">No clinical records found matching "{searchTerm}".</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: MEDICAL PROFILE & VITALS */}
      {activeTab === 'history' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Card: Chronic Medical History */}
          <div 
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-color)',
              color: 'var(--text-main)'
            }}
            className="p-6 rounded-2xl border shadow-md space-y-4"
          >
            <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-teal-400">
              <Activity className="w-4 h-4" />
              <span>Comprehensive Health Profile</span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">History of Present & Past Illness:</span>
                <p className="opacity-90 leading-relaxed">{patient.pastHistoryDetails}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Chief Complaint SOCRATES Narrative:</span>
                <p className="opacity-90 leading-relaxed">{patient.hpiDetails || patient.chiefComplaintDetails}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Family Medical Background:</span>
                <p className="opacity-90 leading-relaxed">{patient.familyHistoryDetails}</p>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Social & Lifestyle Habitus:</span>
                <p className="opacity-90 leading-relaxed">{patient.lifestyleDetails}</p>
              </div>
            </div>
          </div>

          {/* Card: Vitals Baseline & Lab Diagnostics */}
          <div className="space-y-6">
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-6 rounded-2xl border shadow-md space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-teal-400">
                  <HeartPulse className="w-4 h-4" />
                  <span>Clinical Vitals & Physiological Parameters</span>
                </div>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/20">
                  Normal Range
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-[10px] opacity-60 font-bold uppercase">Blood Pressure</span>
                  <div className="text-lg font-bold font-mono text-teal-300 mt-0.5">{patient.vitals?.bp || "124/82"}</div>
                  <span className="text-[9px] opacity-60">mmHg</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-[10px] opacity-60 font-bold uppercase">Heart Rate</span>
                  <div className="text-lg font-bold font-mono text-teal-300 mt-0.5">{patient.vitals?.hr || "78"}</div>
                  <span className="text-[9px] opacity-60">bpm (Regular)</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-[10px] opacity-60 font-bold uppercase">Oxygen Saturation</span>
                  <div className="text-lg font-bold font-mono text-emerald-300 mt-0.5">{patient.vitals?.spo2 || "98%"}</div>
                  <span className="text-[9px] opacity-60">SpO2 on Room Air</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-[10px] opacity-60 font-bold uppercase">Temperature</span>
                  <div className="text-lg font-bold font-mono text-amber-300 mt-0.5">{patient.vitals?.temp || "99.4 °F"}</div>
                  <span className="text-[9px] opacity-60">Mild Low Grade</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-[10px] opacity-60 font-bold uppercase">Respiratory Rate</span>
                  <div className="text-lg font-bold font-mono text-teal-300 mt-0.5">{patient.vitals?.respRate || "16"}</div>
                  <span className="text-[9px] opacity-60">breaths/min</span>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                  <span className="text-[10px] opacity-60 font-bold uppercase">Blood Glucose</span>
                  <div className="text-lg font-bold font-mono text-teal-300 mt-0.5">138</div>
                  <span className="text-[9px] opacity-60">mg/dL (Random)</span>
                </div>
              </div>
            </div>

            {/* Lab Test Results */}
            <div 
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-color)',
                color: 'var(--text-main)'
              }}
              className="p-6 rounded-2xl border shadow-md space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-teal-400">
                  <FileCheck className="w-4 h-4" />
                  <span>Recent Laboratory Diagnostics</span>
                </div>
                <span className="text-xs opacity-75">Hematology & Biochemistry</span>
              </div>

              <div className="space-y-2">
                {patient.labResults?.map((lab, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold" style={{ color: 'var(--text-main)' }}>{lab.test}</div>
                      <div className="text-[10px] opacity-60 mt-0.5">Ref: {lab.refRange}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold">{lab.result}</div>
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        lab.status === 'High' ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'
                      }`}>
                        {lab.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>
      )}

      {/* TAB CONTENT 5: PRESCRIPTIONS */}
      {activeTab === 'prescriptions' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                Prescribed Medications & Pharmacy Schedule
              </h2>
              <p className="text-xs opacity-75 mt-0.5" style={{ color: 'var(--text-muted)' }}>
                Authorized digital prescriptions generated across OPD consultations and verified against allergy databases.
              </p>
            </div>

            <button
              onClick={() => {
                audioService.playBeep('click');
                window.print();
              }}
              className="px-4 py-2.5 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Prescription Sheet</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {activePrescriptions.map((rx) => (
              <div
                key={rx.id}
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-color)',
                  color: 'var(--text-main)'
                }}
                className="p-6 rounded-2xl border shadow-md flex flex-col justify-between space-y-4 hover:border-emerald-500/40 transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
                      <Pill className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20">
                      Active Regimen
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                      {rx.medicine}
                    </h3>
                    <p className="text-xs text-teal-400 font-mono font-bold mt-0.5">{rx.dosage}</p>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="opacity-60">Frequency:</span>
                      <span className="font-semibold">{rx.frequency}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="opacity-60">Duration:</span>
                      <span className="font-semibold">{rx.duration}</span>
                    </div>
                    <div className="pt-1 border-t border-white/5">
                      <span className="text-[10px] opacity-60 font-bold uppercase">Instructions:</span>
                      <p className="opacity-90 mt-0.5 text-[11px] leading-relaxed">{rx.instructions}</p>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t flex items-center justify-between text-xs" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="text-[10px] opacity-60 font-mono">Rx ID: {rx.id}</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    No Interactions
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL 1: BOOK APPOINTMENT MODAL */}
      {isBookModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fadeIn">
          <div 
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-color)',
              color: 'var(--text-main)'
            }}
            className="w-full max-w-lg rounded-3xl border shadow-2xl p-6 md:p-8 space-y-6 relative"
          >
            <button
              onClick={() => setIsBookModalOpen(false)}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold uppercase tracking-wider border border-teal-500/20">
                <Calendar className="w-3.5 h-3.5" />
                ABHA OPD Scheduling
              </div>
              <h2 className="text-2xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                Book Doctor Consultation
              </h2>
              <p className="text-xs opacity-75" style={{ color: 'var(--text-muted)' }}>
                Select a department, doctor, and preferred time slot for patient {patient.name}.
              </p>
            </div>

            <form onSubmit={handleBookAppointment} className="space-y-4">
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider opacity-70">
                  Select Department & Specialty
                </label>
                <select
                  value={newAptDept}
                  onChange={(e) => {
                    setNewAptDept(e.target.value);
                    if (e.target.value.includes('AYUSH')) {
                      setNewAptDoctor('Vaidya Rajeshwari Sharma, BAMS, MD (Ayur)');
                      setNewAptType('AYUSH Evaluation');
                    } else {
                      setNewAptDoctor('Dr. Arvind Varma, MD (General Medicine)');
                      setNewAptType('In-Person OPD');
                    }
                  }}
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-main)'
                  }}
                  className="w-full h-11 px-3 mt-1 rounded-xl border text-xs outline-none focus:border-teal-500 font-semibold"
                >
                  <option value="General Medicine OPD" className="bg-slate-900">General Medicine OPD (Allopathic)</option>
                  <option value="AYUSH Kayachikitsa & Panchakarma" className="bg-slate-900">AYUSH Kayachikitsa & Ayurveda</option>
                  <option value="Surgical Gastroenterology OPD" className="bg-slate-900">Surgical Gastroenterology OPD</option>
                  <option value="Endocrinology & Diabetes Clinic" className="bg-slate-900">Endocrinology & Diabetes Clinic</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider opacity-70">
                  Attending Consultant
                </label>
                <input
                  type="text"
                  value={newAptDoctor}
                  onChange={(e) => setNewAptDoctor(e.target.value)}
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-main)'
                  }}
                  className="w-full h-11 px-3 mt-1 rounded-xl border text-xs outline-none focus:border-teal-500 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider opacity-70">
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    value={newAptDate}
                    onChange={(e) => setNewAptDate(e.target.value)}
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      borderColor: 'var(--border-color)',
                      color: 'var(--text-main)'
                    }}
                    className="w-full h-11 px-3 mt-1 rounded-xl border text-xs outline-none focus:border-teal-500 font-semibold"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider opacity-70">
                    Time Slot
                  </label>
                  <select
                    value={newAptTime}
                    onChange={(e) => setNewAptTime(e.target.value)}
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      borderColor: 'var(--border-color)',
                      color: 'var(--text-main)'
                    }}
                    className="w-full h-11 px-3 mt-1 rounded-xl border text-xs outline-none focus:border-teal-500 font-semibold"
                  >
                    <option value="09:30 AM" className="bg-slate-900">09:30 AM - Morning</option>
                    <option value="11:00 AM" className="bg-slate-900">11:00 AM - Morning</option>
                    <option value="02:30 PM" className="bg-slate-900">02:30 PM - Afternoon</option>
                    <option value="04:00 PM" className="bg-slate-900">04:00 PM - Evening</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider opacity-70">
                  Reason for Visit / Symptoms
                </label>
                <textarea
                  value={newAptNotes}
                  onChange={(e) => setNewAptNotes(e.target.value)}
                  placeholder="E.g. Follow up for abdominal pain, lab report review, or routine check-up..."
                  rows={2}
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                    borderColor: 'var(--border-color)',
                    color: 'var(--text-main)'
                  }}
                  className="w-full p-3 mt-1 rounded-xl border text-xs outline-none focus:border-teal-500 resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsBookModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 text-xs font-semibold"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold uppercase tracking-wider shadow-md transition-all cursor-pointer"
                >
                  Confirm & Issue Token
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: VISIT DETAILS MODAL */}
      {selectedVisit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fadeIn">
          <div 
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-color)',
              color: 'var(--text-main)'
            }}
            className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border shadow-2xl p-6 md:p-8 space-y-6 relative"
          >
            <button
              onClick={() => setSelectedVisit(null)}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold uppercase tracking-wider border border-teal-500/20">
                Clinical Encounter Summary
              </div>
              <h2 className="text-2xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                {selectedVisit.doctorName}
              </h2>
              <p className="text-xs opacity-75" style={{ color: 'var(--text-muted)' }}>
                {selectedVisit.department} • {selectedVisit.hospitalOrClinic} • {selectedVisit.date}
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Chief Complaint:</span>
                <p className="font-semibold text-sm" style={{ color: 'var(--text-main)' }}>{selectedVisit.chiefComplaint}</p>
                <p className="font-mono text-teal-300 text-[11px] pt-1">{selectedVisit.vitalsSummary}</p>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Documented Diagnoses:</span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedVisit.diagnosis.map((d, i) => (
                    <span key={i} className="text-xs font-bold px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 border border-slate-700">
                      {d}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Doctor Clinical Notes & Impressions:</span>
                <p className="opacity-90 leading-relaxed text-sm">{selectedVisit.clinicalSummary}</p>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Prescriptions Issued:</span>
                <ul className="space-y-1.5 list-disc list-inside opacity-90">
                  {selectedVisit.prescriptions.map((p, i) => (
                    <li key={i} className="font-semibold">{p}</li>
                  ))}
                </ul>
              </div>

              {selectedVisit.followUpDate && (
                <div className="p-3 rounded-xl bg-teal-500/10 border border-teal-500/20 text-teal-300 flex items-center justify-between">
                  <span>Advised Follow-up Date:</span>
                  <span className="font-bold">{selectedVisit.followUpDate}</span>
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end">
              <button
                onClick={() => setSelectedVisit(null)}
                className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold uppercase tracking-wider"
              >
                Close Encounter Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: APPOINTMENT DETAILS MODAL */}
      {selectedAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-fadeIn">
          <div 
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-color)',
              color: 'var(--text-main)'
            }}
            className="w-full max-w-lg rounded-3xl border shadow-2xl p-6 md:p-8 space-y-6 relative"
          >
            <button
              onClick={() => setSelectedAppointment(null)}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-500/10 text-teal-400 text-xs font-bold uppercase tracking-wider border border-teal-500/20">
                Confirmed Appointment Slot
              </div>
              <h2 className="text-2xl font-bold font-serif" style={{ color: 'var(--text-main)' }}>
                {selectedAppointment.doctorName}
              </h2>
              <p className="text-xs opacity-75" style={{ color: 'var(--text-muted)' }}>
                {selectedAppointment.department} • {selectedAppointment.specialty}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400">Queue Token</span>
                <div className="text-xl font-bold font-mono text-teal-300 mt-0.5">{selectedAppointment.tokenNumber}</div>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-400">Clinic Room</span>
                <div className="text-sm font-semibold mt-0.5">{selectedAppointment.roomNumber}</div>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Consultation Date & Time:</span>
                <p className="font-semibold text-sm">{selectedAppointment.date} ({selectedAppointment.time})</p>
              </div>

              {selectedAppointment.instructions && (
                <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">Patient Instructions & Prep:</span>
                  <p className="opacity-90 leading-relaxed">{selectedAppointment.instructions}</p>
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedAppointment(null)}
                className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold uppercase tracking-wider"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Digital Consent & Data Privacy Modal */}
      <ConsentManagerModal
        isOpen={isConsentManagerOpen}
        onClose={() => setIsConsentManagerOpen(false)}
        patient={patient}
        onPurgeData={() => {
          setIsConsentManagerOpen(false);
          onOpenSecurityModal();
        }}
      />

    </div>
  );
};
