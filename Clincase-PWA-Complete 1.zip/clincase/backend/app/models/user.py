from sqlalchemy import Column, String, Boolean, DateTime
from datetime import datetime
from app.database import Base

class DoctorUserModel(Base):
    __tablename__ = "doctor_users"

    id = Column(String, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(String, nullable=False, default="doctor")  # doctor, admin, patient, guest
    license_number = Column(String, nullable=True)  # e.g., DOC-MD-8921
    specialty = Column(String, nullable=True)  # e.g., Internal Medicine & Gastroenterology
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
