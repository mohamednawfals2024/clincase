import hashlib
import json
import base64
from datetime import datetime, timedelta
from typing import Optional, Any, Dict
from jose import jwt, JWTError
from passlib.context import CryptContext
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

from app.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
ALGORITHM = "HS256"

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def decode_access_token(token: str) -> Optional[dict]:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None

def sha256(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()

# AES-256-GCM Zero-Trust Storage Encryption
def get_aes_gcm_key() -> bytes:
    return hashlib.scrypt(
        settings.ENCRYPTION_SECRET.encode(),
        salt=b"medikiosk_salt_2026",
        n=16384, r=8, p=1, dklen=32
    )

def encrypt_payload(plain_text: str) -> Dict[str, str]:
    key = get_aes_gcm_key()
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    cipher_text = aesgcm.encrypt(nonce, plain_text.encode("utf-8"), None)
    return {
        "cipherText": cipher_text.hex(),
        "nonce": nonce.hex()
    }

def decrypt_payload(cipher_hex: str, nonce_hex: str) -> str:
    key = get_aes_gcm_key()
    aesgcm = AESGCM(key)
    cipher_bytes = bytes.fromhex(cipher_hex)
    nonce_bytes = bytes.fromhex(nonce_hex)
    decrypted = aesgcm.decrypt(nonce_bytes, cipher_bytes, None)
    return decrypted.decode("utf-8")
