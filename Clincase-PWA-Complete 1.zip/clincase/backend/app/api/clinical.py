import random
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.patient import PatientRecordModel
from app.models.history_session import HistorySessionModel
from app.models.clinical_history import ClinicalHistoryModel
from app.schemas.clinical import (
    ConversationalRequest, 
    ConversationalResponse, 
    HistorySessionStartRequest, 
    HistorySessionAnswerRequest
)
from app.schemas.history_session import HistorySessionResponse
from app.services.ai_service import ai_service
from app.core.rbac import allow_guest

router = APIRouter(prefix="/clinical", tags=["Clinical History & Dialogue"])

@router.post(
    "/sessions/start", 
    response_model=HistorySessionResponse, 
    status_code=status.HTTP_201_CREATED,
    summary="Start Clinical History Intake Session",
    description="Initializes a new clinical history intake session for a registered patient."
)
async def start_history_session(
    payload: HistorySessionStartRequest, 
    db: AsyncSession = Depends(get_db), 
    current_user: dict = Depends(allow_guest)
):
    # Verify patient exists
    res = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == payload.patientId))
    patient = res.scalars().first()
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Patient session '{payload.patientId}' not found"
        )

    session_id = f"HS-{random.randint(10000, 99999)}"
    hs = HistorySessionModel(
        id=session_id,
        patient_id=payload.patientId,
        current_step=1,
        status="active",
        intake_started_at=datetime.utcnow()
    )

    db.add(hs)
    await db.commit()
    await db.refresh(hs)

    return HistorySessionResponse(
        id=hs.id,
        patient_id=hs.patient_id,
        current_step=hs.current_step,
        status=hs.status,
        intake_started_at=hs.intake_started_at.isoformat()
    )

@router.post(
    "/sessions/{session_id}/answers",
    summary="Record Clinical Intake History Answers",
    description="Saves patient answers for Chief Complaint, HPI, SOCRATES pain profile, ROS, or AYUSH Dashavidha."
)
async def record_history_answers(
    session_id: str,
    payload: HistorySessionAnswerRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(allow_guest)
):
    res = await db.execute(select(HistorySessionModel).where(HistorySessionModel.id == session_id))
    hs = res.scalars().first()
    if not hs:
        # Check if session_id is a Patient ID directly
        res_p = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == session_id))
        patient = res_p.scalars().first()
        if not patient:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"History Session '{session_id}' not found")
        patient_id = patient.id
    else:
        patient_id = hs.patient_id
        hs.current_step = payload.step
        await db.commit()

    # Fetch patient record to update
    res_patient = await db.execute(select(PatientRecordModel).where(PatientRecordModel.id == patient_id))
    patient = res_patient.scalars().first()
    if patient:
        if payload.symptoms:
            existing = set(patient.symptoms or [])
            existing.update(payload.symptoms)
            patient.symptoms = list(existing)
        if payload.chiefComplaint:
            patient.chief_complaint_details = payload.chiefComplaint
        if payload.hpiText:
            patient.hpi_details = payload.hpiText
        if payload.ayushDetails:
            patient.ayush_details = payload.ayushDetails.dict(exclude_none=True)
        await db.commit()

    return {
        "status": "success",
        "sessionId": session_id,
        "patientId": patient_id,
        "step": payload.step,
        "message": "Clinical history answers saved successfully."
    }

@router.post("/converse", response_model=ConversationalResponse, summary="Conversational AI Intake Dialogue")
async def converse(req: ConversationalRequest, current_user: dict = Depends(allow_guest)):
    if not req.userUtterance or not req.userUtterance.strip():
        raise HTTPException(status_code=400, detail="userUtterance is required")

    result = await ai_service.generate_clinical_dialogue(req.userUtterance, req.consultType or "allopathic")
    return ConversationalResponse(
        spokenResponse=result["spokenResponse"],
        extractedSymptoms=result["extractedSymptoms"],
        isRedFlag=result["isRedFlag"],
        redFlagReason=result.get("redFlagReason"),
        clinicalSummaryFragment=result.get("clinicalSummaryFragment"),
        nextStepGuidance=result["nextStepGuidance"]
    )
