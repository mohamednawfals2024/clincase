import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  onSnapshot, 
  serverTimestamp, 
  Firestore,
  writeBatch,
  deleteDoc
} from 'firebase/firestore';
import { PatientSession, SecurityAuditEvent } from '../types';

// ============================================================================
// FIREBASE FIRESTORE PERSISTENCE & REAL-TIME DATA SYNC ENGINE
// ============================================================================

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket: string;
  messagingSenderId: string;
  appId: string;
}

const STORAGE_KEY_FIREBASE_CONFIG = 'clincase_firebase_custom_config';

// Default configuration with fallback to environment variables or local project
const metaEnv = typeof import.meta !== 'undefined' ? (import.meta as any).env || {} : {};

export const DEFAULT_FIREBASE_CONFIG: FirebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || 'AIzaSyDemoClincaseKeyForLocalDev2026',
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || 'clincase-clinical-ai.firebaseapp.com',
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || 'clincase-clinical-ai',
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || 'clincase-clinical-ai.appspot.com',
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || '104829104829',
  appId: metaEnv.VITE_FIREBASE_APP_ID || '1:104829104829:web:a91b2c3d4e5f6a7b8c9d0e'
};

export function getActiveFirebaseConfig(): FirebaseConfig {
  try {
    if (typeof localStorage !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY_FIREBASE_CONFIG);
      if (saved) {
        return { ...DEFAULT_FIREBASE_CONFIG, ...JSON.parse(saved) };
      }
    }
  } catch (e) {
    console.warn('[Firebase] Failed to load custom config from localStorage:', e);
  }
  return DEFAULT_FIREBASE_CONFIG;
}

export function saveActiveFirebaseConfig(config: Partial<FirebaseConfig>): FirebaseConfig {
  const merged = { ...getActiveFirebaseConfig(), ...config };
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_FIREBASE_CONFIG, JSON.stringify(merged));
    }
  } catch (e) {
    console.error('[Firebase] Failed to persist custom config:', e);
  }
  reinitFirebase(merged);
  return merged;
}

let firebaseApp: FirebaseApp | null = null;
let firestoreDb: Firestore | null = null;
let isConnectedToFirestore = false;
let lastSyncTimestamp: string | null = null;

export function initFirebase(customConfig?: FirebaseConfig): { app: FirebaseApp | null; db: Firestore | null } {
  try {
    const config = customConfig || getActiveFirebaseConfig();
    
    if (getApps().length > 0) {
      firebaseApp = getApp();
    } else {
      firebaseApp = initializeApp(config);
    }
    
    firestoreDb = getFirestore(firebaseApp);
    isConnectedToFirestore = true;
    console.log('[Firebase] Cloud Firestore initialized for project:', config.projectId);
    return { app: firebaseApp, db: firestoreDb };
  } catch (error) {
    console.warn('[Firebase] Firestore initialization fallback mode:', error);
    isConnectedToFirestore = false;
    return { app: null, db: null };
  }
}

export function reinitFirebase(config: FirebaseConfig) {
  try {
    firebaseApp = initializeApp(config, 'clincase-reinit-' + Date.now());
    firestoreDb = getFirestore(firebaseApp);
    isConnectedToFirestore = true;
  } catch (e) {
    console.warn('[Firebase] Reinit notice:', e);
  }
}

// Auto-initialize on module load
initFirebase();

export function getFirestoreInstance(): Firestore | null {
  if (!firestoreDb) {
    initFirebase();
  }
  return firestoreDb;
}

export function isFirebaseConnected(): boolean {
  return isConnectedToFirestore;
}

export function getLastSyncTime(): string | null {
  return lastSyncTimestamp;
}

// ============================================================================
// PATIENT DATA PERSISTENCE IN CLOUD FIRESTORE
// ============================================================================

/**
 * Saves or updates a patient session record in Firebase Firestore
 */
export async function savePatientToFirestore(patient: PatientSession): Promise<{ success: boolean; error?: string }> {
  try {
    const db = getFirestoreInstance();
    if (!db || !patient || !patient.id) {
      return { success: false, error: 'Database instance or patient ID not available' };
    }

    // Clean payload for Firestore compatibility (remove undefined fields)
    const cleanPatientPayload = JSON.parse(JSON.stringify({
      ...patient,
      updatedAt: new Date().toISOString(),
      firestoreSyncedAt: new Date().toISOString()
    }));

    const patientDocRef = doc(db, 'patients', patient.id);
    await setDoc(patientDocRef, cleanPatientPayload, { merge: true });
    
    lastSyncTimestamp = new Date().toISOString();
    console.log(`[Firestore] Successfully saved patient record [${patient.id}] to cloud.`);
    return { success: true };
  } catch (err: any) {
    console.warn(`[Firestore] Failed to save patient ${patient.id}:`, err?.message || err);
    return { success: false, error: err?.message || String(err) };
  }
}

/**
 * Fetches a single patient document from Firestore
 */
export async function getPatientFromFirestore(patientId: string): Promise<PatientSession | null> {
  try {
    const db = getFirestoreInstance();
    if (!db || !patientId) return null;

    const patientDocRef = doc(db, 'patients', patientId);
    const snap = await getDoc(patientDocRef);
    if (snap.exists()) {
      return snap.data() as PatientSession;
    }
    return null;
  } catch (err) {
    console.warn(`[Firestore] Error fetching patient ${patientId}:`, err);
    return null;
  }
}

/**
 * Fetches all patient records stored in Firestore
 */
export async function getAllPatientsFromFirestore(): Promise<PatientSession[]> {
  try {
    const db = getFirestoreInstance();
    if (!db) return [];

    const patientsCol = collection(db, 'patients');
    const snap = await getDocs(patientsCol);
    const patients: PatientSession[] = [];
    snap.forEach((d) => {
      const data = d.data();
      if (data && data.id) {
        patients.push(data as PatientSession);
      }
    });
    return patients;
  } catch (err) {
    console.warn('[Firestore] Error fetching all patients:', err);
    return [];
  }
}

/**
 * Deletes a patient record from Firestore
 */
export async function deletePatientFromFirestore(patientId: string): Promise<boolean> {
  try {
    const db = getFirestoreInstance();
    if (!db || !patientId) return false;
    const patientDocRef = doc(db, 'patients', patientId);
    await deleteDoc(patientDocRef);
    console.log(`[Firestore] Deleted patient ${patientId} from Firestore.`);
    return true;
  } catch (err) {
    console.warn(`[Firestore] Failed to delete patient ${patientId}:`, err);
    return false;
  }
}

/**
 * Real-time listener for patient updates across kiosk and doctor workstations
 */
export function subscribeToPatientsFromFirestore(callback: (patients: PatientSession[]) => void): () => void {
  try {
    const db = getFirestoreInstance();
    if (!db) return () => {};

    const patientsCol = collection(db, 'patients');
    const unsubscribe = onSnapshot(patientsCol, (snapshot) => {
      const list: PatientSession[] = [];
      snapshot.forEach((d) => {
        const item = d.data();
        if (item && item.id) {
          list.push(item as PatientSession);
        }
      });
      callback(list);
    }, (error) => {
      console.warn('[Firestore] Subscription snapshot error:', error);
    });

    return unsubscribe;
  } catch (err) {
    console.warn('[Firestore] Failed to subscribe to patients:', err);
    return () => {};
  }
}

/**
 * Saves an immutable audit trail block to Firestore under 'audit_trail'
 */
export async function saveAuditLogToFirestore(auditBlock: SecurityAuditEvent): Promise<boolean> {
  try {
    const db = getFirestoreInstance();
    if (!db || !auditBlock) return false;

    const blockId = `block-${auditBlock.index.toString().padStart(6, '0')}`;
    const auditDocRef = doc(db, 'audit_trail', blockId);
    
    await setDoc(auditDocRef, {
      ...auditBlock,
      serverTime: serverTimestamp()
    }, { merge: true });

    return true;
  } catch (err) {
    console.warn('[Firestore] Audit log save notice:', err);
    return false;
  }
}

/**
 * Synchronizes an array of local patient sessions to Cloud Firestore in a batch
 */
export async function syncAllLocalDataToFirestore(patients: PatientSession[]): Promise<{ syncedCount: number; errors: number }> {
  try {
    const db = getFirestoreInstance();
    if (!db) return { syncedCount: 0, errors: patients.length };

    const batch = writeBatch(db);
    let count = 0;

    for (const p of patients) {
      if (p && p.id) {
        const ref = doc(db, 'patients', p.id);
        const clean = JSON.parse(JSON.stringify({
          ...p,
          firestoreSyncedAt: new Date().toISOString()
        }));
        batch.set(ref, clean, { merge: true });
        count++;
      }
    }

    await batch.commit();
    lastSyncTimestamp = new Date().toISOString();
    console.log(`[Firestore] Batch sync committed: ${count} patients.`);
    return { syncedCount: count, errors: 0 };
  } catch (err) {
    console.error('[Firestore] Batch sync error:', err);
    return { syncedCount: 0, errors: patients.length };
  }
}
